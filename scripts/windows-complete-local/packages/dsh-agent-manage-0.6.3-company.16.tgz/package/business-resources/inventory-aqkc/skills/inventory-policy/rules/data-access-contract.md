# 数据与知识访问契约（MCP）

所有 Skill 取数与查规则都必须遵守本文件。主提示词只写"用哪个工具、什么时候用、禁止什么"，字段级细节在本文件与 `本 Skill 的 rules/metric-catalog.md`。

> 契约版本：2026-10-14（对齐 Cube-New 网关 MCP：语义查询与取数拆分为两个工具）。

## 一、工具清单与分工

| 工具 | 用途 | 边界 |
|---|---|---|
| `mcp__cube_new__inspect_cube_model` | 查指标语义：枚举已发布 View，读取说明书（度量、维度、单位、粒度、业务时间、`required_scope`、原值范围、`aliasMember` 底层成员映射） | 只读；默认列 View，传 `model` 看完整说明书；**不返回全模型目录**；**说明书可见 ≠ 有权取数**；不得凭猜测编造度量名 |
| `mcp__cube_new__query_business_data` | 按底层 model 成员名取数（`action` 只能为 `"query"`、`response_mode` 只能为 `"inline_complete"`） | 只读；不得反写；不得绕过该工具自行推数；不接受 SQL、身份、库地址或凭证 |
| `list_mcp_resources` / `read_mcp_resource`（`server = cube_new`） | 读取查询返回的 `resource_link` 制品 | 只读；制品与内联结果同等效力，均须落溯源 |
| `mcp__lightrag__query_document` | 查企业内部知识与规则：口径解释、业务规则、业务逻辑、SOP、例外场景 | 只读；**禁止反写、修改、删除企业内部知识**；只引用要点，不复述整篇 |

注意：指标"是什么、怎么算"以固化规则包与 `本 Skill 的 rules/metric-catalog.md` 为准；`inspect_cube_model` 说明书用于确认可查询的成员名、单位与粒度；lightrag 用于补充业务背景与例外；说明书语义或 lightrag 知识与固化规则包冲突时，以固化规则包优先，并提示冲突来源。

## 二、取数调用顺序（每次都要走）

1. **定问题与指标**：按主提示词的问题分类确定指标（查 `本 Skill 的 rules/metric-catalog.md`）。
2. **取语义**：用 `inspect_cube_model` 确认该指标所在 View、度量名、单位、粒度、业务时间（`primary_time`）与 `required_scope`，并取 `aliasMember` 作为**底层 model 成员名**（查询只能用这个名称，不能带 View 名前缀）；必要时用 `query_document` 查对应业务规则。
3. **拼查询**：按第三节契约构造；`action` 与 `response_mode` 为固定值，每条 query 必须带 `name`；度量与维度名必须来自说明书，**不确定就先取语义，不要猜**。
4. **加权限与时间**：权限过滤（`belong_base` 等）与业务时间条件（`timeDimensions`，按说明书 `primary_time`）一并写入；时间口径（当前快照 / 事后月份 / 近 30 日窗口 / 未来窗口）随查询声明。
5. **汇总**：按第四节上卷铁律；需要"先算后汇总"的指标必须分组查询后在本地计算。
6. **输出与溯源**：结论 + 数据依据（用了哪个工具、哪个度量、什么时间口径、哪条规则来源）；必须读取返回的 `warnings`、`dataStatus` 与字段单位，空值不当作 0。

## 三、cube 查询契约

### 3.1 两步走：先看说明书，再查数

1. **看说明书**：`mcp__cube_new__inspect_cube_model`（默认发现 View；传 model 看完整 View 或底层 model 说明）。返回度量、维度、单位、粒度、业务时间、原值范围、AI 上下文、层级、下钻与 `aliasMember`（View 成员到底层 model 成员的映射）。
   - 说明书**不按人员权限裁剪，也不代表查询获准**；不猜名称，目录为空就换关键词。
   - 查筛选值只选 dimensions；问最新数据先查可用业务日期或月份。
2. **查数**：`mcp__cube_new__query_business_data`，按 `aliasMember` 映射选择底层 model 成员；数据权限在实际查询时校验。

### 3.2 请求结构

```json
{
  "action": "query",
  "response_mode": "inline_complete",
  "queries": [
    {
      "name": "低于目标明细",
      "query": {
        "measures": [],
        "dimensions": [],
        "filters": [],
        "timeDimensions": [{ "dimension": "", "dateRange": ["", ""], "granularity": "day" }],
        "order": {},
        "limit": 200,
        "offset": 0,
        "total": true
      }
    }
  ]
}
```

约束：

- `action` 固定 `query`，`response_mode` 固定 `inline_complete`；`queries` 1–8 组，**每组必须有 `name`**（用于区分结果）
- `measures` ≤32、`dimensions` ≤32、`filters` ≤100；**不接受 SQL、函数、身份、库地址或 Token**
- `limit` 默认 200、最大 1000；`offset` 翻页；`hasMorePages = true` 时**必须继续分页**，不得截断后直接下结论
- `total` 固定 true：只用于取总值，**不能替代分项**（见第四节）
- `timeDimensions[].granularity` 取 second…year；`dateRange` 用起止两个值；`timezone` 只按模型声明的源时间规则（源时区未确认的新版模型仅用 UTC 以保留源日历值）
- **不同快照日期、不同月份、不同预测类型必须分开查询**，不能混在一次
- 空值不当作 0；单位或比率未知时不换算

### 3.3 结果读取

必须读 `modelContext`、`fields`、`warnings`、`dataStatus`；单位以模型声明为准；`dataStatus` 异常或 `warnings` 非空时，先在数据说明中体现再决定是否给结论。

## 四、上卷与聚合铁律（落到查询层）

| 场景 | 查询方式 | 禁止 |
|---|---|---|
| 可加和量（库存、订单量、计划量） | 按维度分组后 SUM | — |
| 比率 / 天数类 | 分别取分子与分母，再计算 | 对下级比率或天数取平均 |
| 库存差额 | 先按 基地 + SKU 取差额，再按符号分成「高于目标量」「低于目标量」两条 | 用一条净差额（正负相抵） |
| SKU 个数 / 超龄 SKU 数 | COUNT DISTINCT；全国按 SKU 去重 | 各基地相加 |
| 当前订单缺口 / 建议补货量 | 先按 基地 + SKU 查询，本地 `max(…, 0)` 后再汇总 | 先汇总总量再算缺口 |
| 平均货龄 | Σ(数量 × 货龄) ÷ Σ数量 | 简单平均 |
| 目标版本 | 先按 基地 + 月份 + 版本 + SKU 取唯一版本，再汇总 | 多版本混算 |
| 值 / 原值类度量（比率、天数、单值） | 与说明书 `required_scope` 的粒度维度一起查询 | 只取总值（缺粒度）→ `CUBE_VALUE_GRAIN_REQUIRED` |
| 快照类数量（库存类） | 单日取值或按月分组 | 跨快照日直接累加 |

`total` 只能用于"确实只要一个总数"的场景（如全国当前库存）；上面这些"先算后汇总"的指标必须给 dimensions 分组查询。

## 五、权限与只读

- 每次查询前先按角色权限过滤（基地 / 分仓 / 品类），「全国」= 用户授权基地集合，不等于公司全量。
- 无权限对象不得出现在数值、排名、引导中；权限不足时按降级话术回答。
- **说明书可见 ≠ 有权取数**：`inspect_cube_model` 不按数据权限裁剪，权限在取数时校验；被拒绝时按第七节处理，不自行补权限、不改字段映射、不绕路直连。
- 所有工具只读：不写库、不改配置、不删知识、不建事件与任务。

## 六、规则与语义冲突

| 情况 | 处理 |
|---|---|
| 说明书语义与固化规则包不一致 | 以固化规则包优先，回答中提示冲突来源，建议人工确认 |
| lightrag 知识与固化规则包不一致 | 同上；不要用模型记忆替代任一方 |
| 同一指标存在多个候选度量 | 先取语义比对口径，选与 `本 Skill 的 rules/metric-catalog.md` 一致的那个；仍不确定则说明并给两种口径的差异 |
| 度量或维度不存在 | 先用 `inspect_cube_model` 换关键词重查说明书；仍无则说明该指标当前不可取数，给可替代指标（不用相近指标冒充） |

## 七、失败与降级

| 情况 | 处理 |
|---|---|
| 工具不可用 / 超时 | 说明本次未能取到数据，不输出估算值；可给已缓存或用户提供的数据，并标注来源 |
| 权限不足 | 说明只能回答权限范围内数据，不暗示无权限对象存在 |
| 必填字段缺失 | 输出可判断部分 + 说明缺失字段及影响（不填 0） |
| 返回行数达到 limit | 说明结果被截断，改为分组聚合或增加过滤后重查 |
| 时间口径不匹配 | 明确说明用的是快照 / 事后 / 窗口，不给跨口径结论 |
| 同一指标两次取数不一致 | 先比对口径、快照时间与过滤条件并说明差异原因；无法解释时标注「数据待复核」，**该数字不得用于排名、建议或对外结论** |
| 本地脚本计算结果与查询结果不一致 | 以查询结果为准，说明脚本假设；不得两套数字同时出现在回答中 |
| 缺业务时间被拒（`CUBE_BUSINESS_TIME_REQUIRED`） | 按说明书 `primary_time` 补业务时间条件后重查；属用法问题，不上报为系统故障 |
| 缺粒度维度被拒（`CUBE_VALUE_GRAIN_REQUIRED`） | 按说明书 `required_scope` 补粒度维度后重查；仍失败则说明该指标当前不可取数 |
| 参数不符合契约（`AI_SCHEMA_INVALID`） | 按第三节重构后重查；连续 2 次仍失败即停止，交开发排查，不换写法凑结果 |
| 字段未映射 / 成员未发布（`AI_GATEWAY_DATA_PERMISSION_DENIED`、`DATA_QUERY_MEMBER_NOT_PUBLISHED`） | 属平台侧发布与字段映射配置：说明该指标当前不可取数并给替代指标，转数据资源管理员；**换凭证无效**，不自行补权限 |
| 取数会话失效（`AI_GATEWAY_SESSION_INVALID`、`AI_GATEWAY_SESSION_MAX_LIFETIME_EXCEEDED`，约 3~4 天需刷新） | 说明本次未取到数据，不输出估算值；通知运维刷新取数会话，不改任何配置、不改提示词 |

## 八、溯源要求

每次回答的数据依据至少包含：数据来源工具（cube 语义 + 取数）、所用度量与维度、数据时间（快照时间 / 统计月份 / 窗口）、目标版本（如涉及目标）、规则来源（固化规则包章节或 metric-catalog 条目）。

建议一并记录（便于复核）：返回的 `dataStatus` 与 `warnings`、`modelContext` 中的口径说明、字段单位（`unit` / `display_unit`）、`lastRefreshTime`。
