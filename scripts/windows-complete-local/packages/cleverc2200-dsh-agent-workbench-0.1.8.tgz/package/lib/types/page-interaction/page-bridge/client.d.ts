export type PageBridgeApplyResult = {
    applied: boolean;
    error?: string;
};
export type PageBridgeApply = (args: unknown, meta: {
    toolCallId: string;
    toolCallName: string;
}, signal: AbortSignal) => PageBridgeApplyResult | Promise<PageBridgeApplyResult>;
export type PageBridgeClientOptions = {
    /** Workbench 页面动作端点。 */
    endpoint: string;
    /** 页面自己的请求函数：与宿主通信的方式由业务决定。 */
    request: <T>(endpoint: string, payload: object) => Promise<T>;
    /** 当前会话；为空时桥不工作。 */
    sessionId: string | null;
    /** 业务实现：把一次工具调用落到页面上。 */
    apply: PageBridgeApply;
    /** 轮询间隔，默认 1200ms。 */
    pollMs?: number;
    /** 首次轮询前的延迟，默认 500ms。 */
    initialDelayMs?: number;
    /** 单次应用的最长等待；超时按失败回填，避免结果永远悬着。 */
    applyTimeoutMs?: number;
    /** 桥自身出错时的回调（默认忽略，下一轮自动重试）。 */
    onError?: (error: unknown) => void;
    /**
     * 关掉桥时是否要告诉宿主"这个会话已经没有页面能力"（默认是）。
     * 页面被卸载时用它把元素目录撤掉，避免模型继续对着上一屏的元素下指令。
     */
    closeOnDispose?: boolean;
    /**
     * 页面主动发布目录。
     */
    /**
     * 页面自述的能力目录：这一屏此刻能做什么。
     * 桥据此为这个会话生成工具；不声明（返回 null）就等于没有可调用动作。
     */
    catalog?: () => unknown;
};
/**
 * 启动页面桥客户端，返回 dispose。
 * 桥不可用不能影响业务页面本身：所有错误都吞掉并在下一轮重试。
 */
export declare function startPageBridgeClient(options: PageBridgeClientOptions): () => void;
