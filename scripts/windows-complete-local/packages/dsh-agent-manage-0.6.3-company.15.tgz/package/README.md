<img src="docs-site/public/favicon.svg" alt="" width="48" height="48" />

Version metadata is declared in [package.json](package.json); past changes are recorded in [release history](CHANGELOG.md).

# dsh-agent-manage

Personal Agent MCP connections use the Agent configuration MCP tab. Display names and stable server identifiers are separate; each Agent can select, disable or remove its own association. Shared definitions, credentials and connections remain managed by Catalog.runtime; removing one association keeps other Agents working.

The same MCP editor supports Streamable HTTP, SSE and stdio. For stdio, command, arguments, working directory and environment variables remain separate; personal definitions allow absolute paths and retain unknown extension fields. OAuth uses the existing host credential record and browser flow. Saving can return while browser approval is pending; cancellation and failure remain visible until reauthorization. Cancelling or replacing a connection closes its pending callback and rejects late token writes.

**An Agent configuration and native preset workspace for [DeepSeek Harness (DSH)](https://github.com/deepseek-ai/deepseek-harness).**

Reuse supported content from Claude Code, Codex, Cursor, Kimi and other recognized layouts. Manage your own skills, commands, agent personas, MCP services and LSP servers in the DSH Web GUI. Supported layouts are read in place, without converting manifests or manually copying files into DSH. See the capability matrix for format-specific limits.

English | [简体中文](README.zh.md) | [Documentation](https://github.com/CleverC2200/dsh-agent-manage/tree/main/docs/guides)

[![License](https://img.shields.io/github/license/CleverC2200/dsh-agent-manage)](LICENSE)

[Quick start](#quick-start) · [Everyday use](#everyday-use) · [Compatibility](#compatibility-and-boundaries) · [FAQ](#faq)

## Personal Agent configuration

The public Agent configuration page now creates durable personal Agents and publishes enabled configurations as native presets composed from the active DSH standard declaration. Start chat uses the Workbench native Session entry and keeps the current conversation and default choice. The Skill tab selects existing provider resources or creates personal instructions. Skill edits and enable switches apply to new Sessions of that Agent; source files and existing Session revisions stay intact. Disabling withdraws the preset from new tasks; deletion retains recoverable configuration, history and drafts. Restore leaves the configuration disabled until explicit enable and dependency checks, without changing the host default. Live Sessions retain their revision; cold recovery uses the retained current configuration and cannot reconstruct older revisions. External MCP connections use the MCP tab. Imported Git, directory and archive configurations support three-way synchronization with local, upstream or manual conflict resolution; a failed update preserves the usable revision. The MCP tab also selects one trusted plugin Cube reference under the current GEA identity; plugin presets offer an explicit copy into a personal Agent. These configurations are distinct from reusable subagent roles.

## What you can do

- Create and enable personal Agents with stable native preset identities.
- Import Git, local-directory and archive configurations, then preserve personal changes through synchronization.
- Select existing Skills or edit personal Skill bodies for each Agent.
- Configure Agent-scoped MCP connections and permitted trusted Cube references using host credentials and authorization.

Project resources and native commands, LSP, hooks and subagent runtimes retain their existing execution contracts. The Agent directory changes configuration management; those runtimes remain available under host policy.

## Quick start

This fork uses the package name `dsh-agent-manage`; publication of the new npm package has not been performed or verified here. Use the GitHub source below. When replacing the old package, remove its profile entry before installing this package to avoid duplicate loading. Current settings bind the `dsh-agent-manage` Loader entry. Old namespace values are not automatically imported; existing user data stays in place.

Toolchain and peer requirements are declared in [package.json](package.json). Git sources require Git, and resource discovery requires the host skill service. Isolated installation needs the registered official SDK and reviewed package artifacts; the command below does not prepare those inputs. See [host requirements](docs/guides/usage.md#host-requirements). The runtime peer contract accepts the registered official DSH 0.2.0-rc.2 and 0.2.1-alpha.1 releases; [the dual Core decision](.agents/notes/implemented/process/2026-10-10-two-official-core-releases.md) owns their exact peers and capability matrix. Development icons and UI primitives use the task-registered alpha.1 SDK, with React deduplication retained.

Install into your profile, replacing `<name>` with its name:

```sh
dsh plugin --profile <name> add github:CleverC2200/dsh-agent-manage
```

1. Restart DSH and open **Workbench → Agent configuration** (`agent-plugin-workspace`). Settings opens the same Agent list and editor.
2. Create a personal Agent, or open **Configuration sources** to acquire a Git repository, local directory or archive and explicitly import an Agent. The bundled sales source is discoverable but requires import.
3. Configure its **Prompt**, **Skill** and **MCP** tabs. Cancel discards the form; saving configuration, publishing the native preset and connecting MCP have separate results.
4. Enable the Agent and choose **Start conversation**, or select it in the ordinary host roster. Enabling does not change your default Agent or an existing Session.

## Everyday use

The Agent list shows source, personal changes, enablement and availability. Source synchronization compares base, personal configuration and upstream, then asks for an explicit conflict resolution. A failed update keeps the previous usable preset. Disabling or deleting a personal Agent preserves recoverable configuration, Session history and drafts.

Personal MCP connections support Streamable HTTP, SSE, stdio and the host credential/OAuth mechanisms. Removing an association affects only the current Agent. Plugin-provided MCP is source-owned and only supports enablement; create a personal Agent for permitted combinations. GEA Cube is a trusted plugin reference checked by the GEA Host against the current identity and Consumer.

The retired market installation, command/LSP editors and generic resource HTTP writes are removed. Discovery, acquisition, cache, source locks, import/sync, commands/LSP/hooks/project runtimes and subagent execution remain. See [storage and discovery](docs/guides/usage.md#storage-and-discovery) for paths and precedence.

Startup uses the current `$DSH_HOME/agent-plugins` storage only. Retired `userRoot` or `dataRoot` configuration is rejected with `MANAGE_STORAGE_UPGRADE_REQUIRED` before runtime mounting; existing data stays in place and any conversion is a separately authorized upgrade. The canonical home, user/data, authored-user and `.sources` directories must not be symbolic links.

Old plugin MCP connection overrides remain in `data/overrides/` for recovery. Only their enablement applies; runtime status reports `PLUGIN_MCP_OVERRIDE_RETIRED` with the preserved file path. Copy desired values explicitly into a personal Agent connection. Personal MCP definitions and credentials keep their existing storage and lifecycle.

## Compatibility and boundaries

Supported **layout dialects** describe how files are organized. The [shared priority table](#layout-detection-precedence) lists suite manifests and Marketplace catalogs together.

All ten active layout contracts in [`schemas/`](schemas/README.md) have independent reader tests. [The layout audit](docs/layout-coverage.md) maps them to commit-pinned README repository fixtures and distinguishes layout/component compatibility from full original-client runtime equivalence.

Supported **runtime surfaces** describe what DSH can use:

| Surface  | Runtime support and conditions                                                                                                            |
| -------- | ----------------------------------------------------------------------------------------------------------------------------------------- |
| Skills   | Host skill catalog and user-invocable slash entries; supported root placeholders are expanded.                                            |
| Commands | Slash commands through the host command service.                                                                                          |
| Agents   | Dynamic subagent catalog and `subagents_run`; requires host agents, tools, LLM and subagent services.                                     |
| MCP      | Built-in bridge by default: stdio, Streamable HTTP with OAuth, and legacy SSE. Optional host-client compatibility mode is also available. |
| Hooks    | The command-hook subset mapped by `dsh-hooks-claude-code`.                                                                                |
| LSP      | Live mounts when the host provides LSP packages; the profile must expose the LSP tool for agent use.                                      |

Agent roles are published directly in a dynamic `subagent-catalog`, using the same per-step comparison, durable entries and complete replacement mechanism as DSH's skills catalog. Call `subagents_run(role, prompt)` with the catalog's exact ID; it resolves the role's provider, model and `reasoning_effort`, then applies the persona and tool restrictions. Roles no longer generate `agent-*` or `persona-*` skill/command entries. See [agent roles](docs/guides/agent-roles.md) for model inheritance, catalog refresh and migration from `market_agent`.

### Layout detection precedence

When multiple manifests exist in the **same suite directory**, the first existing file in this order selects the layout:

| Priority | Layout | Suite manifest | Marketplace catalog |
| --- | --- | --- | --- |
| 1 | agent-plugins.org v1 / root compatibility | `plugin.json` | No dedicated catalog |
| 2 | Universal compatibility | `.plugin/plugin.json` | `.plugin/marketplace.json` |
| 3 | Claude Code | `.claude-plugin/plugin.json` | `.claude-plugin/marketplace.json` |
| 4 | Cursor | `.cursor-plugin/plugin.json` | `.cursor-plugin/marketplace.json` |
| 5 | Kimi Code | `kimi.plugin.json`, then `.kimi-plugin/plugin.json` | `.kimi-plugin/marketplace.json` |
| 6 | Codex | `.codex-plugin/plugin.json` | `.agents/plugins/marketplace.json`, then `.agents/plugins/api_marketplace.json` |
| 7 | ZCode | `.zcode-plugin/plugin.json` | No dedicated catalog |
| 8 | Qoder CLI | `.qoder-plugin/plugin.json` | `.qoder-plugin/marketplace.json` |
| 9 | GitHub Copilot CLI | `.github/plugin/plugin.json` | `.github/plugin/marketplace.json` |
| Fallback | Skill collection / shared catalog | Discover skills when no recognized manifest exists | Root `marketplace.json` |

- **Selection precedes parsing:** an invalid higher-priority manifest produces diagnostics; it does not trigger a retry with a lower-priority manifest.
- **Root manifest identity:** root `plugin.json` uses strict v1 validation only when it declares a recognized agent-plugins.org `$schema`. Otherwise it is read as a Claude-compatible manifest.
- **Component fallback:** manifests are not generally merged. For a non-v1 root `plugin.json`, missing component declarations can come from `.claude-plugin/plugin.json`. Explicit root declarations win; marketplace entry declarations fill remaining gaps.

**Both columns follow the same layout priority.** Catalog lookup skips layouts without a dedicated catalog; aliases are tried in the listed order. Root `marketplace.json` is a shared fallback, not a skill-collection manifest or an agent-plugins.org v1 catalog, and does not inherit the priority of root `plugin.json`.

All existing catalogs are read, but suite scanning selects the first catalog that produces suites, rather than merging every catalog. Invalid or empty catalogs allow the next candidate to be tried. This priority does not make native project directories mutually exclusive.

The order is defined in [`src/model/layouts.ts`](src/model/layouts.ts); selection and root-manifest fallback are implemented in [`src/catalog/manifests.ts`](src/catalog/manifests.ts).

### Layout capability matrix

Checked against official documentation, this plugin's source, and one real repository per schema on 2026-09-08. This table describes **integration by this plugin**. “Shared” means the plugin's common scanning conventions, not an upstream-defined capability. “Partial” requires the limitations below. The [compatibility report](docs/compat-report.md) records the sampled repositories, their commits, the schema verdicts and the scanner output.

| Layout | Skills | Agents | Commands | MCP | Hooks | LSP |
| --- | --- | --- | --- | --- | --- | --- |
| [Claude Code](https://code.claude.com/docs/en/plugins-reference) | Declared + default skills | Declared Markdown | Declared Markdown | Files / inline | Command-hook subset | Files / inline |
| [Codex](https://developers.openai.com/plugins/build/plugins) | Supported | Shared | Shared | Partial: `.mcp.json` | Compatible event subset | Shared inline |
| [Cursor](https://cursor.com/docs/reference/plugins) | Supported | Partial: `.md` only | Partial: `.md` only | Partial: see below | Native events unsupported | Shared inline |
| Kimi Code | Declared skills + startup | Declared Markdown | Declared commands | Inline | Inline command events | Shared extension, non-native |
| [ZCode](https://zcode.z.ai/en/docs/plugin) `.zcode-plugin/` | Shared | Shared | Shared | `.mcp.json` + inline overrides | Shared | Shared inline, non-native |
| [Qoder CLI](https://docs.qoder.com/cli/plugins-reference) `.qoder-plugin/` | Shared | Shared | Shared | Partial: prefers `.mcp.json` | Shared | Shared inline, non-native |
| [GitHub Copilot CLI](https://docs.github.com/en/copilot/reference/copilot-cli-reference/cli-plugin-reference) | Declared skills | `.md` / `.agent.md` | Declared Markdown | Files / inline | Mapped command events | Files / inline |
| Universal compatibility layout `.plugin/` | Shared | Shared | Shared | Shared | Claude-format subset | Shared inline |
| [agent-plugins.org v1](https://agent-plugins.org/specification) | Supported | Shared, nonstandard | Shared, nonstandard | Standard `mcp.json` | Shared, nonstandard | Directory preview only, nonstandard |
| Manifest-less skill collection | Supported | Shared | Shared | Shared files | Claude-format subset | Directory preview only |
| Project-native directories (see below) | Supported | Portable Markdown roles | Scoped commands | JSON / Codex TOML | Mapped command-hook subset | Diagnosed, not mounted |

- **Component paths:** declared files, directory trees and arrays resolve inside the suite by realpath. Commands, agents and detail panels use the same resources. Cursor also accepts `.mdc`, `.markdown` and `.txt` commands; Qoder maps support files and inline content. Claude/Codex skills supplement default discovery. Flat skill Markdown files work in manifest-less collections.
- **Agent identities:** `reviewer.agent.md` and `reviewer.md` retain distinct role IDs in the subagent catalog. Roles have no generated `agent-*` skill or command aliases. Ordinary skills with those names remain skills.
- **MCP:** declared files, inline maps and arrays are resolved by dialect. Cursor's schema-less `mcp.json` is supported; agent-plugins v1 stays schema-strict. Claude/ZCode declarations add to defaults, Cursor declarations replace defaults, Copilot/Universal include `.github/mcp.json`, and Kimi Code uses inline declarations. Invalid explicit configs cannot revive defaults. Codex app connectors remain outside this adapter.
- **Hooks:** declared files/directories and inline configs are supported, including Kimi arrays and ZCode process hooks with quoted argv. Supported Copilot/Cursor lifecycle names map to the existing command-hook bridge. Events without a DSH equivalent, such as `afterFileEdit`, are diagnosed rather than simulated.
- **LSP:** user suites accept declared files, arrays and inline tables, plus `.lsp.json` and Copilot/Universal `lsp.json`, `.github/lsp.json`, `lsp-config/servers.json`. Reverse-domain directory definitions remain previews. Project LSP retains its host-scope limitation.
- **Specification boundaries:** agent-plugins.org v1 standardizes portable skills and MCP only; shared agents / commands / hooks scanning is not a standard capability. Universal is a compatibility-layout label used by this plugin; the [OpenHands SDK](https://docs.openhands.dev/sdk/guides/plugins) documents the same `.plugin/plugin.json` location and a [Vercel repository](https://github.com/vercel/vercel-plugin/blob/main/.plugin/plugin.json) uses it, but no cross-vendor specification exists.
- **Kimi Code:** the active schema covers both manifest spellings, startup skills, appended skill instructions, system prompts, inline hooks and catalog aliases. The historical `kimi-cli` root tools protocol is a different system; it must not be confused with the current Kimi Code schema.
- **ZCode boundary:** `.zcode-plugin/plugin.json` and root `marketplace.json` are recognized, including keyed plugin maps. Inline MCP servers override matching `.mcp.json` keys. The zip + `sha256` marketplace distribution contract is not implemented.
- **Qoder boundary:** `.qoder-plugin/plugin.json` and `.qoder-plugin/marketplace.json` are recognized. MCP prefers `.mcp.json`, with schema-less `mcp.json` as fallback.
- **GitHub Copilot CLI:** `.plugin/plugin.json` retains the Universal identity. Both spellings consume declared component paths and fallback MCP/LSP files. Isolated tests suppress competing manifests at nested suite roots, preventing a Claude fallback from masquerading as a passing Copilot test.
- **Project directories:** [Claude project skills](https://code.claude.com/docs/en/skills) and [Codex `.agents/skills`](https://developers.openai.com/codex/skills) are documented upstream; `.agents/agents` and `.agents/commands` are this plugin's shared discovery conventions.

### Project layout switch

The plugin settings card exposes **Scan project Agent layouts** (`dsh-agent-manage.scanProjectLayouts`, default `true`). Turning it off removes this plugin's native project candidates immediately; configured sources and the harness's own skill providers remain independent. Files are read in place and are never installed, rewritten or deleted.

The registry reads skills under `.claude`, `.agents`, `.codex`, `.cursor`, `.kimi`, `.zcode`, `.qoder` and `.github`. Portable Markdown agents are enabled for all except `.codex` and `.kimi`; their TOML/YAML formats need separate adapters. Role execution resolves the calling session's project. Project commands, supported MCP servers and mapped command hooks register in each agent's scoped context and refresh on session startup or catalog changes; disabling the switch removes them.

MCP reads root `.mcp.json`, `.cursor/mcp.json`, and the `mcpServers` tables in `.qoder/settings.json` and `.qoder/settings.local.json` (local keys override project keys). ZCode reads `mcp.servers` from `zcode.json` and `.zcode/config.json`, with `.agents/mcp.json` as an empty-native-table fallback. Codex reads `[mcp_servers.*]` from `.codex/config.toml` through `smol-toml`, preserving stdio/HTTP configuration, environment/header references, enabled flags, tool filters and timeouts. Unsupported server options produce diagnostics; host-client mode rejects policies it cannot enforce. Relative executables resolve from the project root. Claude/Qoder settings hooks and enabled ZCode configuration hooks use the bridge's supported command-event subset. Validated hooks become private temporary runtime files removed on teardown; project files remain unchanged. Project LSP is diagnosed and not mounted: host changes are outside this plugin's scope. See the [architecture decision and supported boundaries](docs/adr/2026-09-09-layout-registry.md).

### Verified samples

These are dated fixture/report observations; this documentation cleanup does not rerun their tests or refresh acceptance. Current installed behavior must be checked against the target inputs and runtime.

The nine README repository samples have offline snapshots in [`tests/fixtures/real-layouts/`](tests/fixtures/real-layouts/), with commit IDs, hashes and licenses. Tests validate real schemas, scan original trees and isolate each dialect independently. The [compatibility report](docs/compat-report.md) records natural precedence; [the audit](docs/layout-coverage.md) records independent resource checks.

| Layout | Sample repository | Dialect manifest | Schema | Scanner |
| --- | --- | --- | --- | --- |
| Claude Code | [grafana/mcp-grafana](https://github.com/grafana/mcp-grafana) | `.claude-plugin/plugin.json` | valid | integrated |
| Codex | [saadeghi/daisyui](https://github.com/saadeghi/daisyui) | `.codex-plugin/plugin.json` | valid | shadowed |
| Cursor | [EveryInc/compound-engineering-plugin](https://github.com/EveryInc/compound-engineering-plugin) | `.cursor-plugin/plugin.json` + marketplace | valid | shadowed |
| Kimi | [obra/superpowers](https://github.com/obra/superpowers) | `.kimi-plugin/plugin.json` | valid | shadowed |
| Universal | [muratcankoylan/Agent-Skills-for-Context-Engineering](https://github.com/muratcankoylan/Agent-Skills-for-Context-Engineering) | `.plugin/plugin.json` | valid | integrated |
| agent-plugins.org v1 | [saadeghi/daisyui](https://github.com/saadeghi/daisyui) | `plugin.json` | valid | integrated |
| ZCode | [zenstory-ai/oh-story-claudecode](https://github.com/zenstory-ai/oh-story-claudecode) | `.zcode-plugin/plugin.json` + `marketplace.json` | valid | shadowed |
| Qoder CLI | [DietrichGebert/ponytail](https://github.com/DietrichGebert/ponytail) | `.qoder-plugin/plugin.json` | valid | shadowed |
| GitHub Copilot CLI | [headroomlabs-ai/headroom](https://github.com/headroomlabs-ai/headroom) | `.github/plugin/marketplace.json` | valid | shadowed |

**Scanner** describes the unmodified repository: **integrated** means its own manifest won; **shadowed** means another won; **unread** means no suite. These verdicts are separate from passing isolated tests. Skill collection is tested with the real Universal repository's skills and no manifests, completing coverage of all ten layouts.

Source checks covered `src/catalog/manifests.ts`, `surfaces.ts`, `validate.ts`, `native-project.ts`, and `src/runtime/hooks-mounts.ts`. The [compatibility report](docs/compat-report.md) adds one real repository per schema, read by this plugin's own scanner. This is a documentation, source and sample audit, not end-to-end compatibility certification for every platform.

Reading a layout does not guarantee every behavior of its original platform. Invalid declarations are diagnosed and skipped. Project-native commands and supported MCP servers use agent-scoped host registration; project MCP server names include session identity to avoid app-wide namespace conflicts.

Review third-party suites before enabling them: enabled services and hooks can execute programs. See the [runtime and security details](docs/guides/usage.md#runtime-and-security).

## FAQ

**Why is an installed skill or tool missing?**

Check that the suite and the relevant capability are enabled. Skills may restrict manual invocation. MCP / LSP panels show user-service failures. Project resources additionally require the project-scan switch; unsupported native fields and project LSP declarations appear in scan diagnostics, while scoped mount failures are logged by the host.

**Where do I configure MCP tokens?**

Open the service in **MCP services**. Missing environment references show `needs-credentials`. Host-managed credentials are write-only; launch-environment credentials require changing the environment and restarting DSH.

**How do I add a service that no suite declares?**

Use **Add** in **MCP services** or **LSP servers**. The declaration is validated, stored under `~/.dsh/agent-plugins/data/`, and mounted through the same lifecycle as suite services. Host-observed services remain read-only.

**What if a source download fails?**

Use a local directory, adopt a manual checkout, or configure a proxy / mirror. See [source configuration](docs/guides/usage.md#configure-marketplace-sources).

**When do local edits become visible?**

There is no file watcher. Local-source discovery caches results for up to 30 seconds; refresh the source to invalidate them immediately. Project discovery has a separate five-second cache. A refresh does not happen automatically on an already-open page.

**Does removing a source delete its files?**

Only when you tick **also delete the managed market directory** in the confirmation. That removes the source's checkout under `~/.dsh/agent-plugins/.sources/<id>` — including one you cloned yourself and adopted. A local-directory source pointing outside `.sources/` is never deleted.

## More documentation

Both the Host and client entrypoints export the frozen `pluginPackageVersion {name, version}` captured during compilation. Builds generate it from the current package.json; typechecking rejects a stale stamp. Loaded modules do not reread an updated manifest. Runtime checks must read the actual ACTIVE Loader module exports and separately verify the installation source and restart; this stamp alone does not establish Native loading or business acceptance.

- [Usage guide](docs/guides/usage.md): installation, source configuration, storage, host requirements, MCP / LSP and feedback settings.
- [Plugin specifications](schemas/README.md): per-dialect reference schemas and evidence, plus the vendored agent-plugins.org v1.0.0 contracts.
- [Compatibility report](docs/compat-report.md): one real repository per schema, with commits, schema verdicts and scanner output.
- [Contributing](CONTRIBUTING.md): development setup, checks and PR workflow.
- [Security policy](SECURITY.md) · [Release history](CHANGELOG.md) · [MIT license](LICENSE).
- [Domain glossary](CONTEXT.md) · [Architecture](docs/adr/0001-catalog-centered-modular-refactor.md).

- [Agent roles and storage](docs/guides/agent-roles.md): role policy, durable catalog and storage.
- [GEA MCP](docs/guides/gea-mcp.md): login owner, Consumer/preset boundaries and cancellation.
- [Native resources](docs/guides/native-resources.md): public resource selection, recovery, references, calculation provenance and business package boundaries.
- [Current development](docs/current-development.md): registered SDK, source checks and outstanding acceptance.
