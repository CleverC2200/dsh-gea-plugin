window.__ModuleLoader__.load({ id: "dsh-agent-manage", factory: (require) => {

		var module = { exports: {} };
		var exports = module.exports;
var __dshManageClientCss="._6K1mgq_overlay {\n  z-index: 2147483647;\n  box-sizing: border-box;\n  background: var(--dsw-alias-bg-mask-3);\n  backdrop-filter: blur(3px);\n  cursor: progress;\n  outline: none;\n  place-items: center;\n  display: grid;\n  position: fixed;\n  overflow: hidden;\n}\n\n._6K1mgq_overlay[data-visible=\"false\"] {\n  backdrop-filter: none;\n  background: none;\n}\n\n._6K1mgq_overlay[data-visible=\"true\"] {\n  animation: .14s ease-out _6K1mgq_busy-enter;\n}\n\n._6K1mgq_content {\n  box-sizing: border-box;\n  border: 1px solid var(--workbench-border);\n  background: var(--workbench-subtle);\n  width: min(360px, 100% - 32px);\n  color: var(--workbench-text);\n  text-align: center;\n  border-radius: 8px;\n  flex-direction: column;\n  align-items: center;\n  gap: 12px;\n  padding: 24px;\n  display: flex;\n}\n\n._6K1mgq_spinner {\n  width: 28px;\n  height: 28px;\n  animation: .9s linear infinite _6K1mgq_busy-spin;\n  display: flex;\n}\n\n._6K1mgq_label {\n  font-size: var(--workbench-font-size);\n  font-weight: 600;\n  line-height: 20px;\n}\n\n._6K1mgq_hintViewport {\n  width: 100%;\n  min-height: 54px;\n  overflow: hidden;\n}\n\n._6K1mgq_hint {\n  font-size: calc(var(--workbench-font-size) * 13 / 14);\n  color: var(--workbench-body);\n  overflow-wrap: anywhere;\n  margin: 0;\n  line-height: 18px;\n  animation: .3s ease-out _6K1mgq_busy-hint;\n}\n\n@keyframes _6K1mgq_busy-spin {\n  to {\n    transform: rotate(360deg);\n  }\n}\n\n@keyframes _6K1mgq_busy-enter {\n  from {\n    opacity: 0;\n  }\n\n  to {\n    opacity: 1;\n  }\n}\n\n@keyframes _6K1mgq_busy-hint {\n  from {\n    opacity: 0;\n    transform: translateY(14px);\n  }\n\n  to {\n    opacity: 1;\n    transform: translateY(0);\n  }\n}\n\n@media (prefers-reduced-motion: reduce) {\n  ._6K1mgq_overlay, ._6K1mgq_hint {\n    animation: none;\n  }\n\n  ._6K1mgq_spinner {\n    animation-duration: 2.4s;\n  }\n}\n.uCpKnW_workspace {\n  color: var(--workbench-text, #202127);\n  max-width: 1040px;\n  height: 100%;\n  font: 14px/1.55 var(--workbench-font-family, -apple-system, BlinkMacSystemFont, \"PingFang SC\", sans-serif);\n  box-sizing: border-box;\n  margin: 0 auto;\n  padding: 40px 48px;\n  overflow-y: auto;\n}\n\n.uCpKnW_settingsWorkspace {\n  max-width: none;\n  height: auto;\n  padding: 24px 0 0;\n  overflow: visible;\n}\n\n.uCpKnW_workspace button, .uCpKnW_workspace input, .uCpKnW_workspace textarea, .uCpKnW_workspace select {\n  font: inherit;\n}\n\n.uCpKnW_workspace button {\n  cursor: pointer;\n  border: 1px solid var(--workbench-border, #dfe1e6);\n  color: inherit;\n  white-space: nowrap;\n  background: none;\n  border-radius: 8px;\n  padding: 6px 12px;\n  font-size: 13px;\n}\n\n.uCpKnW_workspace button:hover {\n  background: var(--workbench-hover, #f6f7f9);\n}\n\n.uCpKnW_workspace button:disabled {\n  opacity: .45;\n  cursor: default;\n}\n\n.uCpKnW_workspace button:focus-visible, .uCpKnW_workspace summary:focus-visible, .uCpKnW_workspace input:focus-visible, .uCpKnW_workspace select:focus-visible, .uCpKnW_workspace textarea:focus-visible {\n  outline-offset: 2px;\n  outline: 2px solid #4c8dff;\n}\n\n.uCpKnW_workspace .uCpKnW_primary {\n  background: var(--workbench-text, #18191d);\n  color: var(--workbench-bg, #fff);\n  border-color: #0000;\n}\n\n.uCpKnW_workspace .uCpKnW_primary:hover {\n  background: #34363c;\n}\n\n.uCpKnW_workspace .uCpKnW_switchOn:hover {\n  background: var(--workbench-text, #18191d);\n}\n\n.uCpKnW_workspace .uCpKnW_switchOff:hover {\n  background: #e3e4e7;\n}\n\n.uCpKnW_heading {\n  align-items: center;\n  gap: 12px;\n  margin-bottom: 20px;\n  display: flex;\n}\n\n.uCpKnW_title {\n  flex: 1;\n  min-width: 0;\n}\n\n.uCpKnW_title h2 {\n  margin: 0;\n  font-size: 20px;\n  font-weight: 600;\n}\n\n.uCpKnW_title p {\n  color: var(--workbench-muted, #69717c);\n  white-space: nowrap;\n  text-overflow: ellipsis;\n  margin: 3px 0 0;\n  font-size: 13px;\n  overflow: hidden;\n}\n\n.uCpKnW_sectionTitle {\n  margin: 28px 0 8px;\n  font-size: 14px;\n  font-weight: 500;\n}\n\n.uCpKnW_sectionTitle span {\n  color: var(--workbench-muted, #69717c);\n  margin-left: 5px;\n  font-size: 13px;\n}\n\n.uCpKnW_row {\n  align-items: center;\n  gap: 16px;\n  min-height: 68px;\n  display: flex;\n}\n\n.uCpKnW_workspace .uCpKnW_identity {\n  text-align: left;\n  border: 0;\n  flex: 1;\n  align-items: center;\n  gap: 14px;\n  min-width: 0;\n  padding: 8px 0;\n  display: flex;\n}\n\n.uCpKnW_identity > span:last-child {\n  min-width: 0;\n}\n\n.uCpKnW_identity strong {\n  text-overflow: ellipsis;\n  font-size: 14px;\n  font-weight: 550;\n  display: block;\n  overflow: hidden;\n}\n\n.uCpKnW_description {\n  color: var(--workbench-muted, #69717c);\n  white-space: nowrap;\n  text-overflow: ellipsis;\n  margin: 3px 0 0;\n  font-size: 13px;\n  display: block;\n  overflow: hidden;\n}\n\n.uCpKnW_icon {\n  border: 1px solid var(--workbench-border, #dfe1e6);\n  color: #488dfb;\n  border-radius: 12px;\n  flex-shrink: 0;\n  place-items: center;\n  width: 46px;\n  height: 48px;\n  display: grid;\n}\n\n.uCpKnW_workspace .uCpKnW_switchOn, .uCpKnW_workspace .uCpKnW_switchOff {\n  background: var(--workbench-text, #18191d);\n  border: 0;\n  border-radius: 20px;\n  flex-shrink: 0;\n  width: 36px;\n  height: 21px;\n  padding: 0;\n  position: relative;\n}\n\n.uCpKnW_switchOn span, .uCpKnW_switchOff span {\n  background: #fff;\n  border-radius: 50%;\n  width: 15px;\n  height: 15px;\n  position: absolute;\n  top: 3px;\n  left: 18px;\n}\n\n.uCpKnW_workspace .uCpKnW_switchOff {\n  background: #e3e4e7;\n}\n\n.uCpKnW_switchOff span {\n  left: 3px;\n}\n\n.uCpKnW_workspace .uCpKnW_back {\n  color: var(--workbench-muted, #69717c);\n  border: 0;\n  margin-bottom: 20px;\n  padding: 0;\n}\n\n.uCpKnW_tabs {\n  border-bottom: 1px solid var(--workbench-border, #dfe1e6);\n  gap: 26px;\n  margin: 20px 0;\n  display: flex;\n}\n\n.uCpKnW_workspace .uCpKnW_tabs button {\n  color: var(--workbench-muted, #69717c);\n  border: 0;\n  border-radius: 0;\n  padding: 8px 0 10px;\n}\n\n.uCpKnW_workspace .uCpKnW_tabs button[aria-current] {\n  border-bottom: 2px solid var(--workbench-text, #202127);\n  color: var(--workbench-text, #202127);\n  font-weight: 600;\n}\n\n.uCpKnW_workspace label {\n  margin-bottom: 16px;\n  font-size: 13px;\n  display: block;\n}\n\n.uCpKnW_workspace input, .uCpKnW_workspace select, .uCpKnW_workspace textarea {\n  box-sizing: border-box;\n  background: var(--workbench-bg, #fff);\n  width: 100%;\n  color: inherit;\n  border: 1px solid var(--workbench-border, #dfe1e6);\n  caret-color: var(--workbench-text, #202127);\n  border-radius: 8px;\n  margin-top: 5px;\n  padding: 7px 10px;\n  display: block;\n}\n\n.uCpKnW_workspace textarea {\n  resize: vertical;\n  line-height: 1.7;\n}\n\n.uCpKnW_inline {\n  background: var(--workbench-hover, #f5f6f7);\n  border: 1px solid var(--workbench-border, #dfe1e6);\n  border-radius: 12px;\n  margin-top: 16px;\n  padding: 18px;\n}\n\n.uCpKnW_actions {\n  border-top: 1px solid var(--workbench-border, #dfe1e6);\n  justify-content: flex-end;\n  gap: 8px;\n  padding-top: 14px;\n  display: flex;\n}\n\n.uCpKnW_error {\n  color: var(--workbench-danger, #b42318);\n  white-space: pre-wrap;\n  overflow-wrap: anywhere;\n}\n\n.uCpKnW_muted {\n  color: var(--workbench-muted, #69717c);\n  font-size: 13px;\n}\n\n.uCpKnW_panelHeading {\n  justify-content: space-between;\n  align-items: center;\n  gap: 16px;\n  margin: 0 0 14px;\n  display: flex;\n}\n\n.uCpKnW_panelHeading h3 {\n  margin: 0;\n  font-size: 14px;\n  font-weight: 550;\n}\n\n.uCpKnW_mcpRow {\n  border-top: 1px solid var(--workbench-border, #dfe1e6);\n  align-items: center;\n  gap: 14px;\n  padding: 12px 0;\n  display: flex;\n}\n\n.uCpKnW_mcpRow strong {\n  font-weight: 550;\n}\n\n.uCpKnW_badge {\n  background: var(--workbench-hover, #f5f6f7);\n  color: var(--workbench-muted, #69717c);\n  white-space: nowrap;\n  border-radius: 3px;\n  margin-left: 8px;\n  padding: 1px 5px;\n  font-size: 11px;\n}\n\n.uCpKnW_state {\n  color: var(--workbench-muted, #69717c);\n  white-space: nowrap;\n  font-size: 12px;\n}\n\n.uCpKnW_workspace .uCpKnW_textButton {\n  color: var(--workbench-muted, #69717c);\n  border: 0;\n  padding: 6px;\n}\n\n.uCpKnW_workspace .uCpKnW_danger {\n  color: var(--workbench-danger, #b42318);\n}\n\n.uCpKnW_menu {\n  position: relative;\n}\n\n.uCpKnW_menu > summary {\n  cursor: pointer;\n  border-radius: 8px;\n  padding: 4px 8px;\n  font-size: 20px;\n  list-style: none;\n}\n\n.uCpKnW_menu > summary::-webkit-details-marker {\n  display: none;\n}\n\n.uCpKnW_menuItems {\n  z-index: 2;\n  border: 1px solid var(--workbench-border, #dfe1e6);\n  background: var(--workbench-bg, #fff);\n  border-radius: 10px;\n  min-width: 176px;\n  padding: 6px;\n  position: absolute;\n  top: 100%;\n  right: 0;\n  box-shadow: 0 4px 14px #0002;\n}\n\n.uCpKnW_menuItems button {\n  text-align: left;\n  border: 0;\n  width: 100%;\n  display: block;\n}\n\n.uCpKnW_modeTabs {\n  gap: 4px;\n  margin: 0 0 12px;\n  display: flex;\n}\n\n.uCpKnW_modeTabs button[aria-pressed=\"true\"] {\n  background: var(--workbench-hover, #f5f6f7);\n}\n\n@media (width <= 650px) {\n  .uCpKnW_workspace {\n    padding: 24px 18px;\n  }\n\n  .uCpKnW_workspace.uCpKnW_settingsWorkspace {\n    padding: 16px 0 0;\n  }\n\n  .uCpKnW_heading, .uCpKnW_row {\n    gap: 10px;\n  }\n\n  .uCpKnW_heading {\n    flex-wrap: wrap;\n  }\n\n  .uCpKnW_heading > .uCpKnW_title {\n    min-width: 120px;\n  }\n\n  .uCpKnW_row .uCpKnW_icon {\n    width: 42px;\n    height: 44px;\n  }\n}\n\n.uCpKnW_source {\n  border-bottom: 1px solid var(--workbench-border, #dfe1e6);\n  padding: 16px 0;\n}\n\n.uCpKnW_source p {\n  margin: 4px 0;\n}\n\n.uCpKnW_sourceAddress {\n  overflow-wrap: anywhere;\n}\n\n.uCpKnW_sourceFields {\n  border: 0;\n  min-width: 0;\n  margin: 0;\n  padding: 16px 0 0;\n}\n\n.uCpKnW_sourceFields legend {\n  padding: 0;\n  font-weight: 600;\n}\n\n.uCpKnW_sourceFields select {\n  font: inherit;\n  color: inherit;\n  background: var(--workbench-bg, #fff);\n  border: 1px solid var(--workbench-border, #dfe1e6);\n  border-radius: 8px;\n  margin-top: 6px;\n  padding: 8px 10px;\n  display: block;\n}\n\n.uCpKnW_sourceFields select:focus-visible {\n  outline-offset: 2px;\n  outline: 2px solid #4c8dff;\n}\n\n.uCpKnW_conflictValues {\n  grid-template-columns: repeat(3, minmax(0, 1fr));\n  gap: 12px;\n  display: grid;\n}\n\n.uCpKnW_conflictValues pre {\n  white-space: pre-wrap;\n  overflow-wrap: anywhere;\n  max-height: 240px;\n  font: inherit;\n  overflow: auto;\n}\n\n@media (width <= 700px) {\n  .uCpKnW_conflictValues {\n    grid-template-columns: 1fr;\n  }\n}\n\n.uCpKnW_workspace .uCpKnW_iconButton {\n  width: 32px;\n  height: 32px;\n  color: var(--workbench-muted, #69717c);\n  border: 0;\n  flex-shrink: 0;\n  justify-content: center;\n  align-items: center;\n  padding: 0;\n  display: inline-flex;\n}\n\n.uCpKnW_sourceInfo {\n  color: var(--workbench-muted, #69717c);\n  margin: 6px;\n  font-size: 12px;\n}\n\n.uCpKnW_sourceInfo summary {\n  cursor: pointer;\n  font-size: 13px;\n}\n\n.uCpKnW_sourceInfo dd {\n  overflow-wrap: anywhere;\n  margin: 0 0 8px;\n}\n.G-7KhG_dialog[role=\"dialog\"] {\n  box-sizing: border-box;\n  width: min(1120px, 100vw - 48px);\n  max-width: calc(100vw - 48px);\n  max-height: calc(100dvh - 48px);\n}\n\n.G-7KhG_body {\n  overflow-wrap: anywhere;\n  min-width: 0;\n  min-height: 0;\n  max-height: calc(100dvh - 200px);\n  overflow-y: auto;\n}\n\n.G-7KhG_modes {\n  flex-wrap: wrap;\n  gap: 4px;\n  margin-bottom: 12px;\n  display: flex;\n}\n\n.G-7KhG_footer {\n  justify-content: flex-end;\n  align-items: center;\n  gap: 8px;\n  width: 100%;\n  display: flex;\n}\n\n.G-7KhG_footer > :first-child {\n  flex: 1;\n}\n\n.G-7KhG_footerSlot:empty {\n  display: none;\n}\n\n.G-7KhG_mode {\n  border: 1px solid var(--workbench-border);\n  color: var(--workbench-body);\n  font: inherit;\n  cursor: pointer;\n  background: none;\n  border-radius: 4px;\n  padding: 6px 12px;\n}\n\n.G-7KhG_mode[aria-pressed=\"true\"] {\n  background: var(--workbench-brand-soft);\n  color: var(--workbench-text);\n}\n\n.G-7KhG_mode:focus-visible, .G-7KhG_raw:focus-visible {\n  outline: 2px solid var(--workbench-brand);\n  outline-offset: 2px;\n}\n\n.G-7KhG_raw {\n  box-sizing: border-box;\n  resize: vertical;\n  border: 1px solid var(--workbench-border);\n  width: 100%;\n  min-height: 320px;\n  color: var(--workbench-text);\n  background: var(--workbench-surface);\n  border-radius: 6px;\n  padding: 12px;\n  font: 13px / 1.6 ui-monospace, monospace;\n}\n\n.G-7KhG_section {\n  min-width: 0;\n  margin: 0 0 16px;\n}\n\n.G-7KhG_heading {\n  font-size: calc(var(--workbench-font-size) * 13 / 14);\n  margin: 0 0 8px;\n  font-weight: 600;\n}\n\n.G-7KhG_metadata {\n  font-size: calc(var(--workbench-font-size) * 13 / 14);\n  grid-template-columns: minmax(100px, 180px) minmax(0, 1fr);\n  margin: 0;\n  display: grid;\n}\n\n.G-7KhG_metadata dt, .G-7KhG_metadata dd {\n  border-bottom: 1px solid var(--workbench-border);\n  min-width: 0;\n  margin: 0;\n  padding: 8px 0;\n}\n\n.G-7KhG_metadata dt {\n  color: var(--workbench-body);\n  padding-right: 12px;\n}\n\n.G-7KhG_metadata dd {\n  color: var(--workbench-text);\n}\n\n.G-7KhG_values {\n  flex-wrap: wrap;\n  gap: 6px;\n  display: flex;\n}\n\n.G-7KhG_value {\n  background: var(--workbench-hover);\n  border-radius: 4px;\n  max-width: 100%;\n  padding: 2px 6px;\n}\n\n.G-7KhG_preview {\n  min-width: 0;\n  color: var(--workbench-text);\n  font-size: var(--workbench-font-size);\n  line-height: 1.6;\n}\n\n.G-7KhG_preview pre, .G-7KhG_preview table {\n  max-width: 100%;\n  overflow: auto;\n}\n\n.G-7KhG_preview img {\n  max-width: 100%;\n  height: auto;\n}\n\n.G-7KhG_error {\n  color: var(--dsw-alias-state-error-primary);\n  font-size: calc(var(--workbench-font-size) * 13 / 14);\n  margin: 8px 0;\n}\n\n.G-7KhG_form {\n  grid-template-columns: repeat(2, minmax(0, 1fr));\n  gap: 16px;\n  display: grid;\n}\n\n.G-7KhG_field {\n  min-width: 0;\n  font-size: calc(var(--workbench-font-size) * 13 / 14);\n  flex-direction: column;\n  gap: 6px;\n  display: flex;\n}\n\n.G-7KhG_field input, .G-7KhG_field select, .G-7KhG_field textarea {\n  box-sizing: border-box;\n  min-width: 0;\n  max-width: 100%;\n  color: var(--workbench-text);\n  background: var(--workbench-surface);\n  border: 1px solid var(--workbench-border);\n  font: inherit;\n  border-radius: 4px;\n  padding: 8px;\n}\n\n.G-7KhG_wide {\n  grid-column: 1 / -1;\n}\n\n.G-7KhG_rows {\n  flex-direction: column;\n  gap: 6px;\n  min-width: 0;\n  display: flex;\n}\n\n.G-7KhG_row {\n  align-items: center;\n  gap: 6px;\n  min-width: 0;\n  display: flex;\n}\n\n.G-7KhG_row input {\n  flex: 1;\n  width: 0;\n}\n\n.G-7KhG_row button {\n  flex: none;\n}\n\n.G-7KhG_rows > button {\n  align-self: flex-start;\n}\n\n@media (width <= 640px) {\n  .G-7KhG_dialog[role=\"dialog\"] {\n    width: calc(100vw - 16px);\n    max-width: calc(100vw - 16px);\n    max-height: calc(100dvh - 16px);\n  }\n\n  .G-7KhG_form {\n    grid-template-columns: minmax(0, 1fr);\n  }\n\n  .G-7KhG_metadata {\n    grid-template-columns: minmax(80px, 30%) minmax(0, 1fr);\n  }\n}\n.UsIx-W_switchOn, .UsIx-W_switchOff {\n  cursor: pointer;\n  border: none;\n  border-radius: 999px;\n  flex-shrink: 0;\n  width: 38px;\n  height: 22px;\n  padding: 0;\n  transition: background-color .15s;\n  position: relative;\n}\n\n.UsIx-W_switchOn {\n  background: var(--dsw-alias-button-primary-fill, var(--workbench-brand));\n}\n\n.UsIx-W_switchOff {\n  background: var(--dsw-alias-label-dimmed, #e1e5ee);\n}\n\n.UsIx-W_switchOn:disabled, .UsIx-W_switchOff:disabled {\n  opacity: .6;\n  cursor: default;\n}\n\n.UsIx-W_switchThumb {\n  pointer-events: none;\n  background: #fff;\n  border-radius: 50%;\n  width: 16px;\n  height: 16px;\n  transition: left .15s;\n  position: absolute;\n  top: 3px;\n  left: 3px;\n  box-shadow: 0 1px 2px #0003;\n}\n\n.UsIx-W_switchOn .UsIx-W_switchThumb {\n  left: 19px;\n}\n\n@media (prefers-reduced-motion: reduce) {\n  .UsIx-W_switchOn, .UsIx-W_switchOff, .UsIx-W_switchThumb {\n    transition: none;\n  }\n}\n\n.UsIx-W_pluginCard {\n  border: 1px solid var(--workbench-border);\n  background: var(--dsw-alias-bg-layer-3, #fff);\n  border-radius: 12px;\n  list-style: none;\n  transition: border-color .16s, background .16s;\n  container: UsIx-W_market-config / inline-size;\n}\n\n.UsIx-W_pluginCard:hover {\n  border-color: var(--dsw-alias-label-dimmed, #c8ccd4);\n}\n\n.UsIx-W_pluginCardOpen {\n  background: var(--workbench-subtle);\n  border-color: var(--dsw-alias-label-dimmed, #c8ccd4);\n}\n\n.UsIx-W_pluginCard[data-busy=\"true\"] {\n  opacity: .6;\n  pointer-events: none;\n}\n\n.UsIx-W_pluginCardHeader {\n  appearance: none;\n  width: 100%;\n  font: inherit;\n  color: inherit;\n  text-align: left;\n  cursor: pointer;\n  background: none;\n  border: 0;\n  border-radius: 12px;\n  align-items: center;\n  gap: 12px;\n  padding: 14px 16px;\n  display: flex;\n}\n\n.UsIx-W_pluginCardHeader:focus-visible {\n  outline: 2px solid var(--workbench-brand);\n  outline-offset: -2px;\n}\n\n.UsIx-W_pluginCardBody {\n  border-top: 1px solid var(--workbench-border);\n  flex-direction: column;\n  gap: 8px;\n  margin: 0 16px;\n  padding: 4px 0 8px;\n  display: flex;\n}\n\n.UsIx-W_pluginCardRow {\n  justify-content: space-between;\n  align-items: center;\n  gap: 16px;\n  padding: 8px 0 4px;\n  display: flex;\n}\n\n.UsIx-W_pluginCardText {\n  flex-direction: column;\n  flex: 1;\n  gap: 4px;\n  min-width: 0;\n  display: flex;\n}\n\n.UsIx-W_pluginCardTitle {\n  color: var(--workbench-text);\n  font-size: calc(var(--workbench-font-size) * 15 / 14);\n  font-weight: 600;\n  line-height: 1.4;\n}\n\n.UsIx-W_pluginCardDesc {\n  color: var(--workbench-muted);\n  font-size: calc(var(--workbench-font-size) * 13 / 14);\n  line-height: 1.5;\n}\n\n.UsIx-W_pluginCardRowLabel {\n  font-size: calc(var(--workbench-font-size) * 13 / 14);\n  font-weight: 500;\n  line-height: 20px;\n}\n\n@container UsIx-W_market-config (width <= 320px) {\n  .UsIx-W_pluginCardRow {\n    flex-direction: column;\n    align-items: flex-start;\n    gap: 8px;\n  }\n\n  .UsIx-W_pluginCardText {\n    overflow-wrap: anywhere;\n    width: 100%;\n  }\n\n  .UsIx-W_regionSeg {\n    flex-wrap: wrap;\n    max-width: 100%;\n  }\n}\n\n.UsIx-W_pluginCardError {\n  color: var(--dsw-alias-state-error-primary, #dc2626);\n  font-size: calc(var(--workbench-font-size) * 12 / 14);\n  margin: 0;\n  line-height: 1.5;\n}\n\n.UsIx-W_pluginChevron {\n  color: var(--workbench-muted);\n  flex: none;\n  transition: transform .16s;\n  display: inline-flex;\n}\n\n.UsIx-W_pluginChevronOpen {\n  transform: rotate(180deg);\n}\n\n.UsIx-W_regionSeg {\n  border: 1px solid var(--workbench-border);\n  border-radius: 8px;\n  flex: none;\n  gap: 2px;\n  padding: 2px;\n  display: inline-flex;\n}\n\n.UsIx-W_regionSegBtn {\n  appearance: none;\n  font: inherit;\n  color: var(--workbench-body);\n  cursor: pointer;\n  font-size: calc(var(--workbench-font-size) * 12 / 14);\n  background: none;\n  border: none;\n  border-radius: 6px;\n  padding: 3px 10px;\n  line-height: 18px;\n}\n\n.UsIx-W_regionSegOn {\n  appearance: none;\n  font: inherit;\n  cursor: pointer;\n  font-size: calc(var(--workbench-font-size) * 12 / 14);\n  background: var(--workbench-subtle);\n  color: var(--workbench-text);\n  border: none;\n  border-radius: 6px;\n  padding: 3px 10px;\n  font-weight: 600;\n  line-height: 18px;\n}\n\n.UsIx-W_regionSegBtn:disabled, .UsIx-W_regionSegOn:disabled {\n  cursor: default;\n  opacity: .5;\n}\n";
Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
//#region \0rolldown/runtime.js
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
	if (from && typeof from === "object" || typeof from === "function") for (var keys = __getOwnPropNames(from), i = 0, n = keys.length, key; i < n; i++) {
		key = keys[i];
		if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
			get: ((k) => from[k]).bind(null, key),
			enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
		});
	}
	return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule || !__hasOwnProp.call(mod, "default") ? __defProp(target, "default", {
	value: mod,
	enumerable: true
}) : target, mod));
//#endregion
let react = require("react");
react = __toESM(react, 1);
let react_dom_client = require("react-dom/client");
let _deepseek_ai_dsh_client_ui_primitives = require("@deepseek-ai/dsh-client-ui-primitives");
_deepseek_ai_dsh_client_ui_primitives = __toESM(_deepseek_ai_dsh_client_ui_primitives, 1);
let react_jsx_runtime = require("react/jsx-runtime");
//#region src/client/ui/busy-operation.ts
const pending = /* @__PURE__ */ new Map();
const listeners = /* @__PURE__ */ new Set();
let nextId = 0;
let snapshot = [];
/** 将当前租约快照广播给所有订阅者，驱动共享遮罩刷新。 */
function publish() {
	snapshot = [...pending.values()];
	listeners.forEach((listener) => listener());
}
/** 选择最上层可见对话框，否则退回工作区根节点作为遮罩目标。 */
function operationTarget() {
	if (typeof document === "undefined") return null;
	return [...document.querySelectorAll("[role=\"dialog\"]")].filter((node) => node.getClientRects().length > 0).at(-1) ?? document.querySelector("[data-agent-plugins-workspace]");
}
/** 创建一笔独立租约并返回幂等释放函数，避免并发请求互相结束遮罩。 */
function beginBusyOperation(target = operationTarget()) {
	const id = ++nextId;
	pending.set(id, {
		id,
		target
	});
	publish();
	return () => {
		if (pending.delete(id)) publish();
	};
}
/** 用租约包裹异步工作，保证成功和异常路径都会释放忙碌状态。 */
async function withBusyOperation(work) {
	const end = beginBusyOperation();
	try {
		return await work();
	} finally {
		end();
	}
}
/** 注册外部订阅者，并返回移除订阅的清理函数。 */
function subscribeBusy(listener) {
	listeners.add(listener);
	return () => {
		listeners.delete(listener);
	};
}
/** 返回 React 外部 store 所需的稳定只读租约快照。 */
function busySnapshot() {
	return snapshot;
}
//#endregion
//#region src/client/ui/busy-overlay.module.css
var busy_overlay_module_default = {
	"busy-enter": "_6K1mgq_busy-enter",
	"busy-hint": "_6K1mgq_busy-hint",
	"busy-spin": "_6K1mgq_busy-spin",
	"content": "_6K1mgq_content",
	"hint": "_6K1mgq_hint",
	"hintViewport": "_6K1mgq_hintViewport",
	"label": "_6K1mgq_label",
	"overlay": "_6K1mgq_overlay",
	"spinner": "_6K1mgq_spinner"
};
/** Mount once per client. A body-level host covers portaled dialogs without inheriting their inert state. */
/** 中文：每个客户端只挂载一次，body 级宿主可覆盖 portal 弹窗且不继承其 inert。 */
/** 订阅共享忙碌租约，处理延迟显示、最短显示时长和目标元素保留。 */
function BusyOverlay({ t }) {
	const tasks = (0, react.useSyncExternalStore)(subscribeBusy, busySnapshot, busySnapshot);
	const target = [...tasks].reverse().find((task) => task.target?.isConnected)?.target ?? (tasks.length ? operationTarget() : null);
	const [heldTarget, setHeldTarget] = (0, react.useState)(null);
	const [visible, setVisible] = (0, react.useState)(false);
	const startedAt = (0, react.useRef)(null);
	const shownAt = (0, react.useRef)(null);
	const active = tasks.length > 0;
	/** 根据共享租约延迟显示或收起遮罩，并在租约切换时保留正确的定位目标。 */
	(0, react.useLayoutEffect)(() => {
		let timer;
		if (active && target) {
			setHeldTarget(target);
			startedAt.current ??= Date.now();
			if (shownAt.current === null) timer = setTimeout(() => {
				shownAt.current = Date.now();
				setVisible(true);
			}, Math.max(0, 200 - (Date.now() - startedAt.current)));
		} else {
			/** 清除当前遮罩的计时和目标，避免下一次操作继承旧状态。 */
			const clear = () => {
				startedAt.current = null;
				shownAt.current = null;
				setVisible(false);
				setHeldTarget(null);
			};
			if (shownAt.current === null) clear();
			else timer = setTimeout(clear, Math.max(100, 400 - (Date.now() - shownAt.current)));
		}
		return () => {
			if (timer !== void 0) clearTimeout(timer);
		};
	}, [active, target]);
	const displayedTarget = target ?? (heldTarget?.isConnected ? heldTarget : null);
	return displayedTarget && (active || visible) ? (0, react.createElement)(ActiveOverlay, {
		target: displayedTarget,
		t,
		visible
	}) : null;
}
/** 将遮罩定位到目标元素，并负责 inert、焦点陷阱和事件拦截的生命周期。 */
function ActiveOverlay({ target, t, visible }) {
	const ref = (0, react.useRef)(null);
	const [rect, setRect] = (0, react.useState)(() => target.getBoundingClientRect());
	const [message, setMessage] = (0, react.useState)(0);
	const hints = [
		t("busyHintProcessing"),
		t("busyHintRefresh"),
		t("busyHintWaiting")
	];
	/** 遮罩可见时轮换进度提示，隐藏后释放定时器。 */
	(0, react.useEffect)(() => {
		if (!visible) return;
		const timer = setInterval(() => setMessage((value) => (value + 1) % hints.length), 3200);
		return () => clearInterval(timer);
	}, [hints.length, visible]);
	/** 为目标区域设置 inert 和事件拦截，并跟随弹窗尺寸、位置及焦点变化。 */
	(0, react.useLayoutEffect)(() => {
		const previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
		const inertBefore = target.hasAttribute("inert");
		const busyBefore = target.getAttribute("aria-busy");
		target.setAttribute("inert", "");
		target.setAttribute("aria-busy", "true");
		const scope = target.closest("[role=\"presentation\"]") ?? target;
		/** 阻止遮罩目标内的交互事件，避免忙碌期间重复提交或关闭弹窗。 */
		const stop = (event) => {
			if (ref.current?.contains(event.target)) return;
			if (event instanceof KeyboardEvent || scope.contains(event.target)) {
				event.preventDefault();
				event.stopImmediatePropagation();
			}
		};
		/** 将误入被锁定区域的焦点拉回遮罩，维持忙碌期间的焦点陷阱。 */
		const trapFocus = (event) => {
			if (scope.contains(event.target)) ref.current?.focus({ preventScroll: true });
		};
		/** 重新测量目标边界，供遮罩定位并避免无实际变化的状态更新。 */
		const update = () => {
			const next = target.getBoundingClientRect();
			setRect((previous) => previous.top === next.top && previous.left === next.left && previous.width === next.width && previous.height === next.height ? previous : next);
		};
		let frame = 0;
		/** 用动画帧跟随 transform 位移；尺寸变化由 ResizeObserver 处理。 */
		const follow = () => {
			update();
			frame = requestAnimationFrame(follow);
		};
		if (typeof requestAnimationFrame !== "undefined") frame = requestAnimationFrame(follow);
		const observer = typeof ResizeObserver === "undefined" ? void 0 : new ResizeObserver(update);
		observer?.observe(target);
		window.addEventListener("resize", update);
		window.addEventListener("scroll", update, true);
		for (const event of [
			"pointerdown",
			"click",
			"keydown",
			"submit"
		]) window.addEventListener(event, stop, true);
		window.addEventListener("focusin", trapFocus, true);
		ref.current?.focus({ preventScroll: true });
		update();
		return () => {
			if (frame) cancelAnimationFrame(frame);
			observer?.disconnect();
			window.removeEventListener("resize", update);
			window.removeEventListener("scroll", update, true);
			for (const event of [
				"pointerdown",
				"click",
				"keydown",
				"submit"
			]) window.removeEventListener(event, stop, true);
			window.removeEventListener("focusin", trapFocus, true);
			if (!inertBefore) target.removeAttribute("inert");
			if (busyBefore === null) target.removeAttribute("aria-busy");
			else target.setAttribute("aria-busy", busyBefore);
			if (previousFocus?.isConnected && !previousFocus.closest("[inert]")) previousFocus.focus({ preventScroll: true });
		};
	}, [target]);
	return (0, react.createElement)("div", {
		ref,
		className: busy_overlay_module_default.overlay,
		tabIndex: -1,
		"data-operation-overlay": true,
		"data-visible": visible,
		role: "status",
		"aria-live": "polite",
		"aria-label": t("panelWorking"),
		style: {
			top: rect.top,
			left: rect.left,
			width: rect.width,
			height: rect.height,
			borderRadius: getComputedStyle(target).borderRadius
		},
		onKeyDown: (event) => {
			event.preventDefault();
			event.stopPropagation();
		}
	}, visible ? (0, react.createElement)("div", { className: busy_overlay_module_default.content }, (0, react.createElement)("span", {
		className: busy_overlay_module_default.spinner,
		"aria-hidden": true
	}, (0, react.createElement)(_deepseek_ai_dsh_client_ui_primitives.IconLoadingOutlineRegular, { size: 28 })), (0, react.createElement)("strong", { className: busy_overlay_module_default.label }, t("panelWorking")), (0, react.createElement)("div", { className: busy_overlay_module_default.hintViewport }, (0, react.createElement)("p", {
		key: message,
		className: busy_overlay_module_default.hint
	}, hints[message]))) : null);
}
//#endregion
//#region src/contracts/market.ts
/** 文件作用：定义市场 HTTP 路由、请求载荷和响应记录等主机/客户端共用契约。 */
/** Browser-safe market wire records and route constants shared by host and client. */
/** 中文：定义主机与客户端共用的市场路由、请求载荷和响应记录。 */
/** Prefix for all Agent Plugins Market HTTP routes. */
/** 中文：所有 Agent Plugins Market HTTP 路由共用的前缀。 */
const MARKET_API_PREFIX = "/api/agent-plugins/";
/** Fixed Agent Plugins Market HTTP routes. */
/** 中文：集中维护市场各功能的固定 HTTP 路由，避免客户端和主机拼接不一致。 */
const MARKET_ROUTES = {
	modelCatalog: `${MARKET_API_PREFIX}model-catalog`,
	mcpBackend: `${MARKET_API_PREFIX}mcp-backend`
};
//#endregion
//#region src/client/api.ts
/** 查询当前使用的 MCP 后端、宿主客户端可用性和下载区域。 */
async function fetchMcpBackend() {
	const response = await fetch(MARKET_ROUTES.mcpBackend, { credentials: "same-origin" });
	if (!response.ok) throw new Error(`mcp backend failed: ${response.status}`);
	return response.json();
}
//#endregion
//#region src/client/locales.ts
/** Chinese is the source-of-truth key set; English is checked against it below. */
/** 中文字典是键集合的事实来源，英文集合在文件末尾做一致性校验。 */
const zh = {
	agentSourcePreviewStale: "配置或预览已变化。请取消本次预览，再重新检查并同步。",
	agentSourceCurrent: "配置来源没有新变化。",
	agentUpdate: "更新",
	agentSourceSync: "检查并同步",
	agentSourceUpdated: "配置已更新，后续新会话将使用新版本。",
	agentSourceConflicts: "处理配置冲突",
	agentSourceConflictHelp: "来源与个人配置均有修改。选择每项的结果后应用；取消保留原配置。MCP 凭据仅显示脱敏值。",
	agentSourceResolveAll: "请处理每项冲突。",
	agentSourceBase: "导入基线",
	agentSourceLocal: "个人配置",
	agentSourceUpstream: "来源更新",
	agentSourceResolution: "处理方式",
	agentSourceChoose: "请选择",
	agentSourceKeepLocal: "保留本地",
	agentSourceUseUpstream: "采用上游",
	agentSourceManual: "手动合并",
	agentSourceMerged: "合并结果（Skill 与 MCP 使用 JSON）",
	agentSourceApply: "应用更新",
	agentSourceIncomplete: "导入尚未完成，请在配置来源中重新导入以继续。",
	agentSourceSkillDisabled: "来源 Skill 已停用，请先恢复该依赖，再重新导入。",
	agentSourceUnsupported: "此来源还包含命令、Hook 或 LSP，不能作为完整 Agent 导入。",
	agentSourceRoleRestricted: "此角色包含模型或工具限制，请手工配置并核对这些限制。",
	agentSourceRemote: "请先将此引用的仓库添加为配置来源。",
	agentSources: "配置来源",
	agentSourcesHelp: "从 Git、本地目录或配置包读取 Agent，导入后可独立定制。",
	agentSourceAdd: "添加配置来源",
	agentSourceKind: "来源类型",
	agentSourceAddress: "地址或目录",
	agentSourceBranch: "分支（可选）",
	agentSourceRead: "读取配置",
	agentSourceReading: "正在读取…",
	agentSourceImport: "导入 Agent",
	agentSourceImported: "Agent 已导入，可在列表中配置和使用。",
	agentSourceNoAgents: "此来源未发现可导入的提示词或 Agent。",
	agentSourceCustomized: "有个人修改",
	agentSourceUnmodified: "与导入版本一致",
	agentDeleted: "已删除，可恢复",
	agentRecovery: "配置恢复",
	agentDelete: "删除个人 Agent",
	agentDeleteConfirm: "确认删除",
	agentDeleteConfirmation: "此 Agent 将从新任务中撤下。历史会话、草稿和可恢复配置会保留。",
	agentRestore: "恢复配置",
	agentEnableRecovery: "启用并检查依赖",
	agentChooseAnother: "返回列表，选择其他 Agent",
	agentDefaultUnavailable: "新任务默认值仍指向此 Agent。请恢复此配置，或在宿主设置中显式选择其他默认 Agent。",
	agentDeletedRecovery: "此 Agent 已删除。先恢复配置，再检查依赖并启用，才能恢复原会话。",
	agentDisabledRecovery: "此 Agent 已停用。历史会话和草稿保留；冷启动恢复前须显式启用。",
	agentDependencyRecovery: "配置依赖暂不可用。请按上方错误恢复来源或修正配置，再检查并启用；也可另选 Agent 新建对话。",
	agentColdRecoveryLimit: "运行中的会话保留原修订。重启恢复使用保留的当前配置，无法还原过去的修订；不会自动更换历史会话的 Agent。",
	agentMcpExisting: "使用已有连接",
	agentMcpNew: "创建新连接",
	agentCubeTitle: "GEA Cube",
	agentCubeScope: "沿当前 GEA 登录身份与业务授权查询。每个 Agent 可选择一个插件来源。",
	agentCubeSource: "插件来源",
	agentCubeNone: "不使用 Cube",
	agentCubeEnable: "启用 Cube",
	agentCubeDisable: "停用 Cube",
	agentCubeEnabled: "启用 {name} 的 Cube",
	agentPluginPresets: "插件预设",
	agentPluginMcpFixed: "MCP 成员由插件提供，只能启停。需要增删时请复制为个人 Agent。",
	agentCopyPersonal: "复制为个人 Agent",
	"agentMcpUsed": "使用的 MCP",
	"agentMcpAdd": "添加 MCP",
	"agentMcpUser": "用户添加",
	"agentMcpPlugin": "插件提供",
	"agentMcpRemove": "移除关联",
	"agentMcpEmpty": "尚未关联 MCP",
	"agentMcpName": "显示名称",
	"agentMcpServerId": "服务标识",
	"agentMcpCredentials": "密钥使用 DSH 凭据引用，例如 ${API_TOKEN}。编辑共享连接会更新所有引用；移除仅影响当前 Agent。",
	"agentMcpState_saved": "已保存，未连接",
	"agentMcpState_connecting": "连接中",
	"agentMcpState_connected": "已连接",
	"agentMcpState_failed": "连接失败",
	"agentMcpState_disabled": "已停用",
	"agentMcpState_needs-credentials": "需要凭据",
	"agentMcpState_awaiting-authorization": "等待浏览器授权",
	"agentMcpState_authorization-cancelled": "授权已取消，可重新授权",
	"agentMcpState_authorization-failed": "授权失败，请重新授权",
	agentMcpCancelAuthorization: "取消授权",
	agentSourceInfo: "来源信息",
	agentSourceVersion: "配置版本",
	agentMore: "更多操作",
	agentMcpExternal: "外部 MCP",
	agentStateEnabled: "已启用",
	agentStateDisabled: "已停用",
	agentConfiguration: "Agent 配置",
	agentAdd: "＋ 添加 Agent",
	agentCurrent: "当前 Agent",
	agentName: "名称",
	agentDescription: "描述",
	agentPrompt: "提示词",
	agentSkill: "Skill",
	agentSkillEdit: "编辑",
	agentSkillAdd: "＋ 添加 Skill",
	agentSkillEmpty: "此 Agent 尚未添加 Skill。",
	agentSkillExisting: "选择已有 Skill",
	agentSkillPersonal: "创建个人 Skill",
	agentSkillChoose: "请选择 Skill",
	agentSkillDuplicate: "此 Agent 已使用这个 Skill。",
	agentSkillName: "Skill 名称（小写字母、数字和连字符）",
	agentSkillContent: "Skill 正文",
	agentSkillOverride: "修改仅保存到此 Agent 的个人配置。",
	agentMcp: "MCP",
	agentBack: "‹ 返回 Agent 列表",
	agentPersonal: "我的配置",
	agentEnabled: "启用 {name}",
	agentStart: "开始使用",
	agentEmpty: "暂无 Agent",
	agentSaved: "配置已保存",
	agentSavedUnavailable: "配置已保存，预设暂不可用，请修正后重试。",
	agentUnavailable: "预设不可用",
	agentHostUnavailable: "原生会话入口尚未就绪，请稍后重试。",
	agentNotDelivered: "此配置将在后续切片接入。",
	nav: "Agent 配置",
	detailPreview: "预览",
	detailMarkdown: "Markdown 编辑",
	detailMetadata: "元数据",
	detailForm: "表单",
	detailJson: "JSON",
	detailInvalidJson: "JSON 无效",
	detailUseJson: "当前字段类型无法使用表单，请在 JSON 中修正。",
	detailTransport: "传输协议",
	detailCommand: "启动命令",
	detailArgs: "启动参数",
	detailEnv: "环境变量",
	detailUrl: "服务 URL",
	detailHeaders: "HTTP 请求头",
	detailCwd: "工作目录",
	detailScope: "OAuth scope",
	detailExtensions: "扩展名与语言映射",
	detailKey: "键",
	detailValue: "值",
	detailUniqueKeys: "键不能为空或重复",
	sourceUrlPh: "git 仓库地址",
	sourceUrlLocalPh: "本地仓库路径（绝对路径或 ~/…）",
	sourceUrlArchivePh: "压缩包地址（.zip / .tar.gz）",
	sourceModeGit: "远程 git",
	sourceModeArchive: "压缩包",
	sourceModeLocal: "本地目录",
	save: "保存",
	detailTitle: "Agent Plugins 详情",
	agentsSection: "子代理",
	detailHint: "点击技能或 MCP 服务行可展开查看详情",
	remove: "移除",
	refresh: "刷新",
	cancel: "取消",
	mcpReauthorize: "重新授权",
	marketCardDesc: "Agent 配置、原生预设及 MCP 运行设置。",
	mcpCardTitle: "MCP 增强模式",
	mcpCardDescOn: "已开启：支持 OAuth 授权、SSE、授权保持等功能。",
	mcpCardDescOff: "已关闭：使用宿主 dsh-mcp-client。",
	mcpCardReadonly: "当前环境设置文档只读，无法切换。",
	regionLabel: "下载区域",
	regionHint: "中国大陆走镜像线路，仅影响下载线路。",
	regionGlobal: "全球",
	regionChina: "中国大陆",
	mcpBackendHostMissing: "宿主 dsh-mcp-client 在当前环境不可用，无法切换到兼容模式。",
	panelWorking: "正在执行…",
	busyHintProcessing: "正在处理请求，请稍候。",
	busyHintRefresh: "操作完成后，将自动更新当前视图。",
	busyHintWaiting: "等待时间取决于本地服务和网络响应。",
	panelAdd: "新增",
	panelEditTitle: "编辑条目",
	panelDelete: "删除",
	feedbackToggleLabel: "体验反馈工具",
	projectLayoutsLabel: "扫描项目 Agent 布局",
	feedbackToggleDescOn: "已开启：Agent 遇到本插件的问题时可自动提交 issue 反馈。",
	feedbackToggleDescOff: "已关闭：Agent 无法自动提交反馈。"
};
const en = {
	agentSourcePreviewStale: "The configuration or preview changed. Cancel this preview, then check and sync again.",
	agentSourceCurrent: "The configuration source has no new changes.",
	agentUpdate: "Update",
	agentSourceSync: "Check and sync",
	agentSourceUpdated: "Configuration updated. New sessions will use the new revision.",
	agentSourceConflicts: "Resolve configuration conflicts",
	agentSourceConflictHelp: "Both the source and your configuration changed. Resolve each item, then apply. Cancel keeps your current configuration. MCP credentials are redacted.",
	agentSourceResolveAll: "Resolve every conflict.",
	agentSourceBase: "Imported baseline",
	agentSourceLocal: "Your configuration",
	agentSourceUpstream: "Source update",
	agentSourceResolution: "Resolution",
	agentSourceChoose: "Choose a resolution",
	agentSourceKeepLocal: "Keep local",
	agentSourceUseUpstream: "Use upstream",
	agentSourceManual: "Merge manually",
	agentSourceMerged: "Merged result (JSON for Skill and MCP)",
	agentSourceApply: "Apply update",
	agentSourceIncomplete: "Import is incomplete. Import it again from Configuration sources to continue.",
	agentSourceSkillDisabled: "Source Skills are disabled. Restore that dependency before importing again.",
	agentSourceUnsupported: "This source also contains commands, hooks or LSP and cannot be imported as a complete Agent.",
	agentSourceRoleRestricted: "This role declares model or tool restrictions. Configure it manually and preserve those restrictions.",
	agentSourceRemote: "Add the referenced repository as a configuration source first.",
	agentSources: "Configuration sources",
	agentSourcesHelp: "Read Agents from Git, a local directory or an archive. Imported Agents can be customized independently.",
	agentSourceAdd: "Add configuration source",
	agentSourceKind: "Source type",
	agentSourceAddress: "Address or directory",
	agentSourceBranch: "Branch (optional)",
	agentSourceRead: "Read configuration",
	agentSourceReading: "Reading…",
	agentSourceImport: "Import Agent",
	agentSourceImported: "Agent imported. Configure and use it from the list.",
	agentSourceNoAgents: "No importable prompts or Agents found in this source.",
	agentSourceCustomized: "Customized",
	agentSourceUnmodified: "Matches imported version",
	agentDeleted: "Deleted, recoverable",
	agentRecovery: "Configuration recovery",
	agentDelete: "Delete personal Agent",
	agentDeleteConfirm: "Confirm deletion",
	agentDeleteConfirmation: "This Agent will be removed from new tasks. History, drafts and recoverable configuration remain.",
	agentRestore: "Restore configuration",
	agentEnableRecovery: "Enable and check dependencies",
	agentChooseAnother: "Back to list, choose another Agent",
	agentDefaultUnavailable: "The new-task default still points to this Agent. Restore it or explicitly choose another default in host settings.",
	agentDeletedRecovery: "This Agent was deleted. Restore its configuration, then check dependencies and enable it to recover the original conversation.",
	agentDisabledRecovery: "This Agent is disabled. History and drafts remain; explicitly enable it before cold recovery.",
	agentDependencyRecovery: "A dependency is unavailable. Restore the source or edit the configuration using the error above, then check and enable it; or choose another Agent for a new conversation.",
	agentColdRecoveryLimit: "Live conversations keep their original revision. After restart, recovery uses the retained current configuration; older revisions cannot be reconstructed. Historical conversations never switch Agent automatically.",
	agentMcpExisting: "Use an existing connection",
	agentMcpNew: "Create a connection",
	agentCubeTitle: "GEA Cube",
	agentCubeScope: "Query with the current GEA identity and business permissions. Select one plugin source per Agent.",
	agentCubeSource: "Plugin source",
	agentCubeNone: "Do not use Cube",
	agentCubeEnable: "Enable Cube",
	agentCubeDisable: "Disable Cube",
	agentCubeEnabled: "Enable Cube for {name}",
	agentPluginPresets: "Plugin presets",
	agentPluginMcpFixed: "Plugin MCP membership is fixed. Enable or disable members here; make a personal copy to add or remove them.",
	agentCopyPersonal: "Copy as personal Agent",
	"agentMcpUsed": "Selected MCP servers",
	"agentMcpAdd": "Add MCP",
	"agentMcpUser": "User connection",
	"agentMcpPlugin": "Plugin connection",
	"agentMcpRemove": "Remove association",
	"agentMcpEmpty": "No MCP servers selected",
	"agentMcpName": "Display name",
	"agentMcpServerId": "Server identifier",
	"agentMcpCredentials": "Use DSH credential references such as ${API_TOKEN}. Editing a shared connection updates every reference; removing affects only this Agent.",
	"agentMcpState_saved": "Saved, disconnected",
	"agentMcpState_connecting": "Connecting",
	"agentMcpState_connected": "Connected",
	"agentMcpState_failed": "Connection failed",
	"agentMcpState_disabled": "Disabled",
	"agentMcpState_needs-credentials": "Credentials required",
	"agentMcpState_awaiting-authorization": "Waiting for browser authorization",
	"agentMcpState_authorization-cancelled": "Authorization cancelled; re-authorize to continue",
	"agentMcpState_authorization-failed": "Authorization failed; re-authorize to continue",
	agentMcpCancelAuthorization: "Cancel authorization",
	agentSourceInfo: "Source information",
	agentSourceVersion: "Configuration revision",
	agentMore: "More actions",
	agentMcpExternal: "External MCP",
	agentStateEnabled: "Enabled",
	agentStateDisabled: "Disabled",
	agentConfiguration: "Agent configuration",
	agentAdd: "+ Add Agent",
	agentCurrent: "Current Agents",
	agentName: "Name",
	agentDescription: "Description",
	agentPrompt: "Prompt",
	agentSkill: "Skill",
	agentSkillEdit: "Edit",
	agentSkillAdd: "＋ Add Skill",
	agentSkillEmpty: "This Agent has no selected Skills.",
	agentSkillExisting: "Choose an existing Skill",
	agentSkillPersonal: "Create a personal Skill",
	agentSkillChoose: "Select a Skill",
	agentSkillDuplicate: "This Agent already uses this Skill.",
	agentSkillName: "Skill name (lowercase letters, digits and hyphens)",
	agentSkillContent: "Skill instructions",
	agentSkillOverride: "Changes are saved only in this Agent personal configuration.",
	agentMcp: "MCP",
	agentBack: "‹ Back to Agents",
	agentPersonal: "My configuration",
	agentEnabled: "Enable {name}",
	agentStart: "Start chat",
	agentEmpty: "No Agents yet",
	agentSaved: "Configuration saved",
	agentSavedUnavailable: "Configuration saved. The preset is unavailable; correct the configuration and retry.",
	agentUnavailable: "Preset unavailable",
	agentHostUnavailable: "The native conversation entry is not ready. Please retry.",
	agentNotDelivered: "This configuration will be available in a later slice.",
	nav: "Agent configuration",
	detailPreview: "Preview",
	detailMarkdown: "Edit Markdown",
	detailMetadata: "Metadata",
	detailForm: "Form",
	detailJson: "JSON",
	detailInvalidJson: "Invalid JSON",
	detailUseJson: "These field types cannot be edited as a form. Correct them in JSON.",
	detailTransport: "Transport",
	detailCommand: "Command",
	detailArgs: "Arguments",
	detailEnv: "Environment variables",
	detailUrl: "Server URL",
	detailHeaders: "HTTP headers",
	detailCwd: "Working directory",
	detailScope: "OAuth scope",
	detailExtensions: "Extension-to-language mapping",
	detailKey: "Key",
	detailValue: "Value",
	detailUniqueKeys: "Keys must be non-empty and unique",
	sourceUrlPh: "git repository URL",
	sourceUrlLocalPh: "local repository path (absolute or ~/…)",
	sourceUrlArchivePh: "archive URL (.zip / .tar.gz)",
	sourceModeGit: "remote git",
	sourceModeArchive: "archive",
	sourceModeLocal: "local dir",
	save: "Save",
	detailTitle: "Suite details",
	agentsSection: "Subagents",
	detailHint: "Click a skill or MCP server row to expand its details",
	remove: "Remove",
	refresh: "Refresh",
	cancel: "Cancel",
	mcpReauthorize: "Re-authorize",
	marketCardDesc: "Agent configuration, native presets and MCP runtime settings.",
	mcpCardTitle: "MCP enhancement",
	mcpCardDescOn: "On: enables OAuth authorization, SSE, authorization hold, and more.",
	mcpCardDescOff: "Off: uses the host dsh-mcp-client.",
	mcpCardReadonly: "The settings document is read-only in this environment; the switch is unavailable.",
	regionLabel: "Download region",
	regionHint: "China mainland routes through a mirror. Affects the download route only.",
	regionGlobal: "Global",
	regionChina: "China mainland",
	mcpBackendHostMissing: "The host dsh-mcp-client is not available here; compat mode cannot be enabled.",
	panelWorking: "Working…",
	busyHintProcessing: "Your request is being processed. Please wait.",
	busyHintRefresh: "The current view will update when the operation finishes.",
	busyHintWaiting: "Waiting time depends on local services and network responses.",
	panelAdd: "Add",
	panelEditTitle: "Edit entry",
	panelDelete: "Delete",
	feedbackToggleLabel: "Experience feedback tool",
	projectLayoutsLabel: "Scan project Agent layouts",
	feedbackToggleDescOn: "On: the agent may auto-file an issue when it hits a problem in this plugin.",
	feedbackToggleDescOff: "Off: the agent cannot auto-file feedback."
};
//#endregion
//#region src/contracts/user-agents.ts
const USER_AGENT_ROUTES = {
	list: "/api/agent-manage/agents",
	pluginList: "/api/agent-manage/agents/plugins",
	pluginSave: "/api/agent-manage/agents/plugin/save",
	pluginSkills: "/api/agent-manage/agents/plugin/skills",
	pluginEnabled: "/api/agent-manage/agents/plugin/enabled",
	save: "/api/agent-manage/agents/save",
	enabled: "/api/agent-manage/agents/enabled",
	select: "/api/agent-manage/agents/select",
	remove: "/api/agent-manage/agents/remove",
	restore: "/api/agent-manage/agents/restore",
	skillCatalog: "/api/agent-manage/agents/skills/catalog",
	skillRead: "/api/agent-manage/agents/skills/read",
	skills: "/api/agent-manage/agents/skills/save",
	cubeSources: "/api/agent-manage/agents/cube/sources",
	cubeSave: "/api/agent-manage/agents/cube/save",
	cubeEnabled: "/api/agent-manage/agents/cube/enabled",
	pluginCopy: "/api/agent-manage/agents/plugin/copy"
};
//#endregion
//#region src/client/user-agent-api.ts
async function request$1(path, value, signal) {
	const response = await fetch(path, {
		method: value === void 0 ? "GET" : "POST",
		credentials: "same-origin",
		cache: "no-store",
		signal,
		...value === void 0 ? {} : {
			headers: { "content-type": "application/json" },
			body: JSON.stringify(value)
		}
	});
	const body = await response.json();
	if (!response.ok) throw Error(body.error ?? `HTTP ${response.status}`);
	return body;
}
const userAgentApi = {
	pluginAgents: () => request$1(USER_AGENT_ROUTES.pluginList),
	savePlugin: (id, prompt) => request$1(USER_AGENT_ROUTES.pluginSave, {
		id,
		prompt
	}),
	savePluginSkills: (id, skills, signal) => request$1(USER_AGENT_ROUTES.pluginSkills, {
		id,
		skills
	}, signal),
	setPluginEnabled: (id, enabled) => request$1(USER_AGENT_ROUTES.pluginEnabled, {
		id,
		enabled
	}),
	cubeSources: () => request$1(USER_AGENT_ROUTES.cubeSources),
	saveCube: (id, cube) => request$1(USER_AGENT_ROUTES.cubeSave, {
		id,
		cube
	}),
	setPluginCubeEnabled: (sourceRef, enabled) => request$1(USER_AGENT_ROUTES.cubeEnabled, {
		sourceRef,
		enabled
	}),
	copyPlugin: (sourceRef) => request$1(USER_AGENT_ROUTES.pluginCopy, { sourceRef }),
	list: () => request$1(USER_AGENT_ROUTES.list),
	skillCatalog: (signal) => request$1(USER_AGENT_ROUTES.skillCatalog, void 0, signal),
	readSkill: (skill, signal) => request$1(`${USER_AGENT_ROUTES.skillRead}?${new URLSearchParams({
		name: skill.name,
		provider: skill.provider,
		...skill.path ? { path: skill.path } : {}
	})}`, void 0, signal),
	saveSkills: (id, skills, signal) => request$1(USER_AGENT_ROUTES.skills, {
		id,
		skills
	}, signal),
	save: (value) => request$1(USER_AGENT_ROUTES.save, value),
	setEnabled: (id, enabled) => request$1(USER_AGENT_ROUTES.enabled, {
		id,
		enabled
	}),
	remove: (id) => request$1(USER_AGENT_ROUTES.remove, { id }),
	restore: (id) => request$1(USER_AGENT_ROUTES.restore, { id }),
	select: (id) => request$1(USER_AGENT_ROUTES.select, { id })
};
//#endregion
//#region src/contracts/agent-sources.ts
const AGENT_SOURCE_ROUTES = {
	list: "/api/agent-manage/agent-sources",
	acquire: "/api/agent-manage/agent-sources/acquire",
	import: "/api/agent-manage/agent-sources/import",
	preview: "/api/agent-manage/agent-sources/preview",
	commit: "/api/agent-manage/agent-sources/commit",
	cancel: "/api/agent-manage/agent-sources/cancel"
};
//#endregion
//#region src/client/agent-source-api.ts
async function request(path, value, signal) {
	const response = await fetch(path, {
		method: value === void 0 ? "GET" : "POST",
		credentials: "same-origin",
		cache: "no-store",
		signal,
		...value === void 0 ? {} : {
			headers: { "content-type": "application/json" },
			body: JSON.stringify(value)
		}
	});
	const body = await response.json();
	if (!response.ok) throw Error(body.error ?? `HTTP ${response.status}`);
	return body;
}
const agentSourceApi = {
	list: () => request(AGENT_SOURCE_ROUTES.list),
	acquire: (value, signal) => request(AGENT_SOURCE_ROUTES.acquire, value, signal),
	import: (value, signal) => request(AGENT_SOURCE_ROUTES.import, value, signal),
	preview: (id, signal) => request(AGENT_SOURCE_ROUTES.preview, { id }, signal),
	commit: (value, signal) => request(AGENT_SOURCE_ROUTES.commit, value, signal),
	cancel: (token) => request(AGENT_SOURCE_ROUTES.cancel, { token })
};
//#endregion
//#region src/client/user-agents.module.css
var user_agents_module_default = {
	"actions": "uCpKnW_actions",
	"back": "uCpKnW_back",
	"badge": "uCpKnW_badge",
	"conflictValues": "uCpKnW_conflictValues",
	"danger": "uCpKnW_danger",
	"description": "uCpKnW_description",
	"error": "uCpKnW_error",
	"heading": "uCpKnW_heading",
	"icon": "uCpKnW_icon",
	"iconButton": "uCpKnW_iconButton",
	"identity": "uCpKnW_identity",
	"inline": "uCpKnW_inline",
	"mcpRow": "uCpKnW_mcpRow",
	"menu": "uCpKnW_menu",
	"menuItems": "uCpKnW_menuItems",
	"modeTabs": "uCpKnW_modeTabs",
	"muted": "uCpKnW_muted",
	"panelHeading": "uCpKnW_panelHeading",
	"primary": "uCpKnW_primary",
	"row": "uCpKnW_row",
	"sectionTitle": "uCpKnW_sectionTitle",
	"settingsWorkspace": "uCpKnW_settingsWorkspace",
	"source": "uCpKnW_source",
	"sourceAddress": "uCpKnW_sourceAddress",
	"sourceFields": "uCpKnW_sourceFields",
	"sourceInfo": "uCpKnW_sourceInfo",
	"state": "uCpKnW_state",
	"switchOff": "uCpKnW_switchOff",
	"switchOn": "uCpKnW_switchOn",
	"tabs": "uCpKnW_tabs",
	"textButton": "uCpKnW_textButton",
	"title": "uCpKnW_title",
	"workspace": "uCpKnW_workspace"
};
//#endregion
//#region src/client/AgentSources.tsx
/** Config sources share Catalog acquisition without installing executable plugins. */
function AgentSources({ t, onImported, onClose, agents = [], initialSyncId }) {
	const explain = (failure) => {
		if (["AGENT_SOURCE_PREVIEW_STALE", "AGENT_SOURCE_PREVIEW_EXPIRED"].includes(failure)) return t("agentSourcePreviewStale");
		if (failure.startsWith("AGENT_SOURCE_CONFLICT_UNRESOLVED")) return t("agentSourceResolveAll");
		if (failure === "AGENT_SOURCE_IMPORT_INCOMPLETE") return t("agentSourceIncomplete");
		if (failure === "AGENT_SOURCE_SKILLS_DISABLED") return t("agentSourceSkillDisabled");
		if (failure === "AGENT_SOURCE_UNSUPPORTED_COMPONENTS") return t("agentSourceUnsupported");
		if (failure === "AGENT_SOURCE_ROLE_RESTRICTIONS_REQUIRE_MANUAL_CONFIGURATION") return t("agentSourceRoleRestricted");
		if (failure === "AGENT_SOURCE_REMOTE_REQUIRES_OWN_SOURCE") return t("agentSourceRemote");
		return failure;
	};
	const operation = (0, react.useRef)();
	const [preview, setPreview] = (0, react.useState)();
	const [resolutions, setResolutions] = (0, react.useState)({});
	const [manual, setManual] = (0, react.useState)({});
	(0, react.useEffect)(() => () => operation.current?.abort(), []);
	const [sources, setSources] = (0, react.useState)([]);
	const [kind, setKind] = (0, react.useState)("git");
	const [url, setUrl] = (0, react.useState)("");
	const [branch, setBranch] = (0, react.useState)("");
	const [busy, setBusy] = (0, react.useState)(false);
	const [error, setError] = (0, react.useState)("");
	const [message, setMessage] = (0, react.useState)("");
	(0, react.useEffect)(() => {
		let current = true;
		agentSourceApi.list().then((rows) => {
			if (current) setSources(rows);
		}).catch((failure) => {
			if (current) setError(String(failure));
		});
		return () => {
			current = false;
		};
	}, []);
	const run = async (action) => {
		operation.current = new AbortController();
		setBusy(true);
		setError("");
		setMessage("");
		try {
			await action();
		} catch (failure) {
			setError(explain(failure instanceof Error ? failure.message : String(failure)));
		} finally {
			setBusy(false);
		}
	};
	const acquire = (event) => {
		event.preventDefault();
		run(async () => {
			const acquired = await agentSourceApi.acquire({
				url,
				kind,
				...kind === "git" && branch.trim() ? { branch: branch.trim() } : {}
			}, operation.current?.signal);
			setSources(await agentSourceApi.list());
			setUrl("");
			setBranch("");
			if (!acquired.candidates.length) setMessage(t("agentSourceNoAgents"));
		});
	};
	const updated = async (agent) => {
		setPreview(void 0);
		await onImported();
		setSources(await agentSourceApi.list());
		setMessage(t(agent.publication === "failed" ? "agentSavedUnavailable" : "agentSourceUpdated"));
	};
	const sync = (id) => void run(async () => {
		const result = await agentSourceApi.preview(id, operation.current?.signal);
		if (result.changed === false) {
			await agentSourceApi.cancel(result.token);
			setMessage(t("agentSourceCurrent"));
			return;
		}
		if (!result.conflicts.length) await updated(await agentSourceApi.commit({
			token: result.token,
			resolutions: {}
		}, operation.current?.signal));
		else {
			setPreview(result);
			setResolutions({});
			setManual({});
		}
	});
	(0, react.useEffect)(() => {
		if (initialSyncId) sync(initialSyncId);
	}, [initialSyncId]);
	const commit = (event) => {
		event.preventDefault();
		if (!preview) return;
		run(async () => {
			const choices = { ...resolutions };
			for (const conflict of preview.conflicts) {
				if (!choices[conflict.key]) throw Error(t("agentSourceResolveAll"));
				if (choices[conflict.key].choice === "manual") choices[conflict.key] = {
					choice: "manual",
					value: [
						"prompt",
						"name",
						"description"
					].includes(conflict.key) ? manual[conflict.key] ?? "" : JSON.parse(manual[conflict.key] ?? "null")
				};
			}
			await updated(await agentSourceApi.commit({
				token: preview.token,
				resolutions: choices
			}, operation.current?.signal));
		});
	};
	return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("section", {
		className: user_agents_module_default.inline,
		"aria-label": t("agentSources"),
		children: [
			/* @__PURE__ */ (0, react_jsx_runtime.jsx)("h3", { children: t("agentSources") }),
			/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
				className: user_agents_module_default.muted,
				children: t("agentSourcesHelp")
			}),
			busy && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => {
					operation.current?.abort();
					onClose();
				},
				children: t("cancel")
			}),
			preview && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("form", {
				onSubmit: commit,
				className: user_agents_module_default.inline,
				children: [
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("h3", { children: t("agentSourceConflicts") }),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
						className: user_agents_module_default.muted,
						children: t("agentSourceConflictHelp")
					}),
					preview.conflicts.map((conflict) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("fieldset", {
						disabled: busy,
						children: [
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("legend", { children: conflict.key === "prompt" ? t("agentPrompt") : conflict.key === "name" ? t("agentName") : conflict.key === "description" ? t("agentDescription") : conflict.key }),
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
								className: user_agents_module_default.conflictValues,
								children: [
									"base",
									"local",
									"upstream"
								].map((side) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("strong", { children: t(side === "base" ? "agentSourceBase" : side === "local" ? "agentSourceLocal" : "agentSourceUpstream") }), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("pre", { children: typeof conflict[side] === "string" ? conflict[side] : JSON.stringify(conflict[side], null, 2) })] }, side))
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("label", { children: [t("agentSourceResolution"), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("select", {
								required: true,
								value: resolutions[conflict.key]?.choice ?? "",
								onChange: (event) => {
									const choice = event.target.value;
									if (choice === "local" || choice === "upstream") setResolutions((rows) => ({
										...rows,
										[conflict.key]: { choice }
									}));
									else if (choice === "manual") {
										setResolutions((rows) => ({
											...rows,
											[conflict.key]: {
												choice: "manual",
												value: conflict.local
											}
										}));
										setManual((rows) => ({
											...rows,
											[conflict.key]: typeof conflict.local === "string" ? conflict.local : JSON.stringify(conflict.local, null, 2)
										}));
									}
								},
								children: [
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("option", {
										value: "",
										disabled: true,
										children: t("agentSourceChoose")
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("option", {
										value: "local",
										children: t("agentSourceKeepLocal")
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("option", {
										value: "upstream",
										children: t("agentSourceUseUpstream")
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("option", {
										value: "manual",
										children: t("agentSourceManual")
									})
								]
							})] }),
							resolutions[conflict.key]?.choice === "manual" && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("label", { children: [t("agentSourceMerged"), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("textarea", {
								required: true,
								rows: 8,
								value: manual[conflict.key] ?? "",
								onChange: (event) => setManual((rows) => ({
									...rows,
									[conflict.key]: event.target.value
								}))
							})] })
						]
					}, conflict.key)),
					/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("footer", {
						className: user_agents_module_default.actions,
						children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
							type: "button",
							disabled: busy,
							onClick: () => void run(async () => {
								await agentSourceApi.cancel(preview.token);
								setPreview(void 0);
							}),
							children: t("cancel")
						}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
							className: user_agents_module_default.primary,
							disabled: busy,
							type: "submit",
							children: t("agentSourceApply")
						})]
					})
				]
			}),
			sources.map((source) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
				className: user_agents_module_default.source,
				children: [
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("strong", { children: source.id }),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
						className: user_agents_module_default.sourceAddress,
						children: source.url
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("p", {
						className: user_agents_module_default.muted,
						children: [t(source.kind === "local" ? "sourceModeLocal" : source.kind === "archive" ? "sourceModeArchive" : "sourceModeGit"), source.lockCommit ? ` · ${source.lockCommit.slice(0, 12)}` : ""]
					}),
					source.errors.map((reason, index) => /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
						className: user_agents_module_default.error,
						children: reason
					}, index)),
					source.candidates.map((candidate) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: user_agents_module_default.row,
						children: [
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: user_agents_module_default.title,
								children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("strong", { children: candidate.name }), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
									className: user_agents_module_default.muted,
									children: candidate.error ? explain(candidate.error) : candidate.description
								})]
							}),
							agents.filter((agent) => !agent.deletedAt && !agent.source?.importPending && agent.source?.sourceId === source.id && agent.source.suiteId === candidate.suiteId && agent.source.resourceKey === candidate.resourceKey).map((agent) => /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: busy || !!preview,
								onClick: () => sync(agent.id),
								children: t("agentSourceSync")
							}, agent.id)),
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
								disabled: busy || !!candidate.error,
								type: "button",
								onClick: () => void run(async () => {
									let agent;
									try {
										agent = await agentSourceApi.import({
											sourceId: source.id,
											suiteId: candidate.suiteId,
											resourceKey: candidate.resourceKey
										}, operation.current?.signal);
									} finally {
										await onImported();
									}
									setMessage(t(agent.publication === "failed" ? "agentSavedUnavailable" : "agentSourceImported"));
								}),
								children: t("agentSourceImport")
							})
						]
					}, `${candidate.suiteId}/${candidate.resourceKey}`)),
					!source.candidates.length && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
						className: user_agents_module_default.muted,
						children: t("agentSourceNoAgents")
					})
				]
			}, source.id)),
			/* @__PURE__ */ (0, react_jsx_runtime.jsx)("form", {
				onSubmit: acquire,
				children: /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("fieldset", {
					disabled: busy,
					className: user_agents_module_default.sourceFields,
					children: [
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)("legend", { children: t("agentSourceAdd") }),
						/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("label", { children: [t("agentSourceKind"), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("select", {
							value: kind,
							onChange: (event) => setKind(event.target.value),
							children: [
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("option", {
									value: "git",
									children: t("sourceModeGit")
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("option", {
									value: "local",
									children: t("sourceModeLocal")
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("option", {
									value: "archive",
									children: t("sourceModeArchive")
								})
							]
						})] }),
						/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("label", { children: [t("agentSourceAddress"), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
							required: true,
							value: url,
							onChange: (event) => setUrl(event.target.value),
							placeholder: t(kind === "local" ? "sourceUrlLocalPh" : kind === "archive" ? "sourceUrlArchivePh" : "sourceUrlPh")
						})] }),
						kind === "git" && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("label", { children: [t("agentSourceBranch"), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
							value: branch,
							onChange: (event) => setBranch(event.target.value)
						})] }),
						/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("footer", {
							className: user_agents_module_default.actions,
							children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									setUrl("");
									setBranch("");
									setError("");
									setMessage("");
									onClose();
								},
								children: t("cancel")
							}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
								className: user_agents_module_default.primary,
								type: "submit",
								children: t(busy ? "agentSourceReading" : "agentSourceRead")
							})]
						})
					]
				})
			}),
			error && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
				role: "alert",
				className: user_agents_module_default.error,
				children: error
			}),
			message && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
				role: "status",
				className: user_agents_module_default.muted,
				children: message
			})
		]
	});
}
//#endregion
//#region src/client/AgentSkills.tsx
/** Agent-local forms own unsaved content; unmounting cancels reads and ignores late writes. */
function AgentSkills({ agent, t, onSaved }) {
	const [catalog, setCatalog] = (0, react.useState)([]);
	const [mode, setMode] = (0, react.useState)();
	const [choice, setChoice] = (0, react.useState)("");
	const [editing, setEditing] = (0, react.useState)();
	const [name, setName] = (0, react.useState)("");
	const [description, setDescription] = (0, react.useState)("");
	const [content, setContent] = (0, react.useState)("");
	const [busy, setBusy] = (0, react.useState)(false);
	const [error, setError] = (0, react.useState)("");
	const [message, setMessage] = (0, react.useState)("");
	const lifetime = (0, react.useRef)();
	const loading = (0, react.useRef)();
	const skills = agent.skills ?? [];
	(0, react.useEffect)(() => {
		const controller = new AbortController();
		lifetime.current = controller;
		userAgentApi.skillCatalog(controller.signal).then((rows) => {
			if (!controller.signal.aborted) setCatalog(rows);
		}).catch((failure) => {
			if (!controller.signal.aborted) setError(String(failure));
		});
		return () => {
			controller.abort();
			loading.current?.abort();
		};
	}, [agent.id]);
	const cancel = () => {
		loading.current?.abort();
		setMode(void 0);
		setEditing(void 0);
		setError("");
		setBusy(false);
	};
	const save = async (next) => {
		const controller = lifetime.current;
		setBusy(true);
		setError("");
		setMessage("");
		try {
			const result = await (agent.origin === "plugin" ? userAgentApi.savePluginSkills(agent.id, next, controller?.signal) : userAgentApi.saveSkills(agent.id, next, controller?.signal));
			if (controller?.signal.aborted) return;
			onSaved(result);
			if (result.publication === "failed") {
				setError(result.error ?? t("agentSavedUnavailable"));
				return;
			}
			setMode(void 0);
			setEditing(void 0);
			setMessage(t("agentSaved"));
		} catch (failure) {
			if (!controller?.signal.aborted) setError(failure instanceof Error ? failure.message : String(failure));
		} finally {
			if (!controller?.signal.aborted) setBusy(false);
		}
	};
	const edit = async (skill) => {
		loading.current?.abort();
		const controller = new AbortController();
		loading.current = controller;
		setMode("edit");
		setEditing(skill);
		setName(skill.name);
		setDescription(skill.kind === "personal" ? skill.description : "");
		setContent(skill.content ?? "");
		setError("");
		setMessage("");
		if (skill.kind !== "reference" || skill.content !== void 0) return;
		setBusy(true);
		try {
			const result = await userAgentApi.readSkill({
				...skill,
				description: ""
			}, controller.signal);
			if (!controller.signal.aborted) setContent(result.content);
		} catch (failure) {
			if (!controller.signal.aborted) setError(String(failure));
		} finally {
			if (!controller.signal.aborted) setBusy(false);
		}
	};
	const submit = (event) => {
		event.preventDefault();
		let skill;
		if (mode === "existing") {
			const source = catalog.find((row) => row.name === choice);
			if (!source) {
				setError(t("agentSkillChoose"));
				return;
			}
			skill = {
				kind: "reference",
				name: source.name,
				provider: source.provider,
				...source.path ? { path: source.path } : {},
				enabled: true
			};
		} else if (editing?.kind === "reference") skill = {
			...editing,
			content
		};
		else skill = {
			kind: "personal",
			name,
			description,
			content,
			enabled: editing?.enabled ?? true
		};
		if (skills.some((row) => row.name === skill.name && row.name !== editing?.name)) {
			setError(t("agentSkillDuplicate"));
			return;
		}
		save(editing ? skills.map((row) => row.name === editing.name ? skill : row) : [...skills, skill]);
	};
	return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("section", { children: [
		/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("header", {
			className: user_agents_module_default.panelHeading,
			children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("h3", {
				className: user_agents_module_default.title,
				children: t("agentSkill")
			}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
				type: "button",
				disabled: busy,
				onClick: () => {
					cancel();
					setMode("existing");
					setChoice("");
					setName("");
					setDescription("");
					setContent("");
				},
				children: t("agentSkillAdd")
			})]
		}),
		skills.map((skill) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("article", {
			className: user_agents_module_default.mcpRow,
			children: [
				/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
					className: user_agents_module_default.title,
					children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("strong", { children: skill.name }), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
						className: user_agents_module_default.description,
						children: skill.kind === "personal" ? t("agentPersonal") : skill.provider
					})]
				}),
				/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
					type: "button",
					className: user_agents_module_default.textButton,
					disabled: busy,
					onClick: () => void edit(skill),
					children: t("agentSkillEdit")
				}),
				/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
					type: "button",
					role: "switch",
					"aria-label": t("agentEnabled", { name: skill.name }),
					"aria-checked": skill.enabled,
					className: skill.enabled ? user_agents_module_default.switchOn : user_agents_module_default.switchOff,
					disabled: busy,
					onClick: () => void save(skills.map((row) => row.name === skill.name ? {
						...row,
						enabled: !row.enabled
					} : row)),
					children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {})
				})
			]
		}, skill.name)),
		!skills.length && !mode && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
			className: user_agents_module_default.muted,
			children: t("agentSkillEmpty")
		}),
		mode && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("form", {
			className: user_agents_module_default.inline,
			onSubmit: submit,
			children: [
				mode !== "edit" && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
					className: user_agents_module_default.heading,
					children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: busy,
						"aria-pressed": mode === "existing",
						onClick: () => setMode("existing"),
						children: t("agentSkillExisting")
					}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: busy,
						"aria-pressed": mode === "personal",
						onClick: () => setMode("personal"),
						children: t("agentSkillPersonal")
					})]
				}),
				mode === "existing" ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("label", { children: [t("agentSkillExisting"), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("select", {
					required: true,
					disabled: busy,
					value: choice,
					onChange: (event) => setChoice(event.target.value),
					children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("option", {
						value: "",
						children: t("agentSkillChoose")
					}), catalog.map((row) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("option", {
						value: row.name,
						disabled: skills.some((skill) => skill.name === row.name),
						children: [
							row.name,
							" · ",
							row.description
						]
					}, row.name))]
				})] }) : /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("label", { children: [t("agentSkillName"), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
						required: true,
						disabled: busy || mode === "edit",
						pattern: "[a-z0-9]+(-[a-z0-9]+)*",
						value: name,
						onChange: (event) => setName(event.target.value)
					})] }),
					editing?.kind !== "reference" && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("label", { children: [t("agentDescription"), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
						required: true,
						disabled: busy,
						maxLength: 1e3,
						value: description,
						onChange: (event) => setDescription(event.target.value)
					})] }),
					/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("label", { children: [t("agentSkillContent"), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("textarea", {
						required: true,
						disabled: busy,
						rows: 12,
						maxLength: 96e3,
						value: content,
						onChange: (event) => setContent(event.target.value)
					})] }),
					editing?.kind === "reference" && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
						className: user_agents_module_default.muted,
						children: t("agentSkillOverride")
					})
				] }),
				/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("footer", {
					className: user_agents_module_default.actions,
					children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: busy,
						onClick: cancel,
						children: t("cancel")
					}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
						type: "submit",
						className: user_agents_module_default.primary,
						disabled: busy,
						children: t("save")
					})]
				})
			]
		}),
		error && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
			role: "alert",
			className: user_agents_module_default.error,
			children: error
		}),
		message && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
			role: "status",
			className: user_agents_module_default.muted,
			children: message
		})
	] });
}
//#endregion
//#region src/client/ui/agent-icon.tsx
const agentIcon = /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("svg", {
	"aria-hidden": "true",
	width: "24",
	height: "24",
	viewBox: "0 0 24 24",
	fill: "none",
	stroke: "currentColor",
	strokeWidth: "1.5",
	children: [
		/* @__PURE__ */ (0, react_jsx_runtime.jsx)("rect", {
			x: "3",
			y: "3",
			width: "6",
			height: "6",
			rx: "1.5"
		}),
		/* @__PURE__ */ (0, react_jsx_runtime.jsx)("rect", {
			x: "15",
			y: "3",
			width: "6",
			height: "6",
			rx: "1.5"
		}),
		/* @__PURE__ */ (0, react_jsx_runtime.jsx)("rect", {
			x: "9",
			y: "15",
			width: "6",
			height: "6",
			rx: "1.5"
		}),
		/* @__PURE__ */ (0, react_jsx_runtime.jsx)("path", { d: "M6 9v3h12V9M12 12v3" })
	]
});
//#endregion
//#region src/client/TrustedCubePanel.tsx
/** Only the association is editable; GEA retains its connection and authorization. */
function TrustedCubePanel({ agent, t, editing, onClose, onSaved }) {
	const [sources, setSources] = (0, react.useState)([]);
	const [sourceRef, setSourceRef] = (0, react.useState)(agent.cube?.sourceRef ?? "");
	const [busy, setBusy] = (0, react.useState)(false);
	const [error, setError] = (0, react.useState)("");
	const mounted = (0, react.useRef)(true);
	(0, react.useEffect)(() => {
		let active = true;
		mounted.current = true;
		userAgentApi.cubeSources().then((rows) => {
			if (active) setSources(rows);
		}).catch((reason) => {
			if (active) setError(String(reason));
		});
		return () => {
			active = false;
			mounted.current = false;
		};
	}, []);
	(0, react.useEffect)(() => {
		if (editing) setSourceRef(agent.cube?.sourceRef ?? "");
	}, [editing, agent.cube?.sourceRef]);
	const save = async (cube) => {
		setBusy(true);
		setError("");
		try {
			const saved = await userAgentApi.saveCube(agent.id, cube);
			if (mounted.current) {
				onSaved(saved);
				if (editing) onClose();
			}
		} catch (reason) {
			if (mounted.current) setError(reason instanceof Error ? reason.message : String(reason));
		} finally {
			if (mounted.current) setBusy(false);
		}
	};
	return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [
		agent.cube && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("article", {
			className: user_agents_module_default.mcpRow,
			children: [
				/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
					className: user_agents_module_default.title,
					children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("strong", { children: t("agentCubeTitle") }), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
						className: user_agents_module_default.badge,
						children: t("agentMcpPlugin")
					})]
				}),
				/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
					className: user_agents_module_default.state,
					children: t(agent.cube.enabled ? "agentStateEnabled" : "agentStateDisabled")
				}),
				/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
					type: "button",
					role: "switch",
					"aria-label": t("agentCubeEnabled", { name: agent.name }),
					"aria-checked": agent.cube.enabled,
					className: agent.cube.enabled ? user_agents_module_default.switchOn : user_agents_module_default.switchOff,
					disabled: busy,
					onClick: () => {
						if (agent.cube) save({
							...agent.cube,
							enabled: !agent.cube.enabled
						});
					},
					children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {})
				})
			]
		}),
		editing && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("form", {
			className: user_agents_module_default.inline,
			onSubmit: (event) => {
				event.preventDefault();
				save(sourceRef ? {
					sourceRef,
					enabled: true
				} : null);
			},
			children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("label", { children: [t("agentCubeSource"), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("select", {
				value: sourceRef,
				disabled: busy,
				onChange: (event) => setSourceRef(event.target.value),
				children: [
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("option", {
						value: "",
						children: t("agentCubeNone")
					}),
					agent.cube && !sources.some((source) => source.sourceRef === agent.cube?.sourceRef) && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("option", {
						value: agent.cube.sourceRef,
						children: t("agentUnavailable")
					}),
					sources.map((source) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("option", {
						value: source.sourceRef,
						children: [source.name, source.available ? "" : ` · ${t("agentUnavailable")}`]
					}, source.sourceRef))
				]
			})] }), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("footer", {
				className: user_agents_module_default.actions,
				children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
					type: "button",
					disabled: busy,
					onClick: onClose,
					children: t("cancel")
				}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
					type: "submit",
					className: user_agents_module_default.primary,
					disabled: busy,
					children: t("save")
				})]
			})]
		}),
		error && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
			role: "alert",
			className: user_agents_module_default.error,
			children: error
		})
	] });
}
/** Fixed plugin members remain separately controllable from Agent enablement. */
function PluginMcpPanel({ agent, t, onSaved }) {
	const [busy, setBusy] = (0, react.useState)(false);
	const [error, setError] = (0, react.useState)("");
	const active = (0, react.useRef)(true);
	(0, react.useEffect)(() => {
		active.current = true;
		return () => {
			active.current = false;
		};
	}, [agent.id]);
	return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("section", { children: [
		/* @__PURE__ */ (0, react_jsx_runtime.jsx)("header", {
			className: user_agents_module_default.panelHeading,
			children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("h3", { children: t("agentMcpUsed") })
		}),
		agent.cube && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("article", {
			className: user_agents_module_default.mcpRow,
			children: [
				/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
					className: user_agents_module_default.title,
					children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("strong", { children: t("agentCubeTitle") }), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
						className: user_agents_module_default.badge,
						children: t("agentMcpPlugin")
					})]
				}),
				/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
					className: user_agents_module_default.state,
					children: t(agent.cube.enabled ? "agentStateEnabled" : "agentStateDisabled")
				}),
				/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
					type: "button",
					role: "switch",
					"aria-label": t("agentCubeEnabled", { name: agent.name }),
					"aria-checked": agent.cube.enabled,
					className: agent.cube.enabled ? user_agents_module_default.switchOn : user_agents_module_default.switchOff,
					disabled: busy,
					onClick: () => {
						setBusy(true);
						(async () => {
							try {
								await userAgentApi.setPluginCubeEnabled(agent.id, !agent.cube?.enabled);
								const saved = (await userAgentApi.pluginAgents()).find((row) => row.id === agent.id);
								if (active.current && saved) onSaved(saved);
							} catch (failure) {
								if (active.current) setError(String(failure));
							} finally {
								if (active.current) setBusy(false);
							}
						})();
					},
					children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {})
				})
			]
		}),
		error && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
			role: "alert",
			children: error
		})
	] });
}
/** Trusted plugin rows open the same editor; personal copy is a separate action. */
function TrustedPluginAgents({ t, onEdit }) {
	const [sources, setSources] = (0, react.useState)([]);
	const [busy, setBusy] = (0, react.useState)(false);
	const [error, setError] = (0, react.useState)("");
	const mounted = (0, react.useRef)(true);
	(0, react.useEffect)(() => {
		let active = true;
		mounted.current = true;
		userAgentApi.pluginAgents().then((rows) => {
			if (active) setSources(rows);
		}).catch((reason) => {
			if (active) setError(String(reason));
		});
		return () => {
			active = false;
			mounted.current = false;
		};
	}, []);
	const run = async (action) => {
		setBusy(true);
		setError("");
		try {
			await action();
		} catch (reason) {
			if (mounted.current) setError(reason instanceof Error ? reason.message : String(reason));
		} finally {
			if (mounted.current) setBusy(false);
		}
	};
	if (!sources.length && !error) return null;
	return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("section", { children: [
		/* @__PURE__ */ (0, react_jsx_runtime.jsx)("h3", {
			className: user_agents_module_default.sectionTitle,
			children: t("agentPluginPresets")
		}),
		sources.map((source) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("article", {
			className: `${user_agents_module_default.row} ${user_agents_module_default.pluginRow}`,
			children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("button", {
				type: "button",
				className: user_agents_module_default.identity,
				disabled: busy,
				onClick: () => onEdit(source),
				children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
					className: user_agents_module_default.icon,
					children: agentIcon
				}), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("strong", { children: source.name }), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
					className: user_agents_module_default.description,
					children: [
						source.description || t("agentMcpPlugin"),
						source.customized ? ` · ${t("agentSourceCustomized")}` : "",
						source.publication === "failed" ? ` · ${t("agentUnavailable")}` : ""
					]
				})] })]
			}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
				type: "button",
				role: "switch",
				"aria-label": t("agentEnabled", { name: source.name }),
				"aria-checked": source.enabled,
				className: source.enabled ? user_agents_module_default.switchOn : user_agents_module_default.switchOff,
				disabled: busy,
				onClick: () => void run(async () => {
					const saved = await userAgentApi.setPluginEnabled(source.id, !source.enabled);
					if (mounted.current) setSources((rows) => rows.map((row) => row.id === saved.id ? saved : row));
				}),
				children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {})
			})]
		}, source.id)),
		error && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
			role: "alert",
			className: user_agents_module_default.error,
			children: error
		})
	] });
}
//#endregion
//#region src/client/AgentRecovery.tsx
/** Personal configuration actions only; Core remains the Session/default/draft owner. */
function AgentRecovery({ agent, t, onChanged, onChooseAnother }) {
	const lifetime = (0, react.useRef)();
	(0, react.useEffect)(() => {
		const controller = new AbortController();
		lifetime.current = controller;
		return () => controller.abort();
	}, [agent.id]);
	const [busy, setBusy] = (0, react.useState)(false);
	const [confirmDelete, setConfirmDelete] = (0, react.useState)(false);
	const [error, setError] = (0, react.useState)("");
	const run = async (action) => {
		const controller = lifetime.current;
		setBusy(true);
		setError("");
		try {
			const saved = await action();
			if (!controller?.signal.aborted) {
				onChanged(saved);
				setConfirmDelete(false);
			}
		} catch (failure) {
			if (!controller?.signal.aborted) setError(failure instanceof Error ? failure.message : String(failure));
		} finally {
			if (!controller?.signal.aborted) setBusy(false);
		}
	};
	return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("aside", {
		"aria-label": t("agentRecovery"),
		children: [
			agent.defaultUnavailable && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
				role: "alert",
				children: t("agentDefaultUnavailable")
			}),
			agent.publication !== "ready" && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", { children: t(agent.publication === "deleted" ? "agentDeletedRecovery" : agent.publication === "disabled" ? "agentDisabledRecovery" : "agentDependencyRecovery") }),
				/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
					className: user_agents_module_default.muted,
					children: t("agentColdRecoveryLimit")
				}),
				agent.publication === "deleted" ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
					type: "button",
					disabled: busy,
					onClick: () => void run(() => userAgentApi.restore(agent.id)),
					children: t("agentRestore")
				}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
					type: "button",
					disabled: busy,
					onClick: () => void run(() => userAgentApi.setEnabled(agent.id, true)),
					children: t("agentEnableRecovery")
				}),
				/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
					type: "button",
					disabled: busy,
					onClick: onChooseAnother,
					children: t("agentChooseAnother")
				})
			] }),
			agent.publication !== "deleted" && (confirmDelete ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", { children: t("agentDeleteConfirmation") }),
				/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
					type: "button",
					disabled: busy,
					onClick: () => setConfirmDelete(false),
					children: t("cancel")
				}),
				/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
					type: "button",
					disabled: busy,
					onClick: () => void run(() => userAgentApi.remove(agent.id)),
					children: t("agentDeleteConfirm")
				})
			] }) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
				type: "button",
				disabled: busy,
				onClick: () => setConfirmDelete(true),
				children: t("agentDelete")
			})),
			error && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
				role: "alert",
				className: user_agents_module_default.error,
				children: error
			})
		]
	});
}
//#endregion
//#region src/client/ui/server-form.ts
/** 将编辑器文本解析为 JSON 对象，并拒绝 null、数组和标量根值。 */
function parseServerConfig(text) {
	const value = JSON.parse(text);
	if (value === null || typeof value !== "object" || Array.isArray(value)) throw new Error("Configuration must be a JSON object");
	return value;
}
/** Switching transport removes only transport-specific fields; all unrelated keys survive edits. */
/** 切换 MCP 传输时删除互斥字段，保留所有与传输无关的配置。 */
function changeTransport(config, type) {
	const next = {
		...config,
		type
	};
	if (type === "stdio") {
		delete next["url"];
		delete next["headers"];
		delete next["auth"];
	} else {
		delete next["command"];
		delete next["args"];
		delete next["env"];
		delete next["cwd"];
	}
	return next;
}
/** 判断配置是否能安全映射到结构化表单；复杂或未知结构留给 JSON 模式编辑。 */
function serverFormCompatible(config, kind) {
	/** 判断可选的键值字段是否为表单能够安全编辑的字符串映射。 */
	const isMap = (value) => value === void 0 || value !== null && typeof value === "object" && !Array.isArray(value) && Object.values(value).every((v) => typeof v === "string");
	if (![
		"command",
		"url",
		"cwd"
	].every((key) => config[key] === void 0 || typeof config[key] === "string")) return false;
	if (config.args !== void 0 && (!Array.isArray(config.args) || config.args.some((value) => typeof value !== "string"))) return false;
	if (!isMap(config.env) || !isMap(config.headers) || !isMap(config.extensionToLanguage)) return false;
	if (kind === "mcp" && config.type !== void 0 && ![
		"stdio",
		"streamable-http",
		"sse"
	].includes(String(config.type))) return false;
	if (config.auth !== void 0 && (config.auth === null || typeof config.auth !== "object" || Array.isArray(config.auth))) return false;
	const auth = config.auth;
	if (auth?.enabled !== void 0 && typeof auth.enabled !== "boolean") return false;
	if (auth?.scope !== void 0 && typeof auth.scope !== "string") return false;
	return true;
}
//#endregion
//#region src/client/ui/detail.module.css
var detail_module_default = {
	"body": "G-7KhG_body",
	"dialog": "G-7KhG_dialog",
	"error": "G-7KhG_error",
	"field": "G-7KhG_field",
	"footer": "G-7KhG_footer",
	"footerSlot": "G-7KhG_footerSlot",
	"form": "G-7KhG_form",
	"heading": "G-7KhG_heading",
	"metadata": "G-7KhG_metadata",
	"mode": "G-7KhG_mode",
	"modes": "G-7KhG_modes",
	"preview": "G-7KhG_preview",
	"raw": "G-7KhG_raw",
	"row": "G-7KhG_row",
	"rows": "G-7KhG_rows",
	"section": "G-7KhG_section",
	"value": "G-7KhG_value",
	"values": "G-7KhG_values",
	"wide": "G-7KhG_wide"
};
//#endregion
//#region src/client/ui/ServerConfigEditor.tsx
/** 文件作用：提供 MCP/LSP 配置的表单模式与原始 JSON 模式，维护字段兼容性、必填校验和局部编辑。 */
/** One JSON document backs both modes. Invalid JSON is retained, never silently converted or reset. */
/** 中文：表单和 JSON 模式共享同一份文本；非法 JSON 保留在编辑器中，不静默重置。 */
function ServerConfigEditor(props) {
	/** 在结构化表单和 JSON 文本之间切换，并把每次有效字段变更序列化回父级。 */
	const [mode, setMode] = (0, react.useState)("form");
	const [issues, setIssues] = (0, react.useState)({});
	let config;
	let parseError;
	try {
		config = parseServerConfig(props.text);
	} catch (error) {
		parseError = error instanceof Error ? error.message : String(error);
	}
	const compatible = config !== void 0 && serverFormCompatible(config, props.kind);
	const hasIssue = Object.values(issues).some(Boolean);
	const requiredValid = config !== void 0 && (props.kind === "lsp" ? typeof config.command === "string" && config.command.trim() !== "" && config.extensionToLanguage !== null && typeof config.extensionToLanguage === "object" && Object.keys(config.extensionToLanguage).length > 0 : config.type === "stdio" ? typeof config.command === "string" && config.command.trim() !== "" : ["sse", "streamable-http"].includes(String(config.type)) && typeof config.url === "string" && config.url.trim() !== "");
	const valid = compatible && !hasIssue && requiredValid;
	/** 将当前结构化配置是否可保存同步给父级详情组件。 */
	(0, react.useEffect)(() => {
		props.onValidityChange?.(valid);
	}, [valid, props.onValidityChange]);
	/** 将表单对象格式化为稳定 JSON，保持原始编辑器的单一数据源。 */
	/** 将结构化配置序列化回父级文本，保持表单和 JSON 编辑共享单一数据源。 */
	const update = (next) => props.onChange(JSON.stringify(next, null, 2));
	/** 更新一个配置键；undefined 表示删除可选字段。 */
	const field = (key, value) => {
		/** 更新单个配置键；空值表示删除可选字段，避免写入无意义空字符串。 */
		const next = { ...config };
		if (value === void 0) delete next[key];
		else next[key] = value;
		update(next);
	};
	/** 记录某个数组/映射字段的局部校验结果，并影响整体可保存状态。 */
	const issue = (key, bad) => {
		/** 汇总数组/映射编辑器的局部错误，阻止保存不合法的结构化配置。 */
		setIssues((current) => {
			return {
				...current,
				[key]: bad
			};
		});
	};
	/** 把字符串配置键渲染成受控输入，并将空可选值转换为删除字段。 */
	const textField = (key, label, required = false) => (0, react.createElement)("label", {
		className: detail_module_default.field,
		key
	}, label, (0, react.createElement)("input", {
		value: typeof config?.[key] === "string" ? config[key] : "",
		required,
		"aria-label": label,
		onChange: (event) => field(key, event.target.value === "" && !required ? void 0 : event.target.value)
	}));
	/** 把对象配置键交给可编辑键值行组件，并回传字段级错误。 */
	const mapField = (key, label) => (0, react.createElement)("div", {
		className: `${detail_module_default.field} ${detail_module_default.wide}`,
		key
	}, (0, react.createElement)("span", null, label), (0, react.createElement)(StringRows, {
		key,
		label,
		t: props.t,
		map: true,
		value: config?.[key],
		onChange: (value) => field(key, value),
		onIssue: (bad) => issue(key, bad)
	}));
	const type = String(config?.type ?? "stdio");
	const auth = config?.auth ?? {};
	return (0, react.createElement)("div", { className: detail_module_default.section }, (0, react.createElement)("div", { className: detail_module_default.modes }, ["form", "json"].map((value) => (0, react.createElement)("button", {
		type: "button",
		key: value,
		className: detail_module_default.mode,
		"aria-pressed": mode === value,
		disabled: props.disabled || value === "json" && hasIssue,
		onClick: () => setMode(value)
	}, props.t(value === "form" ? "detailForm" : "detailJson")))), parseError ? (0, react.createElement)("div", {
		role: "alert",
		className: detail_module_default.error
	}, props.t("detailInvalidJson"), " ", parseError) : null, mode === "json" ? (0, react.createElement)("textarea", {
		className: detail_module_default.raw,
		value: props.text,
		disabled: props.disabled,
		spellCheck: false,
		"aria-label": props.t("detailJson"),
		onChange: (event) => props.onChange(event.target.value)
	}) : !compatible ? (0, react.createElement)("div", {
		role: "alert",
		className: detail_module_default.error
	}, props.t("detailUseJson")) : (0, react.createElement)("fieldset", {
		disabled: props.disabled,
		className: detail_module_default.form,
		style: {
			border: 0,
			margin: 0,
			padding: 0
		}
	}, props.kind === "mcp" ? (0, react.createElement)("label", { className: detail_module_default.field }, props.t("detailTransport"), (0, react.createElement)("select", {
		value: type,
		"aria-label": props.t("detailTransport"),
		disabled: hasIssue,
		onChange: (event) => update(changeTransport(config, event.target.value))
	}, [
		"stdio",
		"streamable-http",
		"sse"
	].map((value) => (0, react.createElement)("option", {
		key: value,
		value
	}, value)))) : null, props.kind === "lsp" || type === "stdio" ? [
		textField("command", props.t("detailCommand"), true),
		(0, react.createElement)("div", {
			className: `${detail_module_default.field} ${detail_module_default.wide}`,
			key: "args"
		}, (0, react.createElement)("span", null, props.t("detailArgs")), (0, react.createElement)(StringRows, {
			label: props.t("detailArgs"),
			t: props.t,
			map: false,
			value: config.args,
			onChange: (value) => field("args", value),
			onIssue: (bad) => issue("args", bad)
		})),
		mapField("env", props.t("detailEnv"))
	] : [textField("url", props.t("detailUrl"), true), mapField("headers", props.t("detailHeaders"))], props.kind === "mcp" && type === "stdio" ? textField("cwd", props.t("detailCwd")) : null, props.kind === "mcp" && type !== "stdio" ? (0, react.createElement)("div", { className: detail_module_default.field }, (0, react.createElement)("label", null, (0, react.createElement)("input", {
		type: "checkbox",
		checked: auth.enabled !== false,
		onChange: (event) => field("auth", {
			...auth,
			enabled: event.target.checked
		})
	}), " OAuth"), (0, react.createElement)("label", { className: detail_module_default.field }, props.t("detailScope"), (0, react.createElement)("input", {
		value: typeof auth.scope === "string" ? auth.scope : "",
		"aria-label": props.t("detailScope"),
		onChange: (event) => {
			const next = {
				...auth,
				scope: event.target.value
			};
			field("auth", next);
		}
	}))) : null, props.kind === "lsp" ? [mapField("extensionToLanguage", props.t("detailExtensions")), ...["initializationOptions", "configuration"].map((key) => (0, react.createElement)(JsonField, {
		key,
		label: key,
		value: config[key],
		onChange: (value) => field(key, value),
		onIssue: (bad) => issue(key, bad)
	}))] : null));
}
/** 编辑字符串数组或字符串映射；映射键必须非空且唯一后才写回父配置。 */
function StringRows(props) {
	const [rows, setRows] = (0, react.useState)(() => props.map ? Object.entries(props.value ?? {}) : (props.value ?? []).map((value) => ["", value]));
	const [invalid, setInvalid] = (0, react.useState)(false);
	/** 应用一组键值行草稿，校验映射键后才向父级输出。 */
	const change = (next) => {
		/** 更新行草稿并计算重复/空键问题，只有合法时才输出结构化值。 */
		setRows(next);
		const bad = props.map && (next.some(([key]) => key.trim() === "") || new Set(next.map(([key]) => key)).size !== next.length);
		setInvalid(bad);
		props.onIssue(bad);
		if (!bad) props.onChange(props.map ? Object.fromEntries(next) : next.map(([, value]) => value));
	};
	return (0, react.createElement)("div", { className: detail_module_default.rows }, rows.map(([key, value], index) => (0, react.createElement)("div", {
		className: detail_module_default.row,
		key: index
	}, props.map ? (0, react.createElement)("input", {
		value: key,
		"aria-label": `${props.label} ${props.t("detailKey")} ${index + 1}`,
		onChange: (event) => change(rows.map((row, i) => i === index ? [event.target.value, row[1]] : row))
	}) : null, (0, react.createElement)("input", {
		value,
		"aria-label": `${props.label} ${props.t("detailValue")} ${index + 1}`,
		onChange: (event) => change(rows.map((row, i) => i === index ? [row[0], event.target.value] : row))
	}), (0, react.createElement)(_deepseek_ai_dsh_client_ui_primitives.Button, {
		variant: "ghost",
		size: "sm",
		title: props.t("panelDelete"),
		"aria-label": `${props.t("panelDelete")} ${props.label} ${index + 1}`,
		onClick: () => change(rows.filter((_, i) => i !== index))
	}, (0, react.createElement)(_deepseek_ai_dsh_client_ui_primitives.IconTrashOutlineRegular)))), invalid ? (0, react.createElement)("span", {
		role: "alert",
		className: detail_module_default.error
	}, props.t("detailUniqueKeys")) : null, (0, react.createElement)(_deepseek_ai_dsh_client_ui_primitives.Button, {
		variant: "ghost",
		size: "sm",
		title: props.t("panelAdd"),
		"aria-label": `${props.t("panelAdd")} ${props.label}`,
		onClick: () => change([...rows, ["", ""]])
	}, (0, react.createElement)(_deepseek_ai_dsh_client_ui_primitives.IconPlusOutlineRegular), props.t("panelAdd")));
}
/** 编辑 LSP 的任意 JSON 字段；输入错误暂存在文本框，不覆盖用户草稿。 */
function JsonField(props) {
	const [text, setText] = (0, react.useState)(props.value === void 0 ? "" : JSON.stringify(props.value, null, 2));
	const [error, setError] = (0, react.useState)("");
	return (0, react.createElement)("label", { className: `${detail_module_default.field} ${detail_module_default.wide}` }, props.label, (0, react.createElement)("textarea", {
		value: text,
		rows: 4,
		"aria-label": props.label,
		onChange: (event) => {
			const next = event.target.value;
			setText(next);
			try {
				const value = next.trim() === "" ? void 0 : JSON.parse(next);
				setError("");
				props.onIssue(false);
				props.onChange(value);
			} catch (reason) {
				setError(String(reason));
				props.onIssue(true);
			}
		}
	}), error ? (0, react.createElement)("span", {
		role: "alert",
		className: detail_module_default.error
	}, error) : null);
}
//#endregion
//#region src/contracts/agent-mcp.ts
const AGENT_MCP_ROUTES = {
	mcpAvailable: "/api/agent-manage/agents/mcp/available",
	mcpList: "/api/agent-manage/agents/mcp/list",
	mcpSave: "/api/agent-manage/agents/mcp/save",
	mcpAssociate: "/api/agent-manage/agents/mcp/associate",
	mcpEnabled: "/api/agent-manage/agents/mcp/enabled",
	mcpReauthorize: "/api/agent-manage/agents/mcp/reauthorize",
	mcpCancelAuthorization: "/api/agent-manage/agents/mcp/cancel-authorization",
	mcpRemove: "/api/agent-manage/agents/mcp/remove"
};
//#endregion
//#region src/client/agent-mcp-api.ts
const agentMcpApi = {
	available: (agentId) => request$1(AGENT_MCP_ROUTES.mcpAvailable, { agentId }),
	associate: (agentId, connectionId) => request$1(AGENT_MCP_ROUTES.mcpAssociate, {
		agentId,
		connectionId,
		enabled: true
	}),
	list: (agentId) => request$1(AGENT_MCP_ROUTES.mcpList, { agentId }),
	save: (input) => request$1(AGENT_MCP_ROUTES.mcpSave, input),
	setEnabled: (agentId, connectionId, enabled) => request$1(AGENT_MCP_ROUTES.mcpEnabled, {
		agentId,
		connectionId,
		enabled
	}),
	reauthorize: (agentId, connectionId) => request$1(AGENT_MCP_ROUTES.mcpReauthorize, {
		agentId,
		connectionId
	}),
	cancelAuthorization: (agentId, connectionId) => request$1(AGENT_MCP_ROUTES.mcpCancelAuthorization, {
		agentId,
		connectionId
	}),
	remove: (agentId, connectionId) => request$1(AGENT_MCP_ROUTES.mcpRemove, {
		agentId,
		connectionId
	})
};
//#endregion
//#region src/client/AgentMcpPanel.tsx
/** Association actions keep their own draft; cancelling never writes effective configuration. */
function AgentMcpPanel({ agent, t, onSaved }) {
	const agentId = agent.id;
	const [rows, setRows] = (0, react.useState)([]);
	const [available, setAvailable] = (0, react.useState)([]);
	const [existing, setExisting] = (0, react.useState)("");
	const [editing, setEditing] = (0, react.useState)();
	const [name, setName] = (0, react.useState)("");
	const [serverId, setServerId] = (0, react.useState)("");
	const [config, setConfig] = (0, react.useState)("");
	const [valid, setValid] = (0, react.useState)(false);
	const [busy, setBusy] = (0, react.useState)(false);
	const [error, setError] = (0, react.useState)("");
	const refresh = async () => {
		const [next, candidates] = await Promise.all([agentMcpApi.list(agentId), agentMcpApi.available(agentId)]);
		setRows(next);
		setAvailable(candidates);
	};
	(0, react.useEffect)(() => {
		let active = true;
		Promise.all([agentMcpApi.list(agentId), agentMcpApi.available(agentId)]).then(([value, candidates]) => {
			if (active) {
				setRows(value);
				setAvailable(candidates);
			}
		}).catch((reason) => {
			if (active) setError(String(reason));
		});
		return () => {
			active = false;
		};
	}, [agentId]);
	const pending = rows.some((row) => row.state === "connecting" || row.state === "awaiting-authorization");
	(0, react.useEffect)(() => {
		if (!pending) return;
		let active = true;
		let timer;
		const poll = async () => {
			try {
				const next = await agentMcpApi.list(agentId);
				if (active) setRows(next);
			} catch (reason) {
				if (active) setError(reason instanceof Error ? reason.message : String(reason));
			}
			if (active) timer = setTimeout(() => void poll(), 1e3);
		};
		timer = setTimeout(() => void poll(), 1e3);
		return () => {
			active = false;
			clearTimeout(timer);
		};
	}, [agentId, pending]);
	const run = async (action) => {
		setBusy(true);
		setError("");
		try {
			await action();
			await refresh();
		} catch (reason) {
			setError(reason instanceof Error ? reason.message : String(reason));
		} finally {
			setBusy(false);
		}
	};
	const edit = (row) => {
		setExisting("");
		setEditing(row ?? "new");
		setName(row?.name ?? "");
		setServerId(row?.serverId ?? "");
		setConfig(JSON.stringify(row?.config ?? {
			type: "streamable-http",
			url: "",
			auth: { enabled: true }
		}, null, 2));
		setError("");
	};
	const save = (event) => {
		event.preventDefault();
		run(async () => {
			if (existing) await agentMcpApi.associate(agentId, existing);
			else await agentMcpApi.save({
				agentId,
				...editing && typeof editing !== "string" ? { connectionId: editing.connectionId } : {},
				serverId,
				name,
				config: JSON.parse(config)
			});
			setEditing(void 0);
		});
	};
	return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("header", {
			className: user_agents_module_default.panelHeading,
			children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("h3", {
				className: user_agents_module_default.title,
				children: t("agentMcpUsed")
			}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
				type: "button",
				disabled: busy,
				onClick: () => edit(),
				children: t("agentMcpAdd")
			})]
		}),
		(editing === "new" || editing === "cube") && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
			className: user_agents_module_default.modeTabs,
			children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-pressed": editing === "new",
				onClick: () => edit(),
				children: t("agentMcpExternal")
			}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-pressed": editing === "cube",
				onClick: () => setEditing("cube"),
				children: t("agentMcpPlugin")
			})]
		}),
		/* @__PURE__ */ (0, react_jsx_runtime.jsx)(TrustedCubePanel, {
			agent,
			t,
			editing: editing === "cube",
			onClose: () => setEditing(void 0),
			onSaved
		}),
		rows.map((row) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("article", {
			className: user_agents_module_default.mcpRow,
			children: [
				/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
					className: user_agents_module_default.title,
					children: [
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)("strong", { children: row.name }),
						/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("p", {
							role: "status",
							className: user_agents_module_default.description,
							children: [
								row.serverId,
								" · ",
								t(row.owner === "user" ? "agentMcpUser" : "agentMcpPlugin"),
								" · ",
								t(`agentMcpState_${row.state}`)
							]
						}),
						row.reason && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
							role: "status",
							className: user_agents_module_default.error,
							children: row.reason
						})
					]
				}),
				row.state === "awaiting-authorization" && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
					type: "button",
					disabled: busy,
					onClick: () => void run(() => agentMcpApi.cancelAuthorization(agentId, row.connectionId)),
					children: t("agentMcpCancelAuthorization")
				}),
				row.canReauthorize && row.state !== "awaiting-authorization" && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
					type: "button",
					disabled: busy,
					onClick: () => void run(() => agentMcpApi.reauthorize(agentId, row.connectionId)),
					children: t("mcpReauthorize")
				}),
				row.allowedOps.includes("edit") && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
					type: "button",
					className: user_agents_module_default.textButton,
					disabled: busy,
					onClick: () => edit(row),
					children: t("panelEditTitle")
				}),
				row.allowedOps.includes("remove") && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
					type: "button",
					className: `${user_agents_module_default.textButton} ${user_agents_module_default.danger}`,
					disabled: busy,
					onClick: () => void run(() => agentMcpApi.remove(agentId, row.connectionId)),
					children: t("agentMcpRemove")
				}),
				row.allowedOps.includes("toggle") && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
					type: "button",
					role: "switch",
					"aria-label": t("agentEnabled", { name: row.name }),
					"aria-checked": row.enabled,
					disabled: busy,
					className: row.enabled ? user_agents_module_default.switchOn : user_agents_module_default.switchOff,
					onClick: () => void run(() => agentMcpApi.setEnabled(agentId, row.connectionId, !row.enabled)),
					children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {})
				})
			]
		}, row.connectionId)),
		!rows.length && !agent.cube && !editing && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
			className: user_agents_module_default.muted,
			children: t("agentMcpEmpty")
		}),
		editing && editing !== "cube" && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("form", {
			className: user_agents_module_default.inline,
			onSubmit: save,
			children: [
				editing === "new" && available.length > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("label", { children: [t("agentMcpExisting"), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("select", {
					disabled: busy,
					value: existing,
					onChange: (event) => setExisting(event.target.value),
					children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("option", {
						value: "",
						children: t("agentMcpNew")
					}), available.map((row) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("option", {
						value: row.connectionId,
						children: [
							row.name,
							" · ",
							row.serverId
						]
					}, row.connectionId))]
				})] }),
				!existing && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("label", { children: [t("agentMcpName"), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
						required: true,
						maxLength: 160,
						disabled: busy,
						value: name,
						onChange: (event) => setName(event.target.value)
					})] }),
					/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("label", { children: [t("agentMcpServerId"), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
						required: true,
						maxLength: 64,
						pattern: "[a-zA-Z0-9][a-zA-Z0-9_-]{0,63}",
						disabled: busy || editing !== "new",
						value: serverId,
						onChange: (event) => setServerId(event.target.value)
					})] }),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)(ServerConfigEditor, {
						kind: "mcp",
						text: config,
						onChange: setConfig,
						t,
						disabled: busy,
						onValidityChange: setValid
					}, editing === "new" ? "new" : editing.connectionId),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
						className: user_agents_module_default.muted,
						children: t("agentMcpCredentials")
					})
				] }),
				/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("footer", {
					className: user_agents_module_default.actions,
					children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: busy,
						onClick: () => setEditing(void 0),
						children: t("cancel")
					}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
						type: "submit",
						className: user_agents_module_default.primary,
						disabled: busy || !existing && !valid,
						children: t("save")
					})]
				})
			]
		}),
		error && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
			role: "alert",
			className: user_agents_module_default.error,
			children: error
		})
	] });
}
//#endregion
//#region src/client/UserAgentWorkspace.tsx
const blank = () => ({
	name: "",
	description: "",
	prompt: "",
	enabled: true
});
/** One shared list/editor for the public main and settings seats. */
function UserAgentWorkspace({ t, startAgent, surface = "main" }) {
	const [showSources, setShowSources] = (0, react.useState)(false);
	const [sourceRequest, setSourceRequest] = (0, react.useState)();
	const [agents, setAgents] = (0, react.useState)([]);
	const [selected, setSelected] = (0, react.useState)();
	const [draft, setDraft] = (0, react.useState)(blank);
	const [adding, setAdding] = (0, react.useState)(false);
	const [tab, setTab] = (0, react.useState)("prompt");
	const [busy, setBusy] = (0, react.useState)(false);
	const [error, setError] = (0, react.useState)("");
	const [message, setMessage] = (0, react.useState)("");
	(0, react.useEffect)(() => {
		const controller = new AbortController();
		userAgentApi.list().then((rows) => {
			if (!controller.signal.aborted) setAgents(rows);
		}).catch((error) => {
			if (!controller.signal.aborted) setError(String(error));
		});
		return () => controller.abort();
	}, []);
	const run = async (action) => {
		setBusy(true);
		setError("");
		setMessage("");
		try {
			await action();
		} catch (failure) {
			setError(failure instanceof Error ? failure.message : String(failure));
		} finally {
			setBusy(false);
		}
	};
	const refresh = async () => setAgents(await userAgentApi.list());
	const edit = (agent) => {
		setSelected(agent);
		setDraft({
			id: agent.id,
			name: agent.name,
			description: agent.description,
			prompt: agent.prompt,
			enabled: agent.enabled
		});
		setAdding(false);
		setTab("prompt");
		setError("");
		setMessage("");
	};
	const save = (event) => {
		event.preventDefault();
		run(async () => {
			const agent = await (selected?.origin === "plugin" ? userAgentApi.savePlugin(selected.id, draft.prompt) : userAgentApi.save(draft));
			setSelected(agent);
			setDraft(agent);
			setAdding(false);
			await refresh();
			setMessage(t(agent.publication === "failed" ? "agentSavedUnavailable" : "agentSaved"));
		});
	};
	const toggle = (agent) => void run(async () => {
		const result = await (agent.origin === "plugin" ? userAgentApi.setPluginEnabled(agent.id, !agent.enabled) : userAgentApi.setEnabled(agent.id, !agent.enabled));
		if (selected?.id === agent.id) {
			setSelected(result);
			setDraft((value) => ({
				...value,
				enabled: result.enabled
			}));
		}
		await refresh();
	});
	const start = (agent) => void run(async () => {
		if (!startAgent) throw Error(t("agentHostUnavailable"));
		const { preset } = agent.origin === "plugin" ? agent : await userAgentApi.select(agent.id);
		await startAgent(preset);
	});
	const leaveEditor = () => {
		setSelected(void 0);
		setDraft(blank());
		setError("");
		setMessage("");
	};
	const fields = /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("label", { children: [t("agentName"), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
			autoFocus: adding,
			disabled: busy || selected?.origin === "plugin",
			required: true,
			maxLength: 160,
			value: draft.name,
			onChange: (event) => setDraft((value) => ({
				...value,
				name: event.target.value
			}))
		})] }),
		/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("label", { children: [t("agentDescription"), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
			disabled: busy || selected?.origin === "plugin",
			maxLength: 1e3,
			value: draft.description,
			onChange: (event) => setDraft((value) => ({
				...value,
				description: event.target.value
			}))
		})] }),
		/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("label", { children: [t("agentPrompt"), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("textarea", {
			disabled: busy,
			required: true,
			rows: adding ? 6 : 12,
			maxLength: 48e3,
			value: draft.prompt,
			onChange: (event) => setDraft((value) => ({
				...value,
				prompt: event.target.value
			}))
		})] })
	] });
	const enable = (agent) => /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
		type: "button",
		role: "switch",
		"aria-label": t("agentEnabled", { name: agent.name }),
		"aria-checked": agent.enabled,
		className: agent.enabled ? user_agents_module_default.switchOn : user_agents_module_default.switchOff,
		disabled: busy,
		onClick: () => toggle(agent),
		children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {})
	});
	return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("section", {
		className: `${user_agents_module_default.workspace} ${surface === "settings" ? user_agents_module_default.settingsWorkspace : ""}`,
		children: [
			selected ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
					type: "button",
					className: user_agents_module_default.back,
					disabled: busy,
					onClick: leaveEditor,
					children: t("agentBack")
				}),
				/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("header", {
					className: user_agents_module_default.heading,
					children: [
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
							className: user_agents_module_default.icon,
							children: agentIcon
						}),
						/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							className: user_agents_module_default.title,
							children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("h2", { children: selected.name }), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", { children: selected.description || t(selected.origin === "plugin" ? "agentMcpPlugin" : "agentPersonal") })]
						}),
						/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("details", {
							className: user_agents_module_default.menu,
							children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("summary", {
								"aria-label": t("agentMore"),
								children: "⋯"
							}), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: user_agents_module_default.menuItems,
								children: [
									selected.pluginSource && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("details", {
										className: user_agents_module_default.sourceInfo,
										children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("summary", { children: t("agentSourceInfo") }), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("dl", { children: [
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)("dt", { children: t("agentCubeSource") }),
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)("dd", { children: selected.pluginSource.sourceRef }),
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)("dt", { children: t("agentSourceVersion") }),
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)("dd", { children: selected.pluginSource.version })
										] })]
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
										type: "button",
										disabled: busy || selected.publication !== "ready",
										onClick: () => start(selected),
										children: t("agentStart")
									}),
									selected.origin === "plugin" && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
										type: "button",
										disabled: busy,
										onClick: () => void run(async () => {
											const copied = await userAgentApi.copyPlugin(selected.id);
											await refresh();
											edit(copied);
										}),
										children: t("agentCopyPersonal")
									}),
									selected.origin === "user" && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(AgentRecovery, {
										agent: selected,
										t,
										onChanged: (agent) => {
											setSelected(agent);
											setDraft(agent);
											setAgents((rows) => rows.map((row) => row.id === agent.id ? agent : row));
										},
										onChooseAnother: leaveEditor
									}, selected.id)
								]
							})]
						}),
						!selected.deletedAt && enable(selected)
					]
				}),
				selected.error && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
					role: "alert",
					className: user_agents_module_default.error,
					children: selected.error === "AGENT_SOURCE_IMPORT_INCOMPLETE" ? t("agentSourceIncomplete") : selected.error
				}),
				!selected.deletedAt && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("nav", {
					className: user_agents_module_default.tabs,
					"aria-label": t("agentConfiguration"),
					children: [
						"prompt",
						"skill",
						"mcp"
					].map((value) => /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: busy,
						"aria-current": tab === value ? "page" : void 0,
						onClick: () => setTab(value),
						children: t(value === "prompt" ? "agentPrompt" : value === "skill" ? "agentSkill" : "agentMcp")
					}, value))
				}), tab === "prompt" ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("form", {
					onSubmit: save,
					children: [fields, /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("footer", {
						className: user_agents_module_default.actions,
						children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
							type: "button",
							disabled: busy,
							onClick: leaveEditor,
							children: t("cancel")
						}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
							className: user_agents_module_default.primary,
							disabled: busy,
							type: "submit",
							children: t("save")
						})]
					})]
				}) : tab === "skill" ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)(AgentSkills, {
					agent: selected,
					t,
					onSaved: (agent) => {
						setSelected(agent);
						setAgents((rows) => rows.map((row) => row.id === agent.id ? agent : row));
					}
				}, selected.id) : selected.origin === "plugin" ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)(PluginMcpPanel, {
					agent: selected,
					t,
					onSaved: (agent) => setSelected(agent)
				}, selected.id) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)(AgentMcpPanel, {
					agent: selected,
					t,
					onSaved: (agent) => {
						setSelected(agent);
						setAgents((rows) => rows.map((row) => row.id === agent.id ? agent : row));
					}
				}, selected.id)] })
			] }) : /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("header", {
					className: user_agents_module_default.heading,
					children: [
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
							className: user_agents_module_default.title,
							children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("h2", { children: t("agentConfiguration") })
						}),
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
							type: "button",
							disabled: busy,
							"aria-label": t("refresh"),
							className: user_agents_module_default.iconButton,
							title: t("refresh"),
							"aria-busy": busy,
							onClick: () => void run(refresh),
							children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.IconRefreshOutlineRegular, { size: 18 })
						}),
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-expanded": showSources,
							onClick: () => {
								setSourceRequest(void 0);
								setAdding(false);
								setShowSources((value) => !value);
							},
							children: t("agentSources")
						}),
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
							className: user_agents_module_default.primary,
							type: "button",
							disabled: busy,
							onClick: () => {
								setDraft(blank());
								setAdding(true);
								setShowSources(false);
								setSourceRequest(void 0);
								setMessage("");
							},
							children: t("agentAdd")
						})
					]
				}),
				adding && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("form", {
					className: user_agents_module_default.inline,
					onSubmit: save,
					children: [fields, /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("footer", {
						className: user_agents_module_default.actions,
						children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
							type: "button",
							disabled: busy,
							onClick: () => setAdding(false),
							children: t("cancel")
						}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
							className: user_agents_module_default.primary,
							type: "submit",
							disabled: busy,
							children: t("save")
						})]
					})]
				}),
				showSources && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(AgentSources, {
					t,
					agents,
					initialSyncId: sourceRequest?.id,
					onImported: refresh,
					onClose: () => {
						setShowSources(false);
						setSourceRequest(void 0);
					}
				}, sourceRequest?.request ?? 0),
				/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("p", {
					className: user_agents_module_default.sectionTitle,
					children: [
						t("agentCurrent"),
						" ",
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { children: agents.filter((agent) => !agent.deletedAt).length })
					]
				}),
				agents.map((agent) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("article", {
					className: user_agents_module_default.row,
					children: [
						/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("button", {
							className: user_agents_module_default.identity,
							type: "button",
							disabled: busy,
							onClick: () => edit(agent),
							children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
								className: user_agents_module_default.icon,
								children: agentIcon
							}), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("strong", { children: agent.name }), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
								className: user_agents_module_default.description,
								children: [
									agent.description || t("agentPersonal"),
									agent.customized ? ` · ${t("agentSourceCustomized")}` : "",
									agent.publication === "deleted" ? ` · ${t("agentDeleted")}` : agent.publication === "failed" ? ` · ${t("agentUnavailable")}` : ""
								]
							})] })]
						}),
						agent.source && !agent.deletedAt && !agent.source.importPending && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
							type: "button",
							className: user_agents_module_default.textButton,
							"aria-label": t("agentSourceSync"),
							disabled: busy,
							onClick: () => {
								setAdding(false);
								setShowSources(true);
								setSourceRequest((previous) => ({
									id: agent.id,
									request: (previous?.request ?? 0) + 1
								}));
							},
							children: t("agentUpdate")
						}),
						!agent.deletedAt && enable(agent)
					]
				}, agent.id)),
				/* @__PURE__ */ (0, react_jsx_runtime.jsx)(TrustedPluginAgents, {
					onEdit: edit,
					t
				}),
				!agents.length && !adding && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
					className: user_agents_module_default.muted,
					children: t("agentEmpty")
				})
			] }),
			error && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
				role: "alert",
				className: user_agents_module_default.error,
				children: error
			}),
			message && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
				role: "status",
				className: user_agents_module_default.muted,
				children: message
			})
		]
	});
}
//#endregion
//#region src/client/PluginWorkspace.tsx
/** Shared Agent configuration entry for main and settings. */
/** The complete Agent editor has one implementation across public seats. */
function PluginWorkspace(props) {
	return (0, react.createElement)(UserAgentWorkspace, {
		t: props.t,
		startAgent: props.startAgent,
		surface: props.surface
	});
}
//#endregion
//#region src/client/plugin-settings.module.css
var plugin_settings_module_default = {
	"market-config": "UsIx-W_market-config",
	"pluginCard": "UsIx-W_pluginCard",
	"pluginCardBody": "UsIx-W_pluginCardBody",
	"pluginCardDesc": "UsIx-W_pluginCardDesc",
	"pluginCardError": "UsIx-W_pluginCardError",
	"pluginCardHeader": "UsIx-W_pluginCardHeader",
	"pluginCardOpen": "UsIx-W_pluginCardOpen",
	"pluginCardRow": "UsIx-W_pluginCardRow",
	"pluginCardRowLabel": "UsIx-W_pluginCardRowLabel",
	"pluginCardText": "UsIx-W_pluginCardText",
	"pluginCardTitle": "UsIx-W_pluginCardTitle",
	"pluginChevron": "UsIx-W_pluginChevron",
	"pluginChevronOpen": "UsIx-W_pluginChevronOpen",
	"regionSeg": "UsIx-W_regionSeg",
	"regionSegBtn": "UsIx-W_regionSegBtn",
	"regionSegOn": "UsIx-W_regionSegOn",
	"switchOff": "UsIx-W_switchOff",
	"switchOn": "UsIx-W_switchOn",
	"switchThumb": "UsIx-W_switchThumb"
};
//#endregion
//#region src/client/ui/ToggleSwitch.tsx
/** Shared switch control (ON = primary button fill, like every host toggle). */
/** 文件作用：提供可复用的开关按钮外观和无障碍语义，具体启停业务由 onChange 回调处理。 */
/** A green/gray switch control for suite enable state. */
/** 中文：绿色表示启用、灰色表示停用，点击事件由父组件决定具体业务。 */
function ToggleSwitch(props) {
	/** 将布尔状态渲染为开关按钮，点击时阻止卡片冒泡并通知父级切换。 */
	return (0, react.createElement)("button", {
		type: "button",
		role: "switch",
		"aria-checked": props.on,
		title: props.title,
		"aria-label": props.title,
		disabled: props.disabled,
		className: props.on ? plugin_settings_module_default.switchOn : plugin_settings_module_default.switchOff,
		onClick: (event) => {
			event.stopPropagation();
			props.onChange();
		}
	}, (0, react.createElement)("span", { className: plugin_settings_module_default.switchThumb }));
}
//#endregion
//#region src/client/McpPluginCard.tsx
/**
* The Agent Plugins Market card on the host's 插件配置 (plugin configuration)
* tab: the market feature's configuration entry, named after the market
* itself. Disclosed inside is the MCP enhancement switch — ON (default)
* mounts suite MCP servers through the market's built-in bridge (OAuth
* authorization, SSE, browser-leg hold); OFF falls back to the host's
* `dsh-mcp-client` compatibility client.
*
* The switch state is the market's host settings namespace (bound by the
* client entry), so a flip persists through the host settings document and
* the node half's namespace watcher remounts the servers. The host client
* version probe rides the market's own API.
*
* 文件作用：渲染宿主“插件配置”页中的 Agent Plugins 配置卡片。
* 业务职责：展示并持久化 MCP 增强模式、下载区域、项目布局扫描和反馈工具开关，同时用宿主探针解释兼容模式是否可用。
*/
/** The host's disclosure chevron, matching the native cards' glyph exactly. */
/** 中文：使用宿主原生展开箭头，保持插件配置卡的视觉一致性。 */
const chevronIcon = _deepseek_ai_dsh_client_ui_primitives["IconChevronDownOutline14"];
/** 绑定宿主设置命名空间，渲染 MCP 运行模式及相关体验开关。 */
function McpPluginCard({ t, scope, probe }) {
	const [open, setOpen] = (0, react.useState)(false);
	const [, setTick] = (0, react.useState)(0);
	const [probeInfo, setProbeInfo] = (0, react.useState)(void 0);
	const [busy, setBusy] = (0, react.useState)(false);
	const [error, setError] = (0, react.useState)(void 0);
	(0, react.useEffect)(() => scope.subscribe(() => setTick((tick) => tick + 1)), [scope]);
	/** 读取宿主 MCP 客户端能力和下载区域；探针失败只隐藏版本信息。 */
	const refreshProbe = (0, react.useCallback)(async () => {
		try {
			setProbeInfo(await probe());
		} catch {}
	}, [probe]);
	(0, react.useEffect)(() => {
		refreshProbe();
	}, [refreshProbe]);
	const enhanced = scope.enhanced();
	const writable = scope.writable();
	const regionSetting = scope.region();
	const effectiveRegion = regionSetting === "auto" ? probeInfo?.downloadRegion.effective ?? "global" : regionSetting;
	const hostUsable = probeInfo?.hostClient.available === true;
	/** 切换 MCP 增强模式，兼容模式不可用时保留当前状态并提示原因。 */
	const onToggle = () => {
		if (busy || !writable) return;
		const next = !enhanced;
		if (!next && !hostUsable) {
			setError(t("mcpBackendHostMissing"));
			return;
		}
		setBusy(true);
		setError(void 0);
		scope.setEnhanced(next).then(() => {
			setBusy(false);
		}).catch((cause) => {
			setError(cause instanceof Error ? cause.message : String(cause));
			setBusy(false);
		});
	};
	return (0, react.createElement)("div", {
		className: open ? `${plugin_settings_module_default.pluginCard} ${plugin_settings_module_default.pluginCardOpen}` : plugin_settings_module_default.pluginCard,
		"data-busy": busy ? "true" : void 0
	}, (0, react.createElement)("button", {
		type: "button",
		className: plugin_settings_module_default.pluginCardHeader,
		"aria-expanded": open,
		onClick: () => {
			setOpen((current) => !current);
		}
	}, (0, react.createElement)("div", { className: plugin_settings_module_default.pluginCardText }, (0, react.createElement)("div", { className: plugin_settings_module_default.pluginCardTitle }, t("nav")), (0, react.createElement)("div", { className: plugin_settings_module_default.pluginCardDesc }, t("marketCardDesc"))), (0, react.createElement)("span", { className: open ? `${plugin_settings_module_default.pluginChevron} ${plugin_settings_module_default.pluginChevronOpen}` : plugin_settings_module_default.pluginChevron }, chevronIcon !== void 0 ? (0, react.createElement)(chevronIcon, { size: 14 }) : "▾")), open ? (0, react.createElement)("div", { className: plugin_settings_module_default.pluginCardBody }, (0, react.createElement)("div", { className: plugin_settings_module_default.pluginCardRow }, (0, react.createElement)("div", { className: plugin_settings_module_default.pluginCardText }, (0, react.createElement)("div", { className: plugin_settings_module_default.pluginCardRowLabel }, t("mcpCardTitle")), (0, react.createElement)("div", { className: plugin_settings_module_default.pluginCardDesc }, enhanced ? t("mcpCardDescOn") : t("mcpCardDescOff"))), (0, react.createElement)(ToggleSwitch, {
		on: enhanced,
		disabled: busy || !writable,
		title: writable ? void 0 : t("mcpCardReadonly"),
		onChange: onToggle
	})), error !== void 0 ? (0, react.createElement)("div", { className: plugin_settings_module_default.pluginCardError }, error) : null, (0, react.createElement)("div", { className: plugin_settings_module_default.pluginCardRow }, (0, react.createElement)("div", { className: plugin_settings_module_default.pluginCardText }, (0, react.createElement)("div", { className: plugin_settings_module_default.pluginCardRowLabel }, t("regionLabel")), (0, react.createElement)("div", { className: plugin_settings_module_default.pluginCardDesc }, t("regionHint"))), (0, react.createElement)("div", { className: plugin_settings_module_default.regionSeg }, ["global", "china"].map((region) => (0, react.createElement)("button", {
		key: region,
		type: "button",
		disabled: busy || !writable,
		className: effectiveRegion === region ? plugin_settings_module_default.regionSegOn : plugin_settings_module_default.regionSegBtn,
		"aria-pressed": effectiveRegion === region,
		onClick: () => {
			if (regionSetting === region) return;
			setBusy(true);
			setError(void 0);
			scope.setRegion(region).then(() => {
				setBusy(false);
			}).catch((cause) => {
				setError(cause instanceof Error ? cause.message : String(cause));
				setBusy(false);
			});
		}
	}, region === "global" ? t("regionGlobal") : t("regionChina"))))), scope.scanProjectLayouts !== void 0 && scope.setScanProjectLayouts !== void 0 ? (0, react.createElement)("div", { className: plugin_settings_module_default.pluginCardRow }, (0, react.createElement)("div", { className: plugin_settings_module_default.pluginCardText }, (0, react.createElement)("div", { className: plugin_settings_module_default.pluginCardRowLabel }, t("projectLayoutsLabel"))), (0, react.createElement)(ToggleSwitch, {
		on: scope.scanProjectLayouts(),
		title: t("projectLayoutsLabel"),
		disabled: busy || !writable,
		onChange: () => {
			if (busy || !writable) return;
			setBusy(true);
			setError(void 0);
			scope.setScanProjectLayouts(!scope.scanProjectLayouts()).catch((cause) => {
				setError(cause instanceof Error ? cause.message : String(cause));
			}).finally(() => setBusy(false));
		}
	})) : null, scope.feedbackEnabled !== void 0 && scope.setFeedbackEnabled !== void 0 ? (0, react.createElement)("div", { className: plugin_settings_module_default.pluginCardRow }, (0, react.createElement)("div", { className: plugin_settings_module_default.pluginCardText }, (0, react.createElement)("div", { className: plugin_settings_module_default.pluginCardRowLabel }, t("feedbackToggleLabel")), (0, react.createElement)("div", { className: plugin_settings_module_default.pluginCardDesc }, scope.feedbackEnabled() ? t("feedbackToggleDescOn") : t("feedbackToggleDescOff"))), (0, react.createElement)(ToggleSwitch, {
		on: scope.feedbackEnabled(),
		disabled: busy || !writable,
		onChange: () => {
			if (busy || !writable) return;
			setBusy(true);
			setError(void 0);
			scope.setFeedbackEnabled(!scope.feedbackEnabled()).then(() => {
				setBusy(false);
			}).catch((cause) => {
				setError(cause instanceof Error ? cause.message : String(cause));
				setBusy(false);
			});
		}
	})) : null) : null);
}
//#endregion
//#region src/plugin-package-version.ts
/** Package identity captured at build time; immutable after module loading. */
const pluginPackageVersion = Object.freeze({
	name: "dsh-agent-manage",
	version: "0.6.3-company.15"
});
//#endregion
//#region src/client/index.ts
/**
* dsh-agent-plugins-market client: registers the Agent Plugins Market section inside the Web
* GUI's settings page (the same settings.section seat dshmarket uses), with a
* current settings.section contract as its only surface. The bundle's
* browser externals are React, ReactDOM, and the injected `dsh.client.inject`
* module table, so it cannot reach packages the host does not serve.
*
* 文件作用：插件客户端入口，向宿主注册翻译、忙碌遮罩和正式设置区工作台。
* 业务职责：检查宿主 UI 能力、绑定设置命名空间，并把配置读写委托给宿主服务；入口本身不承载市场业务数据。
*/
const NS = "dsh-agent-plugins-market";
const SETTINGS_NAMESPACE = "dsh-agent-manage";
const name = "dsh-agent-manage";
const inject = ["slots", "locale"];
const REQUIRED_PRIMITIVES = [
	"Button",
	"Input",
	"Modal",
	"Toast",
	"Tooltip"
];
/**
* Register the MCP enhancement card into the host's shared 插件配置 tab
* (`settings.plugin.item`), the same seat dshmarket uses. Called through
* `ctx.inject(['settingsScope'])` at apply time; a host without the
* settingsScope service simply skips the card.
*/
/** Detect host primitives that predate the exports this UI relies on. */
/** 检查宿主是否提供市场 UI 依赖的基础组件，缺失时返回能力缺口。 */
function missingPrimitives(module, required = REQUIRED_PRIMITIVES) {
	return required.filter((name) => module[name] === void 0);
}
/** 注册客户端插件的所有宿主效果，仅挂载当前宿主的设置槽位。 */
function apply(ctx) {
	ctx.effect(() => {
		if (typeof document === "undefined" || typeof __dshManageClientCss !== "string") return;
		const style = document.createElement("style");
		style.dataset.dshClient = "dsh-agent-manage";
		style.dataset.plugin = "dsh-agent-manage";
		style.textContent = __dshManageClientCss;
		document.head.append(style);
		return () => style.remove();
	}, "dsh-agent-manage: styles");
	ctx.effect(() => ctx.locale.register(NS, {
		zh,
		en
	}), "dsh-agent-plugins: dictionaries");
	const t = ctx.locale.bind(NS);
	const gaps = missingPrimitives(_deepseek_ai_dsh_client_ui_primitives);
	if (gaps.length > 0) throw new Error(`UNSUPPORTED_HOST_UI_PRIMITIVES: ${gaps.join(", ")}`);
	ctx.effect(() => {
		if (typeof document === "undefined") return;
		const element = document.createElement("div");
		element.dataset.agentPluginsBusyHost = "";
		document.body.append(element);
		const root = (0, react_dom_client.createRoot)(element);
		root.render((0, react.createElement)(BusyOverlay, { t }));
		return () => {
			root.unmount();
			element.remove();
		};
	}, "dsh-agent-plugins-market: operation overlay");
	ctx.inject(["settingsScope"], (scoped) => {
		const service = scoped.settingsScope;
		const slots = scoped.slots;
		const tCard = ctx.locale.bind(NS);
		const scope = service.bind({ namespace: SETTINGS_NAMESPACE });
		slots.inject("settings.plugin.item", () => slots.register({
			name: "settings.plugin.item",
			key: SETTINGS_NAMESPACE,
			locale: NS,
			inject: () => ({ t: tCard })
		}, () => (0, react.createElement)(McpPluginCard, {
			t: (key) => tCard(key),
			scope: {
				enhanced: () => scope.getSnapshot().value?.mcpEnhanced !== false,
				writable: () => scope.getSnapshot().writable,
				subscribe: (listener) => scope.subscribe(listener),
				setEnhanced: (next) => withBusyOperation(() => scope.set("mcpEnhanced", next)),
				region: () => {
					const value = scope.getSnapshot().value?.downloadRegion;
					return value === "global" || value === "china" ? value : "auto";
				},
				setRegion: (next) => withBusyOperation(() => scope.set("downloadRegion", next)),
				feedbackEnabled: () => scope.getSnapshot().value?.feedbackEnabled !== false,
				setFeedbackEnabled: (next) => withBusyOperation(() => scope.set("feedbackEnabled", next)),
				scanProjectLayouts: () => scope.getSnapshot().value?.scanProjectLayouts !== false,
				setScanProjectLayouts: (next) => withBusyOperation(() => scope.set("scanProjectLayouts", next))
			},
			probe: () => fetchMcpBackend()
		})));
	});
	let beginAgent;
	const startAgent = async (preset) => {
		if (!beginAgent) throw Error(t("agentHostUnavailable"));
		await beginAgent(preset);
	};
	ctx.inject(["agentWorkbench"], (scoped) => {
		beginAgent = (preset) => scoped.agentWorkbench.startAgent(preset);
		scoped.effect(() => () => {
			beginAgent = void 0;
		});
		scoped.effect(() => scoped.agentWorkbench.register({
			id: "agent-plugin-workspace",
			label: () => t("nav")
		}));
	});
	ctx.slots.inject("main", () => ctx.slots.register({
		name: "main",
		key: "agent-plugin-workspace"
	}, () => (0, react.createElement)("section", {
		className: "agent-workbench-ui",
		style: { height: "100%" }
	}, (0, react.createElement)(PluginWorkspace, {
		t,
		startAgent
	}))));
	ctx.slots.inject("settings.section", () => {
		const workspaceDispose = ctx.slots.register({
			name: "settings.section",
			id: "agent-plugin-workspace",
			order: 45,
			label: () => t("nav"),
			locale: NS,
			inject: () => ({ t })
		}, () => (0, react.createElement)(PluginWorkspace, {
			t,
			startAgent,
			surface: "settings"
		}));
		return () => {
			if (typeof workspaceDispose === "function") workspaceDispose();
		};
	});
}
//#endregion
exports.REQUIRED_PRIMITIVES = REQUIRED_PRIMITIVES;
exports.apply = apply;
exports.inject = inject;
exports.missingPrimitives = missingPrimitives;
exports.name = name;
exports.pluginPackageVersion = pluginPackageVersion;

//# sourceMappingURL=client.js.map
		return module.exports;
}
});
