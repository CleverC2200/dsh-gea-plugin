import type { SkillContent, SuiteDetail } from '../contracts/market.js';
import { type InstalledEntry, type Suite } from '../model/types.js';
import type { McpMountDiagnostic as McpDiagnostic } from '../runtime/mcp-mounts.js';
/** Build the detail response for one normalized suite. 中文：合并 suite、安装状态、挂载诊断和 MCP 覆盖值，生成详情弹窗的完整响应。 */
export declare function buildSuiteDetail(suite: Suite, installed: InstalledEntry | undefined, diagnostics: readonly McpDiagnostic[], mcpOverrides?: Record<string, Record<string, unknown>>): Promise<SuiteDetail>;
/** Read one skill body from a normalized suite. 中文：按名称定位技能并读取完整 SKILL.md，找不到或无法读取时返回可理解的错误。 */
export declare function readSkillContent(suite: Suite, skillName: string): Promise<SkillContent>;
