import type { UserPanelEntryWire, UserPanelKind } from '../contracts/market.js';
import type { UserPanelStore } from '../runtime/user-panels.js';
import type { Catalog } from './catalog.js';
/** The routes consume this structural surface, also implemented by user-only stores in tests. 中文：路由层依赖的面板资源仓库接口，测试可用纯用户资源实现替换。 */
export interface PanelResourceStore {
    /** Strict runtime reads propagate I/O failures so catalogs cannot publish partial replacements. 中文：列出全部资源；严格模式会向上抛出 I/O 失败，避免发布不完整快照。 */
    list(strict?: boolean): Promise<UserPanelEntryWire[]>;
    /** 按稳定 id 查找单个面板资源，不存在时返回 undefined。 */
    get(id: string): Promise<UserPanelEntryWire | undefined>;
    /** 在用户资源区创建一个新条目。 */
    create(name: string, text: string): Promise<UserPanelEntryWire>;
    /** 更新用户资源；插件资源只读。 */
    update(id: string, text: string): Promise<void>;
    /** 删除用户资源；插件资源只读。 */
    remove(id: string): Promise<void>;
}
/** 为三类用户面板创建统一资源仓库，共享同一 Catalog 与对应的用户存储。 */
export declare function createPanelResources(catalog: Catalog, users: Record<UserPanelKind, UserPanelStore>): Record<UserPanelKind, PanelResourceStore>;
