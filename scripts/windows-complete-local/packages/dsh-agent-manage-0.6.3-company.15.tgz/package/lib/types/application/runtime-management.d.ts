/** Resource runtime operations share one owner for configuration, live mounts and their lifecycle. */
import type { Context } from '@deepseek-ai/cordis';
import type { Suite } from '../model/types.js';
import type { HostTranslate } from '../runtime/host-locale.js';
import { type McpToolSnapshot } from '../runtime/mcp-status.js';
import type { McpMountDiagnostic } from '../runtime/mcp-mounts.js';
import { type McpServerOverride, type McpSuiteOverrides } from '../runtime/mcp-overrides.js';
import { type HostMcpClientProbe, type McpBackend } from '../runtime/mcp-backend.js';
import { type DownloadRegionSetting, type EffectiveRegion } from '../runtime/regions.js';
import type { McpStatusPayload } from '../contracts/mcp-status.js';
import type { LspStatusPayload } from '../contracts/lsp-status.js';
import type { ServerConfigPayload } from '../contracts/market.js';
/** Host adapters are resolved lazily because Cordis services can arrive after Manage. */
export interface RuntimeHost {
    ctx: Context;
    translate: HostTranslate;
    backend(): Promise<McpBackend>;
    writeBackend(backend: McpBackend): Promise<void>;
    tools(): readonly McpToolSnapshot[];
    deleteGrantRecord(serverName: string): Promise<void>;
}
interface RuntimeCatalog {
    suites(): Promise<Suite[]>;
    enabledSuites(): Promise<Suite[]>;
    resolveSuite(sourceId: string, suiteId: string): Promise<Suite>;
    change<T>(operation: () => Promise<T>): Promise<T>;
    downloadRegion(): Promise<DownloadRegionSetting>;
}
export declare class RuntimeManagement {
    private readonly dataRoot;
    private readonly catalog;
    private readonly host?;
    private readonly reconciler;
    private diagnostics;
    private requested;
    private reconciliation;
    private disposed;
    private credentialFlush;
    private readonly stopCredentials;
    constructor(dataRoot: string, catalog: RuntimeCatalog, host?: RuntimeHost | undefined);
    /** Latest completed mount diagnostics, also used in Catalog's coherent market projection. */
    get mcpDiagnostics(): McpMountDiagnostic[];
    /** Coalesce slow mounts into the current pass and one fresh follow-up snapshot. */
    reconcile(): Promise<void>;
    /** Stop events and release each surface after its own active pass, without delaying local cleanup behind MCP. */
    dispose(): Promise<void>;
    private warn;
    /**
     * Drop one MCP server's OAuth grant record so the next mount re-runs the
     * browser authorization — the path for "I picked too narrow a scope".
     * @param serverName - the derived serverName whose folded form keys the record.
     * @throws when the credentials service is not mounted.
     * 中文：删除指定服务的授权记录，标记其挂载键重建，并触发一次运行时协调。
     */
    reauthorizeMcpServer(serverName: string): Promise<void>;
    /** Cancel the pending OAuth loopback leg without altering the saved configuration. */
    cancelMcpAuthorization(serverName: string): void;
    /** Whether the re-authorize action can run in this composition. */
    /** 中文：报告当前宿主组合是否提供凭据存储。 */
    mcpReauthorizeAvailable(): boolean;
    /** Build the flat MCP service inventory for the status surface. */
    /** 中文：合并套件、用户直配服务、挂载诊断和工具快照，生成 MCP 平面清单。 */
    mcpStatus(): Promise<McpStatusPayload>;
    /** Persist a user-owned MCP service and reconcile its bridge mount. */
    /** 中文：保存用户直配 MCP 服务，并通知宿主重新协调其挂载。 */
    addMcpServer(name: string, server: unknown, sourceRoot?: string): Promise<void>;
    /** Read effective service configuration without exposing credential literals. */
    /** 中文：读取服务生效配置并脱敏凭据，供客户端详情编辑器使用。 */
    serverConfig(kind: 'mcp' | 'lsp', id: string): Promise<ServerConfigPayload>;
    /** Host-only sync comparison. Never send these credential-bearing values to a client. */
    sourceSyncConfig(id: string): Promise<{
        base: unknown;
        local: unknown;
    }>;
    /** 按客户端服务 ID 定位套件或直配服务，并返回可编辑配置上下文。 */
    private resolveServerConfig;
    /** Validate a complete replacement before writing; plugin checkouts remain untouched. */
    /** 中文：校验完整替换配置并写入覆盖层/直配文件，不修改插件源检出内容。 */
    saveServerConfig(kind: 'mcp' | 'lsp', id: string, config: unknown): Promise<void>;
    /** The LSP status surface: declared servers merged with mount diagnostics. */
    /** 中文：合并套件声明、用户直配服务和挂载诊断，生成 LSP 状态面板数据。 */
    lspStatus(): Promise<LspStatusPayload>;
    /** The user's direct LSP server table (normalized specs). */
    /** 中文：读取用户直接配置且已规范化的 LSP 服务表。 */
    lspServers(): Promise<Record<string, import('../model/types.js').LspServerSpec>>;
    /** Create one direct LSP declaration without replacing other user servers. */
    /** 中文：校验并新增一个用户直配 LSP，不覆盖现有服务。 */
    addLspServer(name: string, config: unknown): Promise<void>;
    /** Validate and persist the user's direct LSP server table. */
    /** 中文：校验并整体保存用户直配 LSP 服务表，然后触发挂载协调。 */
    setLspServers(raw: unknown): Promise<Record<string, import('../model/types.js').LspServerSpec>>;
    /** 切换单个用户直配 LSP 的禁用集合记录，并触发状态刷新。 */
    setLspServerEnabled(id: string, enabled: boolean): Promise<void>;
    /** One suite's persisted MCP overrides, addressed by qualified suite id. */
    /** 中文：读取指定套件的 MCP 覆盖配置，并在返回前脱敏。 */
    mcpOverrides(sourceId: string, suiteId: string): Promise<McpSuiteOverrides>;
    /**
     * Set or clear one server's MCP override and remount it. `override === null`
     * clears the override (back to the source config). The serverKey must exist
     * in the suite's parsed mcp.json.
     * 中文：设置或清除指定 MCP 服务覆盖，并在保存后触发重新挂载。
     */
    setMcpOverride(sourceId: string, suiteId: string, serverKey: string, override: McpServerOverride | null): Promise<void>;
    /**
     * Re-run the MCP reconcile pass: retries failed mounts and clears residual
     * tools, without changing any catalog state.
     * 中文：仅重新执行 MCP 协调，不改变目录状态。
     */
    retryMounts(): Promise<void>;
    /** The persisted backend choice without the host-client probe (mount-time provider). */
    /** 中文：读取持久化后端选择，不额外探测宿主客户端。 */
    mcpBackend(): Promise<McpBackend>;
    /**
     * The active MCP mount backend plus a live probe of the host client, and
     * the download-region setting with its locale-resolved effective route —
     * everything the plugin-config card renders.
     * 中文：返回配置卡所需的后端选择、宿主客户端探针和区域生效线路。
     */
    mcpBackendInfo(): Promise<{
        backend: McpBackend;
        hostClient: HostMcpClientProbe;
        downloadRegion: {
            setting: DownloadRegionSetting;
            effective: EffectiveRegion;
        };
    }>;
    /**
     * Switch the MCP mount backend and remount every suite server through it.
     * A host-client switch takes effect only where the host package resolves;
     * unresolvable or unsupported transports surface as per-server diagnostics.
     * 中文：切换 MCP 挂载后端并触发全部套件服务重新协调，逐服务暴露不可用原因。
     */
    setMcpBackend(backend: McpBackend): Promise<void>;
    /** MCP overrides for a supplied runtime selection, or the full market catalog when omitted. */
    /** 中文：读取指定运行时套件集合的 MCP 覆盖；未传集合时读取完整市场目录。 */
    allMcpOverrides(suites?: readonly Suite[]): Promise<Map<string, McpSuiteOverrides>>;
}
export {};
