import { type AgentRoleEntry } from '../runtime/agent-role-router.js';
import type { Catalog } from './catalog.js';
/** 根据父会话的 cwd 读取已启用 suite 中的 agents 资源，解析成可用角色；无有效 cwd 时返回空列表。 */
export declare function projectAgentRoles(catalog: Catalog, parent: unknown): Promise<AgentRoleEntry[]>;
