/** 文件作用：目录应用层的宿主权威入口，统一管理源、套件发现、安装状态和一致性快照。 */
/**
 * Catalog application module: the host-authoritative owner of source state,
 * discovery, install mutations, and coherent suite snapshots.
 *
 * The module deliberately keeps the existing filesystem and Git operations
 * behind one interface. User and
 * project snapshots use their own persisted state files and share the same
 * source-selection and suite-scanning rules.
 *
 * 业务职责：编排文件系统/Git 获取、用户级与项目级扫描、运行时状态查询及变更通知；不把这些副作用散落到调用方。
 */
import { RuntimeManagement, type RuntimeHost } from './runtime-management.js';
import { type GitOptions } from '../catalog/git.js';
import { type DownloadRegionSetting } from '../runtime/regions.js';
import type { OverviewPayload, SkillContent, SuiteDetail } from '../contracts/market.js';
import { type SourceKind, type SourceRef, type Suite, type SuiteDimension, type SuiteSurfaceKey, type SurfaceOverrides } from '../model/types.js';
/**
 * Git network tuning, plumbed from the host config to every remote-touching
 * invocation (proxy, `insteadOf` mirrors, timeout, retry). `fallbackTarball`
 * additionally lets a failed GitHub clone fall back to a codeload tarball
 * download through the archive pipeline.
 * 中文：将代理、镜像、超时、重试和 GitHub 压缩包回退策略集中传给所有远程获取动作。
 */
export interface CatalogGitOptions extends GitOptions {
    /** Retry a failed GitHub clone as a codeload tarball download; default false. */
    /** 中文：GitHub 克隆失败时是否改用 codeload 压缩包，默认关闭。 */
    fallbackTarball?: boolean;
    /** Allow plain-http archive downloads (intranet mirrors); default false. */
    /** 中文：是否允许内网镜像使用明文 HTTP 下载压缩包，默认关闭。 */
    allowHttpArchives?: boolean;
}
/** Dependencies and host callback used by the catalog application module. */
/** 中文：目录应用层运行所需的用户目录、数据目录和宿主变更回调。 */
export interface CatalogOptions {
    userRoot: string;
    dataRoot: string;
    runtime?: RuntimeHost;
    onChanged: () => void | Promise<void>;
    /** Git/archive acquisition tuning. */
    /** 中文：Git 与压缩包获取策略。 */
    git?: CatalogGitOptions;
    /**
     * Freshness window for cached project-dimension snapshots. The project
     * catalog sits on the skill-list hot path (every provider `list()` call),
     * and its inputs — the project's own files — change only through editor
     * saves; a short window keeps listing cheap without going stale. Defaults
     * to 5 seconds; 0 disables caching.
     * 中文：项目快照缓存有效期；0 表示每次读取都扫描项目文件。
     */
    projectSnapshotTtlMs?: number;
    /**
     * Freshness window for the cached user-dimension snapshot (defaults to the
     * scan-cache TTL). It bounds how long out-of-band edits to local sources
     * stay invisible; 0 disables snapshot caching. Tests pass a small value so
     * staleness regressions need no real sleeps.
     * 中文：用户快照缓存有效期，限制外部修改本地源后的可见延迟；0 表示关闭快照缓存。
     */
    userSnapshotTtlMs?: number;
}
/** A coherent discovered-and-installed view for one catalog dimension. */
/** 中文：某个目录维度下，源、发现套件和安装启用状态的一致视图。 */
export interface CatalogSnapshot {
    revision: number;
    sources: SourceRef[];
    suites: Suite[];
    enabledSuites: Suite[];
    /** Per-source scan diagnostics (sourceId → notes), absent when clean. */
    /** 中文：按源保存扫描诊断；没有问题时省略。 */
    scanNotes?: Record<string, string[]>;
}
/** 目录应用服务：串行协调源获取、套件快照、安装状态和运行时变更通知。 */
export declare class Catalog {
    private readonly options;
    private state;
    private mutationQueue;
    private readonly statePath;
    private readonly headCache;
    private readonly listeners;
    private revision;
    private userSnapshot;
    private userSnapshotExpiresAt;
    private userSnapshotPromise;
    /**
     * Discovery scan cache: per-sources-fingerprint scan results with a TTL.
     * Install / enable / surface toggles re-derive the snapshot from cached
     * discovery (cheap mapping) instead of re-walking every checkout — a full
     * rescan of a 2,500-suite catalog costs ~1s and UI mutations happen in
     * bursts. Content-changing mutations (add / update / remove / adopt /
     * refresh / acquire) clear every cached discovery generation; the TTL
     * bounds staleness for in-place working-tree
     * edits of local sources.
     * 中文：按源指纹缓存扫描结果；状态开关只重映射缓存，内容变更或 TTL 到期才重新扫描。
     */
    private readonly scanCache;
    private scanGeneration;
    private readonly scanPromises;
    private static readonly SCAN_CACHE_TTL_MS;
    private static readonly SCAN_CACHE_MAX_ENTRIES;
    /**
     * User-dimension snapshot TTL: bounded staleness for edits made outside the
     * plugin (a new skill dropped into a local source's working tree, a hand
     * edit in a project layout) becomes visible on the next read past the TTL
     * instead of living until the next mutation. Configurable; a 0 value
     * disables snapshot caching entirely.
     * 中文：用户维度快照的缓存时长，避免外部改动永久不可见；设为 0 时完全禁用。
     */
    private readonly userSnapshotTtlMs;
    /** Project-dimension snapshots keyed by project root, with TTL freshness. */
    /** 中文：按项目根目录保存带 TTL 的项目维度快照。 */
    private readonly projectSnapshots;
    private readonly projectSnapshotPromises;
    private readonly projectSnapshotTtlMs;
    readonly runtime: RuntimeManagement;
    /** Download-region source (the host settings namespace scope). */
    /** 中文：读取宿主设置中的下载区域。 */
    private downloadRegionProvider;
    private scanProjectLayouts;
    /** Apply the host's project-layout switch and invalidate every project snapshot. */
    /** 中文：切换项目布局扫描开关，并使已有项目快照失效。 */
    setScanProjectLayouts(enabled: boolean): Promise<void>;
    /** 初始化目录路径、快照 TTL 和宿主依赖，但不主动读取磁盘状态。 */
    constructor(options: CatalogOptions);
    /** Subscribe to completed catalog mutations; returns an unsubscribe function. */
    /** 中文：订阅目录变更完成事件，并返回取消订阅函数。 */
    subscribe(listener: () => void): () => void;
    /** Install the download-region source (the host settings namespace scope). */
    /** 中文：接入宿主设置命名空间中的下载区域读取器。 */
    setDownloadRegionProvider(provider: () => Promise<DownloadRegionSetting>): void;
    /** Configuration writes may acquire one source; runtime mount reads never do. */
    private resolveRuntimeSuite;
    /** Load persisted user state once at plugin activation. */
    /** 中文：插件激活时读取一次用户持久化状态，并清空旧扫描/快照缓存。 */
    load(): Promise<void>;
    /** 返回当前内存中的已登记源列表。 */
    get sources(): SourceRef[];
    /** The user-dimension suite root this catalog operates. */
    /** 中文：返回用户维度目录扫描所使用的根路径。 */
    get userRoot(): string;
    /** Read one coherent user-dimension snapshot, reusing in-flight discovery. */
    /** 中文：读取用户维度一致性快照，并复用有效缓存或正在进行的扫描。 */
    readUserCatalog(): Promise<CatalogSnapshot>;
    /** Read installed suites from one captured install state without market checkout probes. */
    readInstalledSuites(sourceId?: string): Promise<Suite[]>;
    /** Read one coherent project-dimension snapshot for a workspace cwd. */
    /** 中文：根据工作区 cwd 定位项目根，并读取项目维度一致性快照。 */
    readProjectCatalog(cwd: string): Promise<CatalogSnapshot>;
    /** 从项目根加载状态文件并构建项目快照，必要时跳过扫描缓存。 */
    private buildProjectSnapshot;
    /** One suite's full detail for the market detail modal. */
    /** 中文：读取指定套件的完整详情，包含安装状态、诊断和脱敏后的 MCP 覆盖。 */
    suiteDetail(sourceId: string, suiteId: string): Promise<SuiteDetail>;
    /** One skill's full SKILL.md text for the market detail modal. */
    /** 中文：读取指定套件技能的完整 SKILL.md 正文。 */
    skillContent(sourceId: string, suiteId: string, skillName: string): Promise<SkillContent>;
    /** The full market overview from one user snapshot. */
    /** 中文：把用户快照、源检出状态和安装记录组装成市场总览响应。 */
    overview(): Promise<OverviewPayload>;
    /** Runtime discovery scans only sources containing an enabled install. No acquisition or network access. */
    /** 中文：运行时只扫描存在启用安装项的源，不执行获取或网络操作。 */
    enabledUserSuites(): Promise<Suite[]>;
    /** Enabled user- and project-dimension suites for a workspace cwd. */
    /** 中文：返回指定工作区下用户维度和项目维度的启用套件。 */
    enabledSuitesForCwd(cwd: string): Promise<{
        user: Suite[];
        project: Suite[];
    }>;
    /** All suites of one dimension. */
    /** 中文：读取一个目录维度的全部套件，不限于已启用项。 */
    suitesForDimension(dimension: SuiteDimension, dimensionRoot: string): Promise<Suite[]>;
    /**
     * Add a source and acquire it immediately (clone, download, or in-place).
     *
     * Git sources with an already-present checkout whose `origin` matches the
     * input URL are adopted in place — the manual-clone repair path — so no
     * second clone is made and no `-2` suffixed id is invented. Adopted
     * checkouts are preserved on URL changes; explicit source removal may
     * delete their managed `.sources/<id>` storage.
     * 中文：登记源并立即获取内容；已有匹配远程地址的检出会原地收编，避免重复克隆。
     */
    addSource(input: {
        url: string;
        branch?: string;
        local?: boolean;
        kind?: SourceKind;
        sha256?: string;
    }): Promise<SourceRef>;
    /**
     * First candidate id whose `.sources/` checkout already exists and whose
     * `origin` remote matches the input URL (canonical-form equality) — the
     * signature of a manual clone of the very same repository. Registered ids
     * and checkouts of differently-origined directories never adopt.
     * 中文：只收编远程地址规范化后完全相同、且尚未登记的既有 Git 检出。
     */
    private findAdoptableCheckout;
    /** Register one unmanaged `.sources/` checkout as a source without touching its files. */
    /** 中文：将磁盘上未登记的 `.sources/` 检出登记为源，不复制或修改其文件。 */
    adoptSource(id: string): Promise<SourceRef>;
    /** Unmanaged `.sources/` checkouts: present on disk, absent from state. */
    /** 中文：列出磁盘存在但状态文件未登记的 `.sources/` 检出。 */
    unmanagedSources(): Promise<Array<{
        id: string;
        url?: string;
    }>>;
    /** Progress snapshot of the source mutation currently in flight. */
    /** 中文：记录当前正在执行的源变更及其步骤，供进度接口读取。 */
    private currentSourceState;
    /** Progress snapshot for the progress route. */
    /** 中文：返回进度路由所需的当前步骤快照。 */
    sourceProgress(): {
        active: boolean;
        sourceId: string;
        step: string;
    };
    /**
     * First candidate id not claimed by a registered source; for git candidates
     * the checkout directory must also be free, so a stale or foreign directory
     * under `.sources/` is never cloned over (it would fail `git clone` with a
     * confusing "destination exists" error). `ownedCheckout` marks the directory
     * the in-flight mutation already controls, keeping a rename onto it legal.
     * Local sources skip the disk check: they read their own path in place and
     * never occupy `.sources/`.
     * 中文：选择第一个未被状态或磁盘占用的源 ID；本地源不占用托管检出目录。
     */
    private pickSourceId;
    /** Update one source's URL, branch, kind, or archive digest. */
    /** 中文：更新一个源的地址、分支、类型或压缩包摘要，并处理旧检出失效。 */
    updateSource(sourceId: string, patch: {
        url?: string;
        branch?: string;
        local?: boolean;
        kind?: SourceKind;
        sha256?: string;
    }): Promise<void>;
    /**
     * Remove a source and its install entries. `deleteCheckout` (the UI's
     * "also delete the managed market directory" option) physically removes the
     * `.sources/<id>` checkout — including an adopted one, since a directory
     * under `.sources` is manager-owned storage. A `local` source whose URL
     * points outside `.sources` is registration-only: its directory is never
     * touched. Deleting the checkout is what keeps a removed source from
     * reappearing as an unmanaged entry.
     * 中文：移除源及其安装记录；仅在明确要求且目录属于管理器存储时删除托管检出。
     */
    removeSource(sourceId: string, deleteCheckout?: boolean): Promise<void>;
    /** Refresh one source checkout, or every source when sourceId is omitted. */
    /** 中文：刷新指定源或全部源，区分本地目录、压缩包、收编 Git 和托管 Git 的安全策略。 */
    refreshSource(sourceId?: string): Promise<void>;
    /** Install a suite from a source and enable it. The client confirms the
     * injected surfaces (skills / MCP / hooks / commands) in a pre-install
     * dialog before this runs; disabling afterwards is always available.
     * 中文：确认源和套件后获取缺失检出、记录锁定值并启用安装项；后续仍可关闭。
     */
    install(sourceId: string, suiteId: string, options?: {
        surfaces?: SurfaceOverrides;
        configurationOnly?: true;
    }): Promise<void>;
    /** Uninstall a suite while retaining the source checkout. */
    /** 中文：移除套件安装记录但保留源检出目录。 */
    uninstall(sourceId: string, suiteId: string): Promise<void>;
    /** Enable or disable an installed suite. */
    /** 中文：切换已安装套件整体启用状态。 */
    setEnabled(sourceId: string, suiteId: string, enabled: boolean): Promise<void>;
    /** Enable or disable one runtime surface of an installed suite. */
    /** 中文：切换已安装套件的单个运行时能力面。 */
    setSurface(sourceId: string, suiteId: string, surface: SuiteSurfaceKey, enabled: boolean): Promise<void>;
    /** Append config-seeded sources missing from user state and persist them. */
    /** 中文：将配置预置但状态中缺失的源追加保存，并使扫描/快照失效。 */
    mergeSources(sources: SourceRef[]): Promise<void>;
    /** Serialize a resource write with catalog changes and publish only successful writes. */
    changePanelResources<T>(change: () => Promise<T>): Promise<T>;
    /** 更新一个套件的持久化安装记录，不负责触发变更通知。 */
    private setInstalled;
    /**
     * Acquire one source's content by kind: clone (git), download+extract
     * (archive), or an in-place existence check (local). Returns a lock value
     * when the acquisition yields one (archive SHA-256, tarball fallback
     * digest); git HEAD is read separately by the callers.
     * 中文：按源类型获取内容；本地只检查存在，压缩包返回摘要，Git 由调用方另读 HEAD。
     */
    private acquire;
    /** The filesystem location of one source. */
    /** 中文：解析一个源实际使用的文件系统路径，本地源读取自身目录。 */
    private sourceCheckoutPath;
    /** 按维度、源状态和缓存策略构建一致性套件快照。 */
    private buildSnapshot;
    /** 清空用户/项目快照缓存，并按需递增目录修订号。 */
    private invalidateSnapshot;
    /** 清空扫描结果与进行中的扫描承诺，并推进扫描代数。 */
    private invalidateScans;
    /**
     * Invalidate snapshots and run the change pipeline. `keepScanCache` marks
     * state-only mutations (install, enable, surface toggles, MCP overrides)
     * whose inputs leave every checkout untouched, so the next snapshot
     * re-derives from cached discovery instead of rescanning the filesystem.
     * 中文：失效快照并执行宿主变更回调；纯状态变更可保留发现缓存。
     */
    private notifyChanged;
    /** 串行排队所有目录变更，保证前一个失败后队列仍能继续处理。 */
    private enqueue;
}
/**
 * The codeload tarball URL of a GitHub repository, or undefined for any
 * other host. `https://github.com/<owner>/<repo>` maps to
 * `https://codeload.github.com/<owner>/<repo>/tar.gz/refs/heads/<branch>`
 * (or `/tar.gz/HEAD` for the default branch) — the git-protocol fallback
 * when a clone cannot get through but plain HTTPS file download can.
 * 中文：仅把标准 GitHub 仓库地址转换成对应 codeload tarball，其他主机返回 undefined。
 */
export declare function codeloadTarballUrl(url: string, branch: string | undefined): string | undefined;
