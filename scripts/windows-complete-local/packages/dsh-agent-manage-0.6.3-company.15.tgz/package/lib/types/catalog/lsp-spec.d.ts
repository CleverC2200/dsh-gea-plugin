/** 文件作用：解析并失败关闭处理套件内 lspServers 声明，输出规范化配置和诊断。 */
/**
 * Normalization and validation for inline `lspServers` declarations (Claude
 * Code marketplace entries and plugin manifests).
 *
 * A declaration is a named table of server specs: `command` (required),
 * `args`, and an `extensionToLanguage` map (required, non-empty). Unknown
 * keys are tolerated and listed in the returned diagnostics; known Claude
 * Code-only extensions (`startupTimeout`) are ignored silently. Parsing is
 * fail-closed per suite: a broken server spec degrades to a diagnostic, never
 * a thrown discovery.
 */
import type { LspServerSpec } from '../model/types.js';
/** Parse one inline `lspServers` table into normalized specs plus diagnostics. */
/** 解析命名 LSP 表；单个服务失败关闭并将原因追加到 errors。 */
export declare function parseLspServers(raw: unknown, errors: string[]): Record<string, LspServerSpec>;
