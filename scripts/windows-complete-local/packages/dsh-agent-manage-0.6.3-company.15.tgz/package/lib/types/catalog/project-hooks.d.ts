/** 文件作用：读取并归一化项目原生 Claude hooks，合并事件层并去重。 */
/** Normalize native Claude-shaped command hooks for the existing host execution bridge. */
import type { ProjectHooks } from '../model/types.js';
import type { ProjectHookFormat } from '../model/layouts.js';
/** Merge settings layers additively, deduplicating identical event/matcher/command triples. */
/** 读取项目 hooks 配置层并合并为宿主桥接格式，单层失败进入 errors。 */
export declare function discoverProjectHooks(projectRoot: string, files: readonly string[], errors: string[], format?: ProjectHookFormat): Promise<ProjectHooks | undefined>;
/** Pure validation shared by native settings and plugin file/inline declarations. */
/** 将多个文档的事件组归一化，去重相同事件/匹配器/命令三元组。 */
export declare function normalizeHookDocuments(projectRoot: string, documents: Array<{
    file: string;
    settings: Record<string, unknown>;
}>, errors: string[], format?: ProjectHookFormat): ProjectHooks | undefined;
