import type { SourceRef, Suite, SuiteDimension } from '../model/types.js';
/** Discover suites from the selected configured or project checkouts. */
/** 扫描指定维度的来源 checkout，并返回不带 notes 的兼容套件列表。 */
export declare function discoverSourceList(sources: SourceRef[], dimension: SuiteDimension, dimensionRoot: string): Promise<Suite[]>;
/** Discover suites plus per-source scan diagnostics for one dimension. */
/** 扫描来源并保留 checkout 级 notes，供 SourceOverview 和状态面展示。 */
export declare function discoverSourceListWithNotes(sources: SourceRef[], dimension: SuiteDimension, dimensionRoot: string, scanProjectLayouts?: boolean): Promise<{
    suites: Suite[];
    scanNotes: Record<string, string[]>;
}>;
