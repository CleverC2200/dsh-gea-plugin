import type { Suite, SuiteComponents, SuiteDimension } from '../model/types.js';
import { type MarketplaceEntry } from './manifests.js';
import type { ScanChain, ScanContext, ScanFilter, ScanResolution, ScanResult } from './scan-pipeline.js';
export { repoName } from './manifests.js';
export { listMdFiles, discoverLspEntries, type LspEntry } from './surfaces.js';
export type { MarketplaceEntry } from './manifests.js';
export interface SuiteHint extends SuiteComponents {
    layout?: import('../model/layouts.js').ManifestKind;
    name?: string;
    version?: string;
    description?: string;
    /** Inline `lspServers` declared on the marketplace entry itself (Claude Code). */
    lspServers?: unknown;
}
/** Normalized resolution of one marketplace entry inside its checkout. */
export type EntryResolution = {
    kind: 'local';
    dir: string;
} | {
    kind: 'remote';
    url: string;
} | {
    kind: 'unclaimed';
    reason: string;
} | {
    kind: 'rejected';
    reason: string;
};
interface EntryContext {
    checkout: string;
    entry: MarketplaceEntry;
}
interface EntryChain {
    /** 中文：把当前 marketplace 条目交给链上的下一个解析器继续处理。 */
    next(context: EntryContext): EntryResolution | Promise<EntryResolution>;
}
/** One handler in the marketplace-entry chain. */
export interface EntryHandler {
    name: string;
    /** 中文：尝试解析一个条目；无法处理时通过 chain 继续委托。 */
    handle(context: EntryContext, chain: EntryChain): EntryResolution | Promise<EntryResolution>;
}
/**
 * Canonical `https://host/owner/repo` form of a git URL, for equality
 * comparisons between a source's configured URL and an entry's remote.
 */
/** 归一化 Git URL 的协议、尾部斜杠和 .git 后缀，便于 self-reference 比较。 */
export declare function canonicalGitUrl(url: string): string;
/** The remote URL an entry points at, across every dialect's shape. */
/** 提取 entry 的远程 URL 或 GitHub repo shorthand。 */
export declare function entryRemoteUrl(entry: MarketplaceEntry): string | undefined;
/**
 * Resolve one marketplace entry's source against its checkout. Self-
 * references (an entry pointing back at this very source, as Claude Code
 * ships for single-repo marketplaces) resolve to the local checkout so the
 * repo's own manifest and surfaces are scanned directly.
 */
/** 按本地、自引用、远程顺序解析单个 marketplace entry，并保留失败诊断。 */
export declare function resolveMarketplaceEntry(checkout: string, entry: MarketplaceEntry, sourceUrl: string | undefined): Promise<EntryResolution>;
/** Read one checkout through marketplace manifests, dialect by dialect. */
export declare class MarketplaceStrategy implements ScanFilter {
    readonly name = "marketplace";
    /** 读取 marketplace 方言并逐条解析；有产出才终止策略链。 */
    doScan(context: ScanContext, chain: ScanChain): Promise<ScanResolution>;
    /** 将已解析 marketplace entries 转换为可读 suite roots，并聚合条目诊断。 */
    private marketplaceRoots;
}
/** Read nested plugin roots up to four levels deep. */
export declare class RootedStrategy implements ScanFilter {
    readonly name = "rooted";
    /** 深度受限发现嵌套 plugin 根；至少有套件产出才视为命中。 */
    doScan(context: ScanContext, chain: ScanChain): Promise<ScanResolution>;
}
/** Terminal fallback: manifest-less flat `<child>/SKILL.md` collections. */
export declare class FlatCollectionsStrategy implements ScanFilter {
    readonly name = "flat-collections";
    /** 终端策略：把扁平技能集合转换为合成套件，永远返回结果。 */
    doScan(context: ScanContext): Promise<ScanResolution>;
}
/** The default chain, most specific first with a terminal fallback. */
/** 返回按 marketplace、rooted、flat 顺序排列的默认扫描策略。 */
export declare function defaultScanFilters(): readonly ScanFilter[];
/** Discover every suite under one source checkout. */
/** 扫描来源 checkout 并返回规范化套件列表，诊断随结果保留。 */
export declare function discoverSuitesInSource(checkoutDir: string, sourceId: string, dimension: SuiteDimension, sourceUrl?: string): Promise<Suite[]>;
/** Scan one checkout through the filter chain with full diagnostics. */
/** 运行默认扫描链并输出 roots、suites、notes，作为来源级发现入口。 */
export declare function scanSource(checkoutDir: string, sourceId: string, dimension: SuiteDimension, sourceUrl?: string): Promise<ScanResult>;
/** Whether a directory carries any known suite manifest. */
/** 判断目录是否带可识别 manifest。 */
export declare function hasSuiteManifest(dir: string): Promise<boolean>;
/** Whether a directory carries skill files in the flat or bundled shape. */
/** 判断目录是否存在可作为技能表面的 Markdown 文件。 */
export declare function hasSkillFiles(dir: string): Promise<boolean>;
/** Read one suite root into the normalized shape, or undefined when no manifest parses. */
/** 读取单个 suite root 的 manifest 和各 surface，单项错误写入 notes 后继续。 */
export declare function readSuite(root: string, sourceId: string, dimension: SuiteDimension, hint: SuiteHint | undefined, notes?: string[]): Promise<Suite | undefined>;
