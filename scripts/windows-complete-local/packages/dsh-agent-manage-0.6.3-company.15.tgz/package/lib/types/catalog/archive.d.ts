/** Hard cap on archive download size (mirrors Claude Code's archive limit). */
export declare const ARCHIVE_MAX_BYTES: number;
/** Hard cap on the total decompressed bytes one archive may write. */
export declare const ARCHIVE_MAX_EXTRACTED_BYTES: number;
/** Hard cap on the number of files one archive may write. */
export declare const ARCHIVE_MAX_ENTRIES = 20000;
/** Hard cap on the decompressed size of a single archive entry. */
export declare const ARCHIVE_MAX_ENTRY_BYTES: number;
export declare const DEFAULT_ARCHIVE_TIMEOUT_MS = 180000;
/** Options for one archive acquisition. */
export interface ArchiveOptions {
    /** Caller-owned GitHub API credential; never persisted or sent to redirects. */
    githubToken?: string;
    /** Required SHA-256 hex digest of the payload; mismatch rejects the install. */
    sha256?: string;
    /** Download timeout; defaults to 180s. */
    timeoutMs?: number;
    /** Allow plain `http://` (intranet mirrors); defaults to HTTPS-only. */
    allowHttp?: boolean;
    /**
     * Explicit format for URLs whose extension does not reveal the payload
     * (e.g. a codeload tarball ending in a branch path). Overrides
     * {@link archiveFormatOf}; the caller owns the correctness of the hint.
     */
    format?: ArchiveFormat;
}
/** Result of one successful archive install. */
export interface ArchiveInstallResult {
    /** SHA-256 hex digest of the downloaded payload (usable as a lock value). */
    sha256: string;
}
/** Recognized archive payload kinds. */
export type ArchiveFormat = 'zip' | 'tar' | 'targz';
/** Classify an archive URL by extension; undefined when unsupported. */
/** 根据 URL 后缀识别支持的归档格式，未知格式返回 undefined 交给调用方诊断。 */
export declare function archiveFormatOf(url: string): ArchiveFormat | undefined;
/** Download the payload to a temp file, enforcing the size cap and digest. */
/** 下载归档并校验 HTTPS、大小和可选 SHA-256，返回实际临时文件路径。 */
export declare function downloadArchive(url: string, tempFile: string, options?: ArchiveOptions): Promise<string>;
/**
 * Acquire one archive source into `dest`: download, verify, extract into a
 * sibling temp directory, normalize a single top-level wrapper directory,
 * then swap into `dest`. Returns the payload digest.
 */
/** 下载、解包、检查符号链接并归一化单根目录，输出可作为 checkout 的目录。 */
export declare function archiveInstall(url: string, dest: string, options?: ArchiveOptions): Promise<ArchiveInstallResult>;
/** Walk the extracted tree and reject any symlink whose target resolves outside `root`. */
/** 检查解压树中的符号链接最终目标仍在根目录内。 */
declare function assertNoEscapingSymlinks(root: string): Promise<void>;
/** Test seam: run the symlink-containment walk against a prepared tree. */
export declare const assertNoEscapingSymlinksForTest: typeof assertNoEscapingSymlinks;
/** Probe whether a path exists and is a directory. */
/** 以 stat 判断路径是否为目录；不存在或不可读时返回 false。 */
export declare function isDirectory(path: string): Promise<boolean>;
export {};
