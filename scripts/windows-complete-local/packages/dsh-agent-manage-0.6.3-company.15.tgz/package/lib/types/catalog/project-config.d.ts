import type { McpSuiteConfig } from '../model/types.js';
import type { ProjectMcpFormat } from '../model/layouts.js';
/** Later files override earlier keys; a malformed layer invalidates the whole layout's table. */
/** 读取多层项目 MCP 配置，后层覆盖前层；任一层格式坏则整张表失败关闭。 */
export declare function discoverProjectMcp(projectRoot: string, files: readonly string[], errors: string[], format?: ProjectMcpFormat): Promise<McpSuiteConfig | undefined>;
/** Missing is undefined; malformed/unreadable is null and carries a diagnostic. */
/** 读取项目配置文件并解析为对象；缺失跳过，格式错误写入诊断。 */
export declare function readProjectDocument(projectRoot: string, file: string, errors: string[], format?: 'JSON' | 'TOML'): Promise<Record<string, unknown> | undefined | null>;
