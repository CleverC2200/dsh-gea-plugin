import type { Suite, SuiteDimension } from '../model/types.js';
import { type ProjectLayout } from '../model/layouts.js';
/**
 * Project-local directory conventions, in precedence order. Each entry maps
 * one agent convention onto the content subdirectories it owns.
 */
export declare const NATIVE_PROJECT_DIRS: readonly NativeProjectDir[];
export type NativeProjectDir = ProjectLayout;
/**
 * Discover native project-layout suites under a project root. Each
 * convention directory that carries content becomes one synthetic suite;
 * empty or absent directories contribute nothing.
 */
/** 只读发现项目布局中的技能/MCP/hooks/Agent 目录并生成合成套件。 */
export declare function discoverNativeProjectSuites(projectRoot: string, dimension: SuiteDimension): Promise<Suite[]>;
