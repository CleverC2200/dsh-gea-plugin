/** 文件作用：串联扫描策略链，保证识别、产出和终止策略可解释且不静默丢失。 */
/**
 * Source scan pipeline: a servlet-filter-style strategy chain with
 * classloader-delegation semantics.
 *
 * The chain owns one question — "which suite roots does this checkout
 * declare?" — that several discovery shapes can answer: a marketplace
 * manifest listing entries, nested plugin directories, or a flat collection
 * of skill directories. Each filter either resolves the checkout (short-
 * circuiting the chain) or abstains with a reason, forwarding to the next
 * filter. The last filter is terminal: it always answers, so a checkout
 * never falls off the end silently.
 *
 * Resolution requires *productive* output: a filter that recognizes the
 * layout but yields zero suites is an abstention, not a hit. That is the
 * bug class this pipeline exists to prevent — a parseable marketplace whose
 * entries all fail to resolve used to short-circuit the scan into an empty
 * result with no fallback and no diagnostic.
 *
 * Filter order is parent-first delegation, most specific shape first. Every
 * attempt is recorded on the result, so callers can surface why a source
 * resolved the way it did.
 */
import type { Suite } from '../model/types.js';
/** One filter's work context: the checkout and its identity. */
export interface ScanContext {
    marketplacePath?: string;
    /** Absolute path of the source checkout. */
    checkout: string;
    /** The configured source id suites will be attributed to. */
    sourceId: string;
    /** The dimension being scanned. */
    dimension: 'user' | 'project';
    /** The source's own URL, when known; used by self-reference handling. */
    sourceUrl?: string;
    /** Diagnostics accumulated across the chain (append-only). */
    notes: string[];
}
/** Why a filter did not resolve the checkout. */
export type ScanAbstentionReason = string;
/** The outcome of one filter (or the whole chain) for one checkout. */
export type ScanResolution = {
    kind: 'resolved';
    suites: Suite[];
} | {
    kind: 'abstain';
    reason: ScanAbstentionReason;
};
/** The rest of the chain beyond the filter that holds it. */
export interface ScanChain {
    /** Hand the checkout to the next filter; terminal when none remain. */
    /** 中文：把当前 checkout 交给下一个扫描策略，并返回解析或放弃结果。 */
    next(context: ScanContext): Promise<ScanResolution>;
}
/** One strategy in the source scan chain. */
export interface ScanFilter {
    /** Stable filter name, recorded on every attempt. */
    readonly name: string;
    /** Either resolve the checkout or forward to `chain.next`. */
    /** 中文：执行当前扫描策略；命中则产出套件，否则返回可解释的放弃原因。 */
    doScan(context: ScanContext, chain: ScanChain): Promise<ScanResolution>;
}
/** One recorded chain attempt. */
export interface ScanAttempt {
    filter: string;
    outcome: 'resolved' | 'abstain';
    /** Suites produced when resolved; the abstention reason otherwise. */
    detail: string;
    /** Suite ids produced, when resolved. */
    suiteIds: string[];
}
/** The full outcome of scanning one checkout. */
export interface ScanResult {
    marketplacePath?: string;
    suites: Suite[];
    attempts: ScanAttempt[];
    /** Human-readable diagnostics: dropped entries, broken manifests, fallbacks taken. */
    notes: string[];
}
/** Drive one checkout through the filter chain, recording every attempt. */
/** 按策略顺序运行扫描链；首个有产出的解析结果胜出，末端策略必须回答。 */
export declare function runScanChain(filters: readonly ScanFilter[], context: ScanContext): Promise<ScanResult>;
