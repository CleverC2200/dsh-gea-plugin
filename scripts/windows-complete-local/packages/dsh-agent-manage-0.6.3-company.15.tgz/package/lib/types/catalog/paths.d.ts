/** Source checkouts live under `<dimensionRoot>/.sources/<sourceId>/`. */
export declare const SOURCES_DIR_NAME = ".sources";
/** Per-suite mutable data directory (the `${PLUGIN_DATA}` placeholder). */
export declare const DATA_DIR_NAME = "data";
export declare const STATE_FILE_NAME = "state.json";
/** Expand a leading `~/` (or `~\` on Windows) to the home directory; other values pass through. */
/** 展开 `~` 和 `$DSH_HOME`，把用户输入转换为绝对路径候选。 */
export declare function expandHome(path: string): string;
/** Resolve the harness home (`$DSH_HOME` or `~/.dsh`). */
/** 解析宿主 DSH_HOME，缺省使用用户主目录下的 .dsh。 */
export declare function resolveDshHome(): string;
/** Resolve the canonical user-dimension root owned by the current DSH_HOME. */
/** 解析用户维度插件根目录，统一来源 checkout、状态和数据路径。 */
export declare function resolveUserRoot(): string;
/**
 * Resolve the suite data root hosting `${PLUGIN_DATA}` directories and the
 * MCP overrides. Defaults under the user root so the whole plugin persists
 * into one directory.
 */
/** 解析标准用户根目录内的插件数据根目录。 */
export declare function resolveDataRoot(): string;
/** Resolve a project root from a workspace cwd: nearest ancestor with `.git`. */
/** 向上查找最近包含 .git 的项目根；找不到时返回当前目录。 */
export declare function findProjectRoot(cwd: string): Promise<string>;
/** Resolve the project-dimension suite root for a workspace cwd. */
/** 规范化 cwd 后解析项目根，处理相对路径和不存在路径。 */
export declare function resolveProjectRoot(cwd: string): Promise<string>;
/** Source checkout directory for one source id. */
/** 返回来源 checkout 父目录。 */
export declare function sourcesDir(dimensionRoot: string): string;
/** Source checkout directory for one source id. */
/** 返回指定 sourceId 的 checkout 目录。 */
export declare function sourceCheckoutDir(dimensionRoot: string, sourceId: string): string;
/** Per-suite data directory for `${PLUGIN_DATA}`. */
/** 返回限定套件的数据目录，并保留 source/suite 命名边界。 */
export declare function suiteDataDir(dataRoot: string, suiteId: string): string;
/**
 * Suite-qualified key: `${sourceId}/${suiteId}`. Suite ids are unique within a
 * source only (two sources may both ship a suite named "utils"), so every
 * state, override, data-directory, and mount key must be source-scoped — a
 * bare suite id silently collides across sources.
 */
/** 组合来源 ID 与套件 ID，避免不同来源同名套件发生冲突。 */
export declare function qualifiedSuiteId(sourceId: string, suiteId: string): string;
/** Async existence probe that follows symlinks for a final component. */
/** 判断路径是否为目录，不存在或 stat 失败返回 false。 */
export declare function isDirectory(path: string): Promise<boolean>;
/** Async existence probe for any entry (file, directory, symlink). */
/** 判断任意文件系统路径是否存在。 */
export declare function pathExists(path: string): Promise<boolean>;
/** Sanitize a plugin or server id into `[a-z0-9-]` (lowercased). */
/** 将来源/套件标识清洗为安全稳定的目录片段。 */
export declare function sanitizeId(raw: string): string;
/** Derive a source id from a repository URL or local path: last path segment, `.git` stripped. */
/** 从 URL 推导人类可读 sourceId，并按规则清洗。 */
export declare function deriveSourceId(url: string): string;
/**
 * Derive candidate source ids from a git URL or local path, most preferred
 * first: the sanitized basename, then an owner-prefixed variant (`owner-repo`)
 * for remote URLs so same-named repositories from different owners
 * (`cloudflare/skills`, `mattpocock/skills`) degrade to readable ids instead
 * of numeric suffixes. Local paths yield the basename only.
 */
/** 生成 sourceId 候选序列，供冲突消解和历史兼容使用。 */
export declare function deriveSourceIdCandidates(url: string): string[];
