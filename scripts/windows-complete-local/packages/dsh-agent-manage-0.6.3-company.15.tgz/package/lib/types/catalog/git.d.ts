export declare const DEFAULT_GIT_TIMEOUT_MS = 120000;
/** Network tuning applied to every remote-touching git invocation. */
export interface GitOptions {
    /** Value for `http.proxy` / `https.proxy` (e.g. `http://127.0.0.1:7890`). */
    proxy?: string;
    /** URL-prefix rewrites, git `insteadOf` semantics: `{'https://github.com/': 'https://mirror/https://github.com/'}`. */
    insteadOf?: Record<string, string>;
    /** Timeout per git invocation; defaults to 120s. */
    timeoutMs?: number;
    /** Retry a failed clone once (network flake); default true. */
    cloneRetry?: boolean;
}
/** Clone a source (depth 1, optional branch) into a not-yet-existing directory. */
/** 克隆来源 checkout，可选分支并应用网络重试和代理配置。 */
export declare function gitClone(url: string, branch: string | undefined, dest: string, options?: GitOptions): Promise<void>;
/**
 * Shallow-friendly update: fetch depth 1 into FETCH_HEAD and hard-reset.
 * `git pull --ff-only` on shallow clones can refuse with history-divergence
 * errors; fetch+reset is idempotent and always lands on the remote tip. The
 * local checkout is plugin-managed, so discarding working-tree drift is the
 * intended semantics.
 */
/** 拉取并快进/重置来源 checkout，保持扫描目录与远端分支同步。 */
export declare function gitSync(dir: string, branch: string | undefined, options?: GitOptions): Promise<void>;
/** Read the checked-out HEAD commit. */
/** 读取 checkout 当前 commit，作为扫描和缓存证据。 */
export declare function gitHead(dir: string, timeoutMs?: number): Promise<string>;
/** Read the checked-out branch name (`HEAD` when detached). */
/** 读取 checkout 当前分支；detached HEAD 返回 Git 原值。 */
export declare function gitCurrentBranch(dir: string, timeoutMs?: number): Promise<string>;
/** Read the checkout's `origin` remote URL; throws when the directory is not a git repository. */
/** 读取 origin URL，供源身份和刷新路径判断使用。 */
export declare function gitRemoteUrl(dir: string, timeoutMs?: number): Promise<string>;
/** Point the checkout's `origin` at a new URL (download-region rerouting). */
/** 更新 checkout 的 origin URL，调用方负责授权和业务状态变更。 */
export declare function gitSetRemoteUrl(dir: string, url: string, timeoutMs?: number): Promise<void>;
/** Remove a source checkout tree entirely. */
/** 删除来源 checkout 目录，目标由调用方解析为受控路径。 */
export declare function gitRemove(dir: string): Promise<void>;
