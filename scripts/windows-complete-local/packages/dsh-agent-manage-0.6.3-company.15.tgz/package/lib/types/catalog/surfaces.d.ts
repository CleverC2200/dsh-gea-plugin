import type { LspSuiteConfig, McpSuiteConfig, SuiteManifest, SuiteSkill, SuiteSurfaceCounts } from '../model/types.js';
/** Discover SKILL.md files under the suite's skills directory, up to 3 levels deep. */
/** 扫描声明或默认技能目录，解析 frontmatter、去重并失败关闭单项。 */
export declare function discoverSkills(root: string, errors: string[], declared?: unknown): Promise<SuiteSkill[]>;
/** Read the suite's MCP config: `mcp.json` or `.mcp.json`, else the winning manifest's inline `mcpServers`. */
/** 读取 mcp.json/.mcp.json 并按服务失败关闭校验，保留可诊断 errors。 */
export declare function discoverMcp(root: string, errors: string[], manifest?: SuiteManifest): Promise<McpSuiteConfig | undefined>;
/** Count surfaces for a suite; mcp counts only validated servers, lsp counts inline servers plus directory entries. */
/** 统计各 surface 条目数量，供套件卡片和扫描结果展示。 */
export declare function countSurfaces(root: string, skills: SuiteSkill[], mcp: McpSuiteConfig | undefined, lsp?: LspSuiteConfig): Promise<SuiteSurfaceCounts>;
export interface LspEntry {
    name: string;
    path: string;
}
/** LSP definitions: `.claude-plugin/lsp/*.json` plus reverse-domain `lsp/` dirs. */
/** 兼容旧状态面：读取 LSP 声明并展开为可计数条目。 */
export declare function discoverLspEntries(root: string): Promise<LspEntry[]>;
/** File names under a suite's commands/ or agents/ directory. */
/** 递归列出受控深度内 Markdown 文件，跳过链接和隐藏控制目录。 */
export declare function listMdFiles(dir: string): Promise<string[]>;
