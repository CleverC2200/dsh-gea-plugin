import type { SkillInvocationPolicy } from '@deepseek-ai/dsh-skill';
export interface ParsedSkillFrontmatter {
    name: string;
    description: string;
    whenToUse?: string;
    invocation: SkillInvocationPolicy;
}
/** Kebab-case skill names only, matching the shipped provider's rule. */
/** 判断技能名是否满足宿主可寻址的基础命名约束。 */
export declare function isSkillName(name: string): boolean;
/**
 * Normalize a display-style skill name into kebab-case (e.g. "Presentations"
 * → "presentations"), or `undefined` when nothing usable remains.
 */
/** 清洗并校验技能名，非法或清洗为空时返回 undefined。 */
export declare function normalizeSkillName(name: string): string | undefined;
/**
 * Parse skill frontmatter with the shipped provider's fail-closed semantics.
 * @returns the parsed frontmatter, or a rejection string explaining why the
 *   skill must be dropped from discovery.
 */
/** 解析 SKILL.md frontmatter，校验必填字段和调用策略；错误返回诊断文本。 */
export declare function parseSkillFrontmatter(text: string, expectedName: string | undefined): ParsedSkillFrontmatter | string;
/** Strip the frontmatter block, returning the instruction body. */
/** 去除 frontmatter，返回技能正文供运行时执行和展示。 */
export declare function stripFrontmatter(text: string): string;
