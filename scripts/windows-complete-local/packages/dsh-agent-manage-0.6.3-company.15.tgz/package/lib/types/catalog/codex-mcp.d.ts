/** 文件作用：把 Codex TOML MCP 表转换为统一传输、凭据和启停策略。 */
/** Codex TOML MCP tables normalize into the existing transport and credential contracts. */
import type { McpServer } from '../model/types.js';
/** Unknown or malformed server options reject that server; other servers stay independently usable. */
/** 将 Codex MCP 表映射为统一 McpServer；单项异常写入诊断并跳过。 */
export declare function normalizeCodexMcp(raw: Record<string, unknown>, errors: string[]): Record<string, McpServer>;
