/** Read only the frontmatter bytes; discovery never expands instruction bodies. */
export declare function readSkillHeader(file: string, signal?: AbortSignal): Promise<string>;
