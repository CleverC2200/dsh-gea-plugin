import type { SuiteMarkdownResource } from '../model/types.js';
/** 判断组件声明是否为普通对象，排除数组和 null。 */
export declare function isRecord(value: unknown): value is Record<string, unknown>;
/** Reject both lexical and symlink escapes. Optional defaults may be absent without a diagnostic. */
/** 解析组件路径并校验词法路径和真实路径都未离开套件根。 */
export declare function componentPath(root: string, value: string, errors: string[], required?: boolean): Promise<string | undefined>;
/** Commands and agents may declare one file, several files, or recursive directories. */
/** 发现组件声明指向的 Markdown 资源，返回文件路径、正文和规范化名称。 */
export declare function discoverMarkdownResources(root: string, component: 'commands' | 'agents', declaration: unknown, manifestPath: string, errors: string[], extensions?: readonly string[]): Promise<SuiteMarkdownResource[]>;
export interface ComponentDocument {
    path?: string;
    value: Record<string, unknown>;
}
/** A malformed declared file invalidates that configuration surface instead of falling back. */
/** 将文件/目录组件声明展开为受控文档列表，非法或越界项进入 errors。 */
export declare function componentDocuments(root: string, declaration: unknown, errors: string[], allowDirectory?: boolean): Promise<ComponentDocument[] | undefined>;
/** 按候选顺序返回第一个存在的组件文件，缺失不视为错误。 */
export declare function firstComponentFile(root: string, candidates: readonly string[]): Promise<string | undefined>;
/** Legacy/native suites without catalog resource lists keep their conventional directory behavior. */
/** 读取默认 agents/commands 目录资源，作为未显式声明时的兼容发现。 */
export declare function defaultMarkdownResources(root: string, component: 'agents' | 'commands'): Promise<SuiteMarkdownResource[]>;
/** 读取 Markdown 资源正文，供命令和 Agent 解析器消费。 */
export declare function resourceText(resource: SuiteMarkdownResource): Promise<string>;
/** 从资源文件名生成合法命令名，去除扩展名和路径分隔。 */
export declare function resourceCommandName(name: string): string;
