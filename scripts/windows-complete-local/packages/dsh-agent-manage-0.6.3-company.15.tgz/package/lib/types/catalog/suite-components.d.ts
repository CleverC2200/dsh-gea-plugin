import type { ProjectHooks, SuiteManifest, LspSuiteConfig } from '../model/types.js';
/** 读取套件 LSP 声明或兼容文件，解析失败写入 errors 并返回 undefined。 */
export declare function discoverSuiteLsp(root: string, manifest: SuiteManifest, errors: string[]): Promise<LspSuiteConfig | undefined>;
/** File configs and Kimi's inline array converge on the established command-hook bridge shape. */
/** 读取 hooks 组件、展开根变量并转换为宿主 ProjectHooks。 */
export declare function discoverSuiteHooks(root: string, manifest: SuiteManifest, errors: string[]): Promise<ProjectHooks | undefined>;
/** 读取套件系统提示组件，文件缺失返回 undefined，坏文件进入 errors。 */
export declare function discoverSystemPrompt(root: string, manifest: SuiteManifest, errors: string[]): Promise<string | undefined>;
