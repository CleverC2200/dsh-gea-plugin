import type { McpSuiteConfig } from '../model/types.js';
export declare const PLUGIN_SCHEMA_ID = "https://agent-plugins.org/schemas/1.0.0/plugin.schema.json";
export declare const USER_MCP_SCHEMA_ID = "urn:dsh-agent-manage:user-mcp";
export declare const MCP_SCHEMA_ID = "https://agent-plugins.org/schemas/1.0.0/mcp.schema.json";
/** Validate one JSON document against a vendored schema; errors joined for surfacing. */
/** 使用内置 Schema 校验文档，返回稳定可展示的路径/消息列表。 */
export declare function validateAgainstSchema(schemaId: string, document: unknown): Promise<string[]>;
/** Whether a `$schema` value selects the local v1.0.0 ruleset. */
/** 判断 $schema 是否为本插件支持的正式 Schema 标识。 */
export declare function isRecognizedSchema(value: unknown): boolean;
/**
 * Spec §4 containment: a plugin-relative path must begin with `./` and, after
 * resolution against the plugin root, stay inside the filesystem-resolved
 * plugin root. Symlinks resolving outside the root are rejected.
 * @returns `undefined` when contained, or the rejection reason.
 */
/** 校验路径变量展开后仍位于插件根，阻断绝对路径和符号链接逃逸。 */
export declare function pathContainmentError(pluginRoot: string, value: string): Promise<string | undefined>;
/** Validate a plugin manifest per the vendored schema plus `$schema` recognition. */
/** 校验插件 manifest Schema 并执行 $schema/组件声明语义检查。 */
export declare function validatePluginManifest(raw: unknown): Promise<string[]>;
export interface McpValidateOptions {
    /** Project-owned config may name external executables and working directories. */
    pathMode?: 'plugin' | 'project';
    /** Strict portable mode (`mcp.json`): `$schema` required and schema-validated.
     *  Lenient mode (`.mcp.json`, native client file): no `$schema` requirement,
     *  unknown transports skipped per server, known transports still validated. */
    strict?: boolean;
}
/** 校验 MCP 文档和每个 server 的路径/传输契约，坏服务单独失败关闭。 */
export declare function validateMcpJson(pluginRoot: string, raw: unknown, options?: McpValidateOptions): Promise<{
    config?: McpSuiteConfig;
    errors: string[];
}>;
/** Expand `${PLUGIN_ROOT}`, `${PLUGIN_DATA}`, and `${NAME}` (process env) in one string.
 *  Claude Code aliases `${CLAUDE_PLUGIN_ROOT}` / `${CLAUDE_PLUGIN_DATA}` and
 *  `${NAME:-default}` fallbacks are honored for unset/empty env vars. */
/** 展开插件根、数据根和环境变量占位符，未知占位符保持原样。 */
export declare function expandPlaceholders(value: string, pluginRoot: string, pluginData: string, env?: NodeJS.ProcessEnv): string;
/** Resolve an expanded plugin-relative cwd to an absolute path. */
/** 将 MCP cwd 占位符解析为实际目录，供运行时子进程使用。 */
export declare function resolveCwd(value: string, pluginRoot: string, pluginData: string): string;
/** Whether one absolute path equals or lies under another absolute path. */
/** 判断 candidate 是否位于 root 内，统一处理根目录自身和路径分隔符。 */
export declare function isWithin(root: string, candidate: string): boolean;
