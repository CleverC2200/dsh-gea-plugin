import type { SuiteManifest, SuiteComponents } from '../model/types.js';
import { type ManifestKind } from '../model/layouts.js';
export type { ManifestKind } from '../model/layouts.js';
/** One manifest candidate: its file path and the dialect it selects. */
export interface ManifestCandidate {
    kind: ManifestKind;
    path: string;
}
/** The highest-precedence manifest file a directory carries, if any. */
/** 按方言优先级检测目录 manifest，返回实际布局、路径和原始记录。 */
export declare function detectManifest(dir: string): Promise<ManifestCandidate | undefined>;
/** Whether a directory carries any known suite manifest. */
/** 判断目录是否包含可识别 suite manifest，用于扫描策略快速筛选。 */
export declare function hasSuiteManifest(dir: string): Promise<boolean>;
/** Fallback suite identity for manifest-less skill collections. */
/** 为无 manifest 的原生/扁平目录生成稳定可展示名称。 */
export declare function syntheticManifestName(root: string): string;
/** 从 manifest 记录抽取组件声明，保持方言差异在目录层消化。 */
export declare function componentDeclarations(record: object): SuiteComponents;
/**
 * Parse one manifest document into a normalized SuiteManifest. The v1 dialect
 * is schema-validated (fail-closed); the others are structurally read with
 * light tolerance, and `hint` (a marketplace plugin entry) fills in gaps.
 */
/** 读取并校验 manifest，返回规范套件身份和组件声明；坏文件失败关闭。 */
export declare function readManifest(root: string, errors: string[], hint: ({
    name?: string;
    version?: string;
    description?: string;
} & SuiteComponents) | undefined): Promise<SuiteManifest | undefined>;
export interface MarketplaceEntry extends SuiteComponents {
    layout?: ManifestKind;
    strict?: boolean;
    name?: string;
    version?: string;
    description?: string;
    /** Claude Code: inline `lspServers` table declared on the entry itself. */
    lspServers?: unknown;
    /** Claude Code: a relative path string or `{ source: 'url', url }`.
     *  Codex: `{ source: 'local', path }` or `{ source: 'remote', url }`. */
    source: string | {
        source?: string;
        url?: string;
        path?: string;
    };
}
export interface Marketplace {
    pluginRoot?: string;
    name?: string;
    entries: MarketplaceEntry[];
}
export interface ReadMarketplaceResult extends Marketplace {
    /** The manifest file the entries were read from. */
    path: string;
}
/**
 * Read every marketplace manifest the checkout carries, in dialect
 * precedence order shared with suite manifests, then the shared root catalog.
 * The scan strategy selects the first catalog that produces suites; an empty
 * or invalid catalog allows the next candidate to be tried.
 */
/** 按支持方言顺序读取 checkout 内全部 marketplace 文件。 */
export declare function readMarketplaces(checkoutDir: string, errors?: string[]): Promise<ReadMarketplaceResult[]>;
/** Read the highest-precedence marketplace manifest, or undefined when absent. */
/** 返回优先级最高的 marketplace，兼容旧调用方只需要单值的场景。 */
export declare function readMarketplace(checkoutDir: string): Promise<Marketplace | undefined>;
/** Resolve one marketplace entry to a local checkout-relative directory, or
 *  `undefined` for remote-URL entries that are not present in the clone. */
/** 将 marketplace 本地 entry 解析为 checkout 内路径，拒绝越界路径。 */
export declare function marketplaceEntryDir(checkoutDir: string, entry: MarketplaceEntry): string | undefined;
/**
 * Resolve a repo-level name for source-id derivation, in precedence order:
 * marketplace plugin entry name > marketplace name > root manifest name >
 * the checkout basename. The suite repo's own JSON is authoritative; the
 * basename is only the fallback.
 */
/** 从 manifest、目录名或 Git 远端推导仓库展示名，供 sourceId 回退。 */
export declare function repoName(checkoutDir: string): Promise<string>;
/** The winning manifest's declared `skills` path (string or array), or undefined. */
/** 读取 manifest 声明的 skills 字段，供技能表面按声明扫描。 */
export declare function declaredSkillsPath(root: string): Promise<unknown>;
/** The winning manifest's inline `mcpServers`, or undefined. */
/** 读取并抽取 manifest 的 MCP 声明，未声明时返回 undefined。 */
export declare function declaredMcpServers(root: string): Promise<Record<string, unknown> | undefined>;
/** The winning manifest's inline `lspServers`, or undefined. */
/** 读取并抽取 manifest 的 LSP 声明，未声明时返回 undefined。 */
export declare function declaredLspServers(root: string): Promise<Record<string, unknown> | undefined>;
