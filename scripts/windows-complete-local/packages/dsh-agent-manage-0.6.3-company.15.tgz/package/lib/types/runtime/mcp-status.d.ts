/** 文件作用：把 MCP 声明、诊断、工具观察和覆盖配置汇总为状态行。 */
import { type McpSuiteOverrides } from './mcp-overrides.js';
import type { McpStatusPayload } from '../contracts/mcp-status.js';
import { inspectToolRegistry, type McpToolSnapshot } from './tool-registry-observer.js';
import type { Suite } from '../model/types.js';
export type { McpStatusEntry, McpStatusPayload, McpStatusKind, McpStatusState } from '../contracts/mcp-status.js';
export { inspectToolRegistry };
export type { McpToolSnapshot } from './tool-registry-observer.js';
export interface McpDiagnostic {
    suiteId: string;
    serverKey: string;
    reason: string;
    code?: 'unsupported-transport' | 'missing-credential' | 'credential-error' | 'unmount-failed' | 'mount-failed' | 'foreign-mount' | 'duplicate-mount';
    credentialRefs?: string[];
}
/** Build status rows from discovered plugin MCP definitions and observed tool names. */
/** 合并套件声明、诊断、工具观察和覆盖配置，输出可解释的 MCP 状态与统计。 */
export declare function buildMcpStatus(suites: Suite[], diagnostics: McpDiagnostic[], observed: readonly McpToolSnapshot[], overrides?: Map<string, McpSuiteOverrides>): McpStatusPayload;
