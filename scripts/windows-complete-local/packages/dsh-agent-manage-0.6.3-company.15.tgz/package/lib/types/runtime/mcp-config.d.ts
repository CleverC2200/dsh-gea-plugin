import type { Config } from './mcp-client/config.js';
import { type McpSuiteOverrides } from './mcp-overrides.js';
import type { McpServer, Suite } from '../model/types.js';
export interface McpMountRequest {
    suiteId: string;
    serverKey: string;
    config: Config;
}
export type McpMountFailureCode = 'unsupported-transport' | 'missing-credential' | 'credential-error' | 'unmount-failed' | 'mount-failed'
/** The derived serverName's namespace is already mounted by another MCP client — informational, not a failure. */
 | 'foreign-mount'
/** Another source's identical suite/server pair mounted first — this copy is redundant, informational. */
 | 'duplicate-mount';
export interface McpMountFailure {
    serverKey: string;
    reason: string;
    code?: McpMountFailureCode;
    credentialRefs?: string[];
}
/** Optional DSH credential resolver used while building an in-memory mount. */
export interface McpCredentialResolver {
    resolve(ref: string): Promise<{
        value: string;
        source?: string;
    } | undefined>;
}
/**
 * Build one mount request per supported mcp.json server, resolving every
 * `${NAME}` through the credential resolver before a child process or HTTP
 * request is created. Missing references fail closed per server instead of
 * becoming empty strings.
 *
 * @param overrides user-owned per-server overrides (url/headers/env/args
 *   replacement plus enable/disable); applied before mount. Disabled servers
 *   are omitted entirely.
 * @returns mount requests plus per-server failures. serverName collisions are
 *   reported by the mount registry, not here.
 */
/** 将套件 MCP 服务展开凭据并转换为挂载请求；失败项保留结构化诊断而非半挂载。 */
export declare function toMcpMounts(suite: Suite, pluginDataRoot: string, overrides?: McpSuiteOverrides, resolver?: McpCredentialResolver): Promise<{
    mounts: McpMountRequest[];
    failures: McpMountFailure[];
}>;
/** Find external credential references used by one MCP server definition. */
/** 收集单个 MCP 服务中所有凭据引用，用于变更影响判断。 */
export declare function credentialRefsInServer(server: McpServer): string[];
/**
 * Derive a bridge serverName from the suite and server ids:
 * `${suiteId}__${serverKey}` sanitized, clamped to 32 chars with a
 * deterministic 12-hex suffix when the join exceeds the budget.
 *
 * Deliberately NOT source-qualified: two sources shipping the same
 * suite/server pair are the same server for the model, so the second mount
 * is skipped with a `duplicate-mount` diagnostic instead of registering a
 * shadow copy under a mangled name.
 */
/** 用限定套件 ID 和服务键生成稳定、长度受控的公开 serverName。 */
export declare function deriveServerName(suiteId: string, serverKey: string): string;
