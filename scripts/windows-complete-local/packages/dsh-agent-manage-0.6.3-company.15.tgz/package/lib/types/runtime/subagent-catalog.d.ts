import type { Context } from '@deepseek-ai/cordis';
import { type UserMessage } from '@deepseek-ai/dsh-llm';
import type { HostTranslate } from './host-locale.js';
export interface SubagentCatalogEntry {
    /** Exact execution identity, independent of the human-readable title. */
    name: string;
    title: string;
    description: string;
    provider?: string;
    model?: string;
    reasoningEffort?: string;
}
export interface SubagentCatalogSource {
    kind: 'subagent-catalog';
    form: 'catalog';
    update?: true;
    entries: readonly SubagentCatalogEntry[];
}
declare module '@deepseek-ai/dsh-llm' {
    interface MessageSourceMap {
        'subagent-catalog': SubagentCatalogSource;
    }
}
/** Structural host contract avoids a second installation of the agent/session runtimes. */
export interface CatalogAgent {
    session: {
        seq: number;
        surface: {
            nodes: readonly number[];
        };
        eventAt(seq: number): {
            type: string;
            seq: number;
            data: unknown;
        } | undefined;
    };
}
export type CatalogStepDecision = {
    kind: 'reject';
} | {
    kind: 'enter';
    messages: UserMessage[];
    startsRequestSeries?: true;
};
export type CatalogStepListener = (payload: {
    agent: CatalogAgent;
    signal: AbortSignal;
}, next: () => Promise<CatalogStepDecision>) => Promise<CatalogStepDecision>;
/** Register after the exact tool definition; teardown removes guidance before execution. */
/** 注册 agent/pre-step 监听，将最新目录发布到会话并返回卸载函数。 */
export declare function mountSubagentCatalog(ctx: Context, tool: {
    name: string;
}, snapshot: (agent: CatalogAgent, signal: AbortSignal) => Promise<SubagentCatalogEntry[]>, t: HostTranslate): () => void;
