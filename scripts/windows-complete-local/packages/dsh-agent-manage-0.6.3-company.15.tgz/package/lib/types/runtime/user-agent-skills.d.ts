import type { Context } from '@deepseek-ai/cordis';
import type { UserAgentSkill } from '../contracts/user-agents.js';
export declare const inject: string[];
/** Mounted by the official preset Loader, so every contribution belongs to its revision scope.
 * Provider references are resolved afresh; overrides never modify their source files.
 */
export declare function apply(ctx: Context, config: {
    skills: UserAgentSkill[];
}): void;
