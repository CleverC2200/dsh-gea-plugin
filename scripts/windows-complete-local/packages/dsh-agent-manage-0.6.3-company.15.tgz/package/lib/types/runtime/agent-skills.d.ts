import { z } from 'zod';
import type { Context } from '@deepseek-ai/cordis';
import type { UserAgentSkill } from '../contracts/user-agents.js';
export declare const agentSkills: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
    kind: z.ZodLiteral<"reference">;
    name: z.ZodString;
    provider: z.ZodString;
    path: z.ZodOptional<z.ZodString>;
    enabled: z.ZodBoolean;
    content: z.ZodOptional<z.ZodString>;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"personal">;
    name: z.ZodString;
    description: z.ZodString;
    content: z.ZodString;
    enabled: z.ZodBoolean;
}, z.core.$strip>], "kind">>;
/** Capture only the selected body; references and scripts keep their source directory. */
export declare function captureAgentSkills(ctx: Pick<Context, 'skills'>, skills: UserAgentSkill[]): Promise<UserAgentSkill[]>;
