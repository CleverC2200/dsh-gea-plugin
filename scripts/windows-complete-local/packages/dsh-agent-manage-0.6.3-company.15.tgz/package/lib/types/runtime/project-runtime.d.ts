/** 文件作用：把项目级命令、MCP、hooks 和说明挂载到现有及新建 Agent。 */
/** Native project effects are owned by the receiving agent's scoped host context. */
import type { Context } from '@deepseek-ai/cordis';
import type { Catalog } from '../application/catalog.js';
import type { HostTranslate } from './host-locale.js';
import type { Suite } from '../model/types.js';
/** Mount under existing and newly created agents; the caller owns refresh and teardown. */
/** 将项目命令注册到现有/新建 Agent，并返回刷新与释放控制器。 */
export declare function mountProjectCommands(ctx: Context, catalog: Catalog, t: HostTranslate): {
    refresh(): Promise<void>;
    dispose(): Promise<void>;
};
/** MCP uses a separate injected child so network startup cannot delay local commands. */
/** 将项目 MCP 注册到 Agent 作用域，配置来源由 catalog 和 dataRoot 决定。 */
export declare function mountProjectMcp(ctx: Context, catalog: Catalog, dataRoot: string): {
    refresh(): Promise<void>;
    dispose(): Promise<void>;
};
/** Wait for both bridge dependencies before attempting a scoped hook mount. */
/** 将项目 hooks 注册到 Agent 作用域，生命周期由返回控制器管理。 */
export declare function mountProjectHooks(ctx: Context, catalog: Catalog): {
    refresh(): Promise<void>;
    dispose(): Promise<void>;
};
/** Kimi's startup skill and system-prompt declarations use the existing scoped prompt service. */
/** 将套件说明注入 Agent 会话前置上下文，并随目录快照刷新。 */
export declare function mountSuiteInstructions(ctx: Context, catalog: Catalog): {
    refresh(): Promise<void>;
    dispose(): Promise<void>;
};
/** 读取并拼接套件说明 Markdown，返回正文及逐套件读取错误。 */
export declare function suiteInstructions(suites: readonly Suite[]): Promise<{
    text: string;
    errors: Array<{
        suiteId: string;
        reason: string;
    }>;
}>;
