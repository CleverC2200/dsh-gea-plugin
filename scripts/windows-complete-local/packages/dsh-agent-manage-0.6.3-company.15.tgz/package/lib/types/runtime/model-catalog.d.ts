/** 文件作用：从宿主 LLM 服务读取提供商、模型和推理能力目录。 */
import type { ModelCatalogPayload } from '../contracts/market.js';
interface ModelCatalogHost {
    get?(name: string): unknown;
}
/** Read providers, model identities, or one exact model's reasoning options with a bounded adapter wait. */
/** 按 provider/model 查询宿主目录，并以超时和 AbortSignal 控制外部服务等待。 */
export declare function readModelCatalog(host: ModelCatalogHost, provider?: string, model?: string): Promise<ModelCatalogPayload>;
export {};
