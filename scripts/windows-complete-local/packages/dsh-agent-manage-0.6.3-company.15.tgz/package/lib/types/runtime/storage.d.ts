export declare function assertCanonicalStorageDirectories(): Promise<void>;
