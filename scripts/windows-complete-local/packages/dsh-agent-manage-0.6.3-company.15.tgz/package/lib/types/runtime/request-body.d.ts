/** Local limit for mutating JSON routes, independent of the host transport cap. */
export declare const MAX_JSON_BODY_BYTES: number;
export declare class RequestBodyTooLarge extends Error {
    constructor();
}
/** Read a Fetch stream with the same bound as the existing node:http JSON routes. */
export declare function readJsonRequest(request: Request): Promise<unknown>;
