import type { Context } from '@deepseek-ai/cordis';
import type { AgentSourceBaseline } from '../contracts/agent-sources.js';
import type { UserAgentView, UserAgentSkillOption } from '../contracts/user-agents.js';
import type { RuntimeManagement } from '../application/runtime-management.js';
export { agentSkills } from './agent-skills.js';
import { AgentMcp } from './agent-mcp.js';
/** Owns durable personal configurations and their official preset publication.
 * Writes are serialized; the registry retains old revisions for live Sessions.
 * Saving records the editable configuration even if its publication fails.
 */
export declare class UserAgents {
    private readonly ctx;
    private readonly file;
    private agents;
    private readonly cubeGrants;
    private releases;
    private published;
    private errors;
    private pending;
    private closed;
    private readonly listeners;
    readonly mcp?: AgentMcp;
    constructor(ctx: Context, file: string, runtime?: RuntimeManagement);
    load(): Promise<void>;
    /** Observe committed lifecycle/configuration changes; listeners may start async reads.
     * Notifications are synchronous signals and are never awaited inside the write queue.
     */
    watch(listener: () => void): () => void;
    list(): Promise<UserAgentView[]>;
    save(input: unknown): Promise<UserAgentView>;
    /** Imports only Host-discovered configuration; repeat imports preserve user customization. */
    importSource(input: unknown, source: AgentSourceBaseline): Promise<UserAgentView>;
    /** Complete a multi-resource import only after its external MCP associations exist. */
    finishSourceImport(id: string, mcpReferences: NonNullable<AgentSourceBaseline['mcpReferences']>): Promise<UserAgentView>;
    /** Commit an already resolved source candidate. Unlike ordinary edits, a failed sync
     * keeps the previous durable configuration and its usable declaration. */
    syncSource(id: string, expectedRevision: number, input: unknown, source: AgentSourceBaseline, signal?: AbortSignal): Promise<UserAgentView>;
    /** Resolves the declaration retained by Core, then applies current revocation. */
    cubeFor(agent: {
        ctx: Context;
    }): {
        sourceRef: string;
        signal: AbortSignal;
        generation: string;
    } | undefined;
    private syncCubeGrants;
    saveCube(id: string, input: unknown): Promise<UserAgentView>;
    pluginAgents(): Promise<UserAgentView[]>;
    savePlugin(input: unknown): Promise<UserAgentView>;
    setPluginEnabled(id: string, enabled: boolean): Promise<UserAgentView>;
    cubeSources(): {
        sourceRef: string;
        name: string;
        enabled: boolean;
        available: boolean;
    }[];
    setPluginCubeEnabled(sourceRef: string, enabled: boolean): Promise<void>;
    copyPlugin(sourceRef: string): Promise<UserAgentView>;
    skillCatalog(cwd?: string, signal?: AbortSignal): Promise<UserAgentSkillOption[]>;
    readSkill(name: string, provider: string, cwd?: string, signal?: AbortSignal, path?: string): Promise<{
        content: string;
    }>;
    saveSkills(id: string, input: unknown): Promise<UserAgentView>;
    setEnabled(id: string, enabled: boolean): Promise<UserAgentView>;
    /** Retire only the personal configuration. Core owns all Sessions and drafts. */
    remove(id: string): Promise<UserAgentView>;
    /** Restore configuration only; enabling its capabilities is a separate user action. */
    restore(id: string): Promise<UserAgentView>;
    select(id: string): Promise<{
        preset: string;
    }>;
    dispose(): Promise<void>;
    private find;
    private write;
    private persist;
    private preset;
    private register;
    private prepare;
    private publish;
    private withdraw;
    private assertReady;
    private view;
}
