/** 文件作用：按配置创建 MCP stdio、Streamable HTTP 或传统 SSE 传输。 */
/**
 * Transport factory: creates the appropriate MCP transport based on the
 * bridge's resolved config. Stdio spawns a child process (with credential
 * scrubbing); Streamable HTTP connects to a URL; legacy SSE connects to a
 * URL with the pre-Streamable-HTTP protocol pairing. Both HTTP transports
 * carry OAuth 2.1 authorization by default, activated by the server's first
 * `401` challenge.
 *
 * @module runtime/mcp-client/transport
 */
import type { Transport } from '@modelcontextprotocol/sdk/shared/transport.js';
import { type AuthorizationState, LoopbackOAuthClientProvider } from './oauth.js';
import type { Config } from './config.js';
/**
 * Create an MCP transport from the resolved bridge config.
 *
 * With OAuth active (the default), the Streamable HTTP and SSE transports
 * carry an {@link OAuthClientProvider}: the first `401` from the server
 * starts discovery, dynamic registration, and a loopback browser
 * authorization, and granted tokens persist through the credentials service
 * for later processes. Transport generation identity stays with the caller —
 * the provider binds whichever transport it hands out, so a reconnect builds
 * a fresh generation on the same durable state.
 *
 * @param config - Resolved bridge config discriminated on `transport`.
 * @param credentials - The composition's credential store, when mounted; OAuth
 *   state persists only when it is.
 * @param log - Diagnostic sink for the human leg of the flow.
 * @returns The transport plus its OAuth provider, when active — the
 *   supervisor queries the provider to hold the generation open while a
 *   browser leg is pending.
 */
/** 根据传输类型创建 MCP SDK transport，并绑定凭据、日志和环境策略。 */
export declare function createTransport(config: Config, credentials?: unknown, log?: (message: string) => void, onAuthorizationState?: (state: AuthorizationState) => void): {
    transport: Transport;
    oauthProvider: LoopbackOAuthClientProvider | undefined;
};
