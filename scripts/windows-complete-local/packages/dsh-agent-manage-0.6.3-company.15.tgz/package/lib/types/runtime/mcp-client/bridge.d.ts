/** 文件作用：实现单个 MCP 服务的桥接插件，负责连接、工具注册和生命周期释放。 */
/**
 * The market's self-built MCP client bridge plugin: connects to one external
 * MCP server and registers its tools on the harness ToolRuntime under
 * server-qualified public names (`mcp__<serverName>__<rawName>`). One plugin
 * instance per server; the mount registry loads instances through
 * `ctx.plugin` exactly like the host's own client, so reconcile, retry,
 * rollback, and HMR semantics are unchanged.
 *
 * Namespace plugin (named exports, no default export). Lifecycle is
 * effect-scoped: disposal disconnects from the server, unregisters all tools,
 * and releases the `serverName` namespace reservation. HMR hot-swaps by
 * disposing the old instance and creating a new one; identical `serverName`
 * reproduces identical public tool names.
 *
 * This replaces the runtime dependency on the host's `dsh-mcp-client`
 * package: stdio, Streamable HTTP (with OAuth 2.1), and legacy SSE all run
 * inside this plugin from the market's own `@modelcontextprotocol/sdk`
 * dependency.
 *
 * @module runtime/mcp-client/bridge
 */
import type { Context } from '@deepseek-ai/cordis';
import type { Config } from './config.js';
/** Cordis plugin name used by loader diagnostics. */
export declare const name = "market-mcp-client";
/** Services required by this plugin. */
export declare const inject: string[];
/** Read the supervisor's current generation, including legitimate zero-tool servers. */
export declare function connectionState(root: Context, serverName: string): import("../../contracts/mcp-status.js").McpConnectionState | undefined;
/** Cancel only the current generation; no credential record is removed. */
export declare function cancelAuthorization(root: Context, serverName: string): void;
/**
 * Connect one MCP server and publish its initial tool generation before
 * activation. Remains explicitly `async`: Cordis treats a prototype-bearing
 * ordinary function as a constructor, whose returned Promise is not startup
 * work.
 * @param ctx - plugin context carrying the tool registry.
 * @param config - resolved transport and server namespace configuration.
 * @returns startup readiness after connection and initial tool discovery settle.
 */
/** 启动单个 MCP 桥接实例，连接服务并同步工具；退出时由宿主效果释放。 */
export declare function apply(ctx: Context, config: Config): Promise<void>;
