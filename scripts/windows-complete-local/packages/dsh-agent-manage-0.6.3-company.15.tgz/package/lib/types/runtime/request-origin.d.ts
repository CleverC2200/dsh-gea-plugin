/** Core admits the browser before dispatch; its Fetch bridge replaces the URL's origin. */
export declare function isSameOriginRequest(request: Request): boolean;
