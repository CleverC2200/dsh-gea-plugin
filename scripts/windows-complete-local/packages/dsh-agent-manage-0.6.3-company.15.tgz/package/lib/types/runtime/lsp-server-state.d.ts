/** 根据数据根目录定位 LSP 禁用状态文件。 */
export declare function lspServerStatePath(dataRoot: string): string;
/** 读取禁用服务集合；缺失或损坏时按空集合处理，避免阻断运行时启动。 */
export declare function loadDisabledLspServers(dataRoot: string): Promise<Set<string>>;
/** 去重、排序并持久化禁用服务集合，确保状态文件稳定可审计。 */
export declare function saveDisabledLspServers(dataRoot: string, disabled: Iterable<string>): Promise<void>;
