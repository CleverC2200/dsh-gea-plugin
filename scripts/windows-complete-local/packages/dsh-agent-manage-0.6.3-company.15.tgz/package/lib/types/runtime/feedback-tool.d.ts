/** 文件作用：提供可选的反馈工具，把问题提交到远端仓库或本地队列。 */
/**
 * Optional model-facing experience-feedback tool.
 *
 * When enabled (the `feedbackEnabled` field of the market settings namespace,
 * default true), the model can call `report_market_issue` when it concludes a
 * problem it is looking at is caused by dsh-agent-plugins-market — a failed
 * install, a misdetected source, a market UI defect the user just described.
 * The tool files a GitHub issue on the plugin repository through the GitHub
 * REST API, or falls back to appending a local JSONL record under the plugin
 * data root when no repository host context is available.
 *
 * The tool is deliberately narrow: the title/body must describe the problem,
 * submissions are rate-limited, and the setting switch unregisters the tool
 * on the next reconcile pass.
 * @module runtime/feedback-tool
 */
import type { Context } from '@deepseek-ai/cordis';
/** The GitHub repository experience feedback files issues against. */
export declare const FEEDBACK_REPO_OWNER = "CleverC2200";
export declare const FEEDBACK_REPO_NAME = "dsh-agent-manage";
/** Label applied to every tool-filed issue so they are filterable. */
export declare const FEEDBACK_LABEL = "agent-feedback";
/** One accepted or rejected submission outcome, mirrored to the model. */
export interface FeedbackOutcome {
    ok: boolean;
    /** Where the report went: the issue URL, or the local fallback path label. */
    location?: string;
    reason?: string;
}
/** A structured experience report the model composes. */
export interface FeedbackReport {
    title: string;
    description: string;
    /** What the user was trying to do, when the model can tell. */
    expected?: string;
    /** What actually happened (errors, wrong state, broken flow). */
    actual?: string;
}
/**
 * Submit one experience report. Tries the GitHub issue API first (works when
 * the deployment carries a GITHUB_TOKEN / GH_TOKEN with repo scope), then
 * falls back to the local JSONL spool under `<dataRoot>/feedback/`.
 */
/** 校验限流窗口后提交反馈；远端不可用时落本地 JSONL，始终返回可追踪结果。 */
export declare function submitFeedback(dataRoot: string, report: FeedbackReport, now?: number): Promise<FeedbackOutcome>;
/** Render the model's structured report into a deterministic issue body. */
/** 将反馈报告格式化为 Markdown issue 内容，保留用户可核对的事实字段。 */
export declare function renderFeedbackBody(report: FeedbackReport): string;
export declare const FEEDBACK_TOOL_NAME: "report_market_issue";
/** Register the feedback tool; returns the disposer. Undefined when the host has no tools service. */
/** 在宿主支持工具注册时挂载反馈工具，否则返回 undefined 表示能力不可用。 */
export declare function mountFeedbackTool(hostCtx: Context, dataRoot: string, t: (key: string, params?: Record<string, string>) => string): (() => void) | undefined;
