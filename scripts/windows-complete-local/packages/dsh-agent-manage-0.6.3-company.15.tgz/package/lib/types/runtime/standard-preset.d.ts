import type { Context } from '@deepseek-ai/cordis';
import { type PresetDefinition } from '@deepseek-ai/dsh-agent-preset-registry';
export declare const ORCHESTRATION_PRESET: {
    readonly id: "auto-negotiation";
    readonly name: "智能编排";
    readonly description: "通用任务的完整官方标准能力，支持上下文压缩、规划、任务和协作。";
    readonly order: 0;
};
type Plugin = PresetDefinition['plugins'][number];
export interface StandardPresetAdditions {
    /** Business instructions append to the standard persona without replacing its runtime context. */
    personaPrefix?: string;
    /** Extra plugin rows must not duplicate an existing plugin or its entry id. */
    plugins?: readonly Plugin[];
}
/**
 * Reuse the active official standard declaration through its public registry document.
 * The Loader dialect preserves expressions, disabled rows and isolated nested groups.
 * Missing standard or conflicting additions reject; callers own registration and disposal.
 */
export declare function composeStandardPreset(registry: Pick<Context['agentPresets'], 'readDocument'>, metadata: Omit<PresetDefinition, 'plugins'>, additions?: StandardPresetAdditions): Promise<PresetDefinition>;
export declare const inject: string[];
export declare function apply(ctx: Context): Promise<void>;
export {};
