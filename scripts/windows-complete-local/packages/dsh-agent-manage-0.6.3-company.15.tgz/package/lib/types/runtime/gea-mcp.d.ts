/** Register authorized GEA gateway schemas; GEA owns execution identity and transport. */
import type { Context } from '@deepseek-ai/cordis';
export interface GeaMcpTool {
    name: 'inspect_cube_model' | 'query_business_data' | 'weknora_list_knowledge_bases' | 'weknora_ask';
    description: string;
    inputSchema: Record<string, unknown>;
}
/** Host-only capability: credentials and Consumer selection remain in GEA. */
export interface GeaMcpService {
    version: 2;
    authenticated(): boolean;
    identitySignal(): AbortSignal;
    watch(listener: () => void): () => void;
    allows(sessionId: string): boolean;
    listTools(signal: AbortSignal): Promise<GeaMcpTool[]>;
    call(sessionId: string, name: string, args: Record<string, unknown>, signal: AbortSignal): Promise<string>;
}
interface Mount {
    await(): Promise<unknown>;
    dispose(): void | Promise<void>;
}
/** Runtime publication state shared by login events and first-request admission. */
export interface GeaLoginRuntime {
    readonly revision: number;
    ready(signal?: AbortSignal): Promise<void>;
    dispose(): Promise<void>;
}
/** Prepare same-identity refreshes before replacing tools; revoke changed identities first. */
export declare function followGeaLogin(service: GeaMcpService, mount: (tools: GeaMcpTool[], signal: AbortSignal) => Mount, warn: () => void): GeaLoginRuntime;
/** Publish server-qualified native MCP methods without another model-facing query wrapper. */
export declare function mountGeaMcp(ctx: Context): void;
export {};
