/** 文件作用：选择内置或宿主 MCP 后端，并探测宿主兼容能力。 */
/**
 * MCP backend selection: whether suite MCP servers mount through the
 * market's self-built bridge (default — stdio, Streamable HTTP with OAuth,
 * and legacy SSE) or through the host's `@deepseek-ai/dsh-mcp-client`
 * (compatibility mode: no OAuth, no SSE, but the host-native implementation).
 *
 * The native SettingsForms namespace is the shipped `dsh-agent-manage`
 * Loader entry. Its volatile Config fields drive the custom client card and
 * host reconciler; no separate settings store or namespace is registered.
 *
 * @module runtime/mcp-backend
 */
import z from '@deepseek-ai/schemastery';
/** The MCP mount backend the market uses for suite servers. */
export type McpBackend = 'builtin' | 'host';
export declare const MCP_BACKENDS: readonly McpBackend[];
/** Shipped Loader entry id used by the native plugin-config card. */
export declare const MCP_SETTINGS_NAMESPACE = "dsh-agent-manage";
export declare const MarketSettingsSchema: z<Schemastery.ObjectS<NoInfer<{
    /** ON (default) = the built-in bridge with OAuth and SSE; OFF = host client compat mode. */
    mcpEnhanced: z<boolean, boolean, "defined">;
    /** Read native Agent layouts under the project root; default preserves existing discovery. */
    scanProjectLayouts: z<boolean, boolean, "defined">;
    /** Download region for GitHub acquisition; `auto` follows the interface language. */
    downloadRegion: z<"auto" | "global" | "china", "auto" | "global" | "china", "defined">;
    /** ON (default) = the `report_market_issue` model tool is registered; OFF = unregistered. */
    feedbackEnabled: z<boolean, boolean, "defined">;
}>>, Schemastery.ObjectT<NoInfer<{
    /** ON (default) = the built-in bridge with OAuth and SSE; OFF = host client compat mode. */
    mcpEnhanced: z<boolean, boolean, "defined">;
    /** Read native Agent layouts under the project root; default preserves existing discovery. */
    scanProjectLayouts: z<boolean, boolean, "defined">;
    /** Download region for GitHub acquisition; `auto` follows the interface language. */
    downloadRegion: z<"auto" | "global" | "china", "auto" | "global" | "china", "defined">;
    /** ON (default) = the `report_market_issue` model tool is registered; OFF = unregistered. */
    feedbackEnabled: z<boolean, boolean, "defined">;
}>>, "plain">;
/** What the host client probe reports: resolvability plus its version. */
export interface HostMcpClientProbe {
    available: boolean;
    version?: string;
}
/**
 * Probe whether the host's `dsh-mcp-client` is resolvable from this plugin's
 * module context, and at which version. Best effort: any failure reads as
 * "unavailable", which the mount path surfaces as a per-server diagnostic
 * when the host backend is selected.
 */
/** 探测宿主 MCP 客户端是否可解析及版本；任何失败均返回 unavailable，不抛出发现异常。 */
export declare function probeHostMcpClient(): Promise<HostMcpClientProbe>;
/** Reuse the same field rules as live Loader Config without changing plain validation. */
export declare const ManageConfigSchema: z<Schemastery.ObjectS<NoInfer<{
    mcpEnhanced: z<boolean, boolean, "volatile-defined">;
    scanProjectLayouts: z<boolean, boolean, "volatile-defined">;
    downloadRegion: z<"auto" | "global" | "china", "auto" | "global" | "china", "volatile-defined">;
    feedbackEnabled: z<boolean, boolean, "volatile-defined">;
}>>, Schemastery.ObjectT<NoInfer<{
    mcpEnhanced: z<boolean, boolean, "volatile-defined">;
    scanProjectLayouts: z<boolean, boolean, "volatile-defined">;
    downloadRegion: z<"auto" | "global" | "china", "auto" | "global" | "china", "volatile-defined">;
    feedbackEnabled: z<boolean, boolean, "volatile-defined">;
}>>, "plain">;
