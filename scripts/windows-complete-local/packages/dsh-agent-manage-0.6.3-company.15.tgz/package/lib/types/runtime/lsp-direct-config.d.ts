import type { LspServerSpec } from '../model/types.js';
/** The direct LSP server configuration file path. */
/** 根据数据根目录返回直接 LSP 配置文件路径，供读写和状态层共用。 */
export declare function lspServersPath(dataRoot: string): string;
/** Load the user-configured LSP servers; unreadable or invalid files yield an empty table. */
/** 读取并解析用户 LSP 表；缺失视为空配置，格式错误转为诊断而非阻断套件发现。 */
export declare function loadLspServers(dataRoot: string): Promise<{
    servers: Record<string, LspServerSpec>;
    errors: string[];
}>;
/** Validate and persist the user-configured LSP servers; returns normalized specs. */
/** 校验并保存用户 LSP 配置，返回规范化后的服务表供后续挂载。 */
export declare function saveLspServers(dataRoot: string, raw: unknown): Promise<{
    servers: Record<string, LspServerSpec>;
}>;
