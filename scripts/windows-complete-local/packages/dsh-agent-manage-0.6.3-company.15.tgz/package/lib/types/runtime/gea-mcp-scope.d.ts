/** 文件作用：按 Agent 预设限制 GEA MCP 工具的可见性和调用范围。 */
/** Agent-preset boundary for the login-owned gateway; never trusts prompt text. */
export interface GeaScopeAgent {
    id?: string;
    ctx: {
        tools: {
            restrict(filter: {
                deny: string[];
            }): () => void;
        };
    };
}
/** Minimal host capability needed to mask schemas and deny stale tool calls. */
export interface GeaScopeHost {
    agents: {
        list(): GeaScopeAgent[];
    };
    agentPresets: {
        composedPreset(ctx: GeaScopeAgent['ctx']): string | undefined;
    };
    tools: {
        schemas(): {
            name: string;
        }[];
        guard(check: (exec: {
            name: string;
            agent?: GeaScopeAgent;
        }) => string | undefined): () => void;
    };
    /** 中文：监听宿主 Agent 事件，返回解除监听的函数。 */
    on(event: string, listener: () => void): () => void;
}
/** Keep live and newly created agents masked, including preset switches and login refreshes. */
/** 安装工具守卫并同步现有 Agent 的 schema 屏蔽；返回一次性释放函数。 */
export declare function restrictGeaMcp(host: GeaScopeHost, permits: (agent: GeaScopeAgent) => boolean, watch?: (listener: () => void) => () => void): () => void;
