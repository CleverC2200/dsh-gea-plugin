/** Read only linked references of Skills visible in the current caller workspace. */
import type { Context } from '@deepseek-ai/cordis';
/** The existing Manage resource runtime owns this read-only tool; visibility comes from the official Skill registry. */
export declare function mountSkillReferenceReader(host: Context): void;
