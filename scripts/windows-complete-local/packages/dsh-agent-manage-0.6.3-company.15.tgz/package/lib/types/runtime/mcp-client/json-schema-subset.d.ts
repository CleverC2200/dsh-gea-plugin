/** 文件作用：验证 MCP 工具输出 Schema 是否属于可无损桥接的 JSON 子集。 */
/**
 * Local port of the harness's enforced JSON Schema subset validator
 * (`@deepseek-ai/dsh-tools` `json-schema.ts`, rc.2) — narrowed to the one use
 * the MCP bridge has: deciding whether an MCP server's advertised
 * `outputSchema` may ride a tool registration as a structured-output schema.
 *
 * The upstream validator is 656 lines with realm-safe JSON intrinsics; this
 * port keeps the *contract* — a closed keyword table, one scalar `type`,
 * nested structure, and "unsupported keywords reject rather than pass
 * unenforced" — with a conservative structural check. A schema this check
 * wrongly rejects only loses structured typing (the bridge falls back to
 * untyped JSON, exactly the upstream failure mode); one it wrongly accepts
 * would flow into the host registry, so every branch here fails closed.
 *
 * @module runtime/mcp-client/json-schema-subset
 */
/** Scalar JSON values supported by `enum` and `const`. */
export type JsonSchemaScalar = string | number | boolean | null;
/** Single-type keywords accepted by the enforced subset. */
export type JsonSchemaType = 'object' | 'array' | 'string' | 'number' | 'integer' | 'boolean' | 'null';
/**
 * One raw JSON Schema node in the enforced subset. The optional fields express
 * the external wire schema; {@link assertSupportedJsonSchema} rejects invalid
 * combinations before a caller treats the node as trusted.
 */
export interface JsonSchemaNode {
    /** Omit with no constraints for any JSON value, or use `oneOf`. */
    type?: JsonSchemaType;
    /** Exactly one branch must validate; at least two branches are required. */
    oneOf?: JsonSchemaNode[];
    /** Nested property schemas (`type: 'object'` only). */
    properties?: Record<string, JsonSchemaNode>;
    /** Required property names; each must appear in `properties`. */
    required?: string[];
    /** `false` rejects undeclared keys; absent/`true` follows JSON Schema's open default. */
    additionalProperties?: boolean;
    /** Item schema (`type: 'array'` only); absent accepts any JSON item. */
    items?: JsonSchemaNode;
    /** Allowed values for a scalar node. */
    enum?: JsonSchemaScalar[];
    /** The single allowed value for a scalar node. */
    const?: JsonSchemaScalar;
    /** Annotation, ignored for validation. */
    description?: string;
    /** Annotation, ignored for validation. */
    title?: string;
    /** Annotation, ignored for validation but required to be lossless JSON. */
    default?: JsonSchemaScalar | Record<string, unknown> | unknown[];
    /** Annotation, ignored for validation but required to be lossless JSON. */
    examples?: JsonSchemaScalar | Record<string, unknown> | unknown[];
}
/**
 * Assert that a raw schema uses only the enforced subset. Annotation-only
 * schemas are accepted as the standard unconstrained-JSON form.
 * @param schema - untrusted raw JSON Schema.
 * @throws Error listing every violation when the schema leaves the subset.
 */
/** 递归验证工具输出 Schema 子集；发现不支持结构时抛出完整路径诊断。 */
export declare function assertSupportedJsonSchema(schema: unknown): asserts schema is JsonSchemaNode;
