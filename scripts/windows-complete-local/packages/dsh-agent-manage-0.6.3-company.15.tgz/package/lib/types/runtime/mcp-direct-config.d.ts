import type { Suite } from '../model/types.js';
export declare const USER_MCP_SOURCE = "@user-mcp";
export declare const USER_MCP_SUITE = "user-mcp";
/** User-created services reuse the owned bridge lifecycle without changing host configuration. */
/** 读取用户 MCP 文件并包装成虚拟套件；坏配置保留错误但不影响其他套件。 */
export declare function loadUserMcpSuite(dataRoot: string): Promise<Suite>;
/** Add one service atomically; reject collisions and malformed config before writing. */
/** 校验新增服务并原子写入用户 MCP 文件，拒绝非法名称和重复键。 */
export declare function addUserMcpServer(dataRoot: string, name: string, server: unknown, sourceRoot?: string): Promise<void>;
