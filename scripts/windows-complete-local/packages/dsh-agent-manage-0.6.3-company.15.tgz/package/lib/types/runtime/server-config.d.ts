import type { LspServerSpec, Suite } from '../model/types.js';
/** Restore only unchanged redacted leaves, rejecting invented masked values. */
/** 将编辑回显中的原样脱敏叶恢复为原值，拒绝伪造或改写的掩码内容。 */
export declare function restoreRedactedConfig(input: unknown, original: unknown, redacted?: unknown): unknown;
/** 用统一 Schema 和运行时解析器校验单个 MCP 服务，返回可挂载的规范配置。 */
export declare function validateServerMcp(root: string, key: string, config: unknown): Promise<import("../model/types.js").McpServerStdio | import("../model/types.js").McpServerStreamableHttp | import("../model/types.js").McpServerSse>;
/** 校验单个 LSP 服务并返回带派生 key 的规范声明，非法输入直接失败关闭。 */
export declare function validateServerLsp(key: string, config: unknown): LspServerSpec;
/** Public configuration excludes the parser's derived identity. */
/** 移除内部 key 后生成可持久化、可编辑的公开配置。 */
export declare function lspConfig(spec: LspServerSpec): Record<string, unknown>;
/** 读取并校验 LSP 覆盖表；缺失为空表，其他错误交给调用方呈现。 */
export declare function loadLspOverrides(root: string): Promise<Record<string, LspServerSpec>>;
/** 更新单个覆盖项并原子写回，保持其他套件的覆盖不变。 */
export declare function saveLspOverride(root: string, id: string, config: LspServerSpec): Promise<void>;
/** 将按限定套件 ID 存储的覆盖应用到快照，返回不改变原对象的套件数组。 */
export declare function applyLspOverrides(root: string, suites: Suite[]): Promise<Suite[]>;
