import type { Context } from '@deepseek-ai/cordis';
import type { Suite } from '../model/types.js';
export interface HooksMountDiagnostic {
    suiteId: string;
    reason: string;
}
export declare class HooksMountRegistry {
    private readonly ctx;
    private readonly live;
    private readonly fingerprints;
    private readonly temporary;
    private queue;
    /** 绑定 Cordis 上下文，所有 hooks 插件都在该作用域创建和释放。 */
    constructor(ctx: Context);
    /** Mount/unmount one bridge per suite to match the enabled suites exactly. */
    /** 串行对账 hooks 挂载，避免并发变更破坏宿主拦截链。 */
    reconcile(enabledSuites: Suite[]): Promise<HooksMountDiagnostic[]>;
    /** 在队列内执行实际增删，逐套件隔离文件和插件错误。 */
    private reconcileNow;
    /** Dispose every live bridge; used at plugin teardown. */
    /** 串行释放全部 hooks 挂载并清理临时配置文件。 */
    disposeAll(): Promise<void>;
    /** 为单套件写入临时 hook 配置并挂载桥接插件，返回失败原因或 undefined。 */
    private mount;
    /** 释放单套件 hook 插件并删除临时文件，失败向上转成诊断。 */
    private unmount;
}
/** The first existing CC hook config of a suite root. */
/** 读取套件 hooks.json 路径；不存在返回 undefined，区分无 hooks 与坏配置。 */
export declare function hookConfigPath(root: string): Promise<string | undefined>;
