/** 文件作用：统一编排命令、hooks、MCP、LSP 四类运行时表面的对账和释放。 */
/**
 * Runtime reconciliation for enabled suites.
 *
 * One catalog snapshot is fanned out to the existing MCP, command, hook, and
 * LSP mount adapters. The adapters remain separate because their host surfaces
 * and failure semantics differ; this module owns ordering, containment, and
 * disposal only.
 */
import type { Context } from '@deepseek-ai/cordis';
import { type CommandMountDiagnostic } from './commands-mounts.js';
import { type HooksMountDiagnostic } from './hooks-mounts.js';
import { LspMountRegistry, type LspMountDiagnostic } from './lsp-mounts.js';
import { McpMountRegistry, type McpMountDiagnostic } from './mcp-mounts.js';
import type { Suite } from '../model/types.js';
import { type HostTranslate } from './host-locale.js';
/** Diagnostics returned by one runtime reconciliation pass. */
export interface RuntimeDiagnostics {
    mcp: McpMountDiagnostic[];
    commands: CommandMountDiagnostic[];
    hooks: HooksMountDiagnostic[];
    lsp: LspMountDiagnostic[];
    errors: Array<{
        surface: 'mcp' | 'commands' | 'hooks' | 'lsp';
        reason: string;
    }>;
}
export declare class RuntimeReconciler {
    readonly mcp: McpMountRegistry;
    private readonly commands;
    private readonly hooks;
    readonly lsp: LspMountRegistry;
    private readonly queues;
    private disposed;
    /** 创建四类运行时表面的协调器，所有表面共享同一宿主上下文和数据根。 */
    constructor(ctx: Context, dataRoot: string, t?: HostTranslate);
    /** Reconcile all runtime surfaces against one enabled-suite snapshot. */
    /** 并行触发四类表面对账，按表面隔离异常并返回完整诊断快照。 */
    reconcile(enabledSuites: readonly Suite[]): Promise<RuntimeDiagnostics>;
    /** Dispose all live mounts and registrations. */
    /** 并行释放四类表面；单表面失败记录为错误而不阻塞其他释放。 */
    dispose(): Promise<void>;
}
