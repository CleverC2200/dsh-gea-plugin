import type { SkillCandidate, SkillDefinition, SkillLookupOptions, SkillProvider } from '@deepseek-ai/dsh-skill';
import type { Catalog } from '../application/catalog.js';
export declare const SUITE_PROJECT_SOURCE = "agent-plugin-project";
export declare const SUITE_USER_SOURCE = "agent-plugin-user";
export declare class SuiteSkillProvider implements SkillProvider {
    private readonly manager;
    readonly name = "agent-plugin";
    /** 保存目录管理器，后续查询从其当前套件快照定位技能。 */
    constructor(manager: Catalog);
    /** 按 cwd 查询项目/用户套件技能，排序去重后返回宿主候选项。 */
    list(options: SkillLookupOptions): Promise<SkillCandidate[]>;
    /** 根据候选定位原文，替换插件根变量并返回可执行技能定义。 */
    get(candidate: SkillCandidate, _options: SkillLookupOptions): Promise<SkillDefinition | undefined>;
    /** 将内部定位记录投影为宿主候选，保留来源、优先级和资源目录。 */
    private candidateFor;
    /** 合并项目、用户和套件技能来源，保持各来源优先级边界。 */
    private locate;
    /** 在当前项目目录下定位项目维度套件技能。 */
    private locateProject;
}
