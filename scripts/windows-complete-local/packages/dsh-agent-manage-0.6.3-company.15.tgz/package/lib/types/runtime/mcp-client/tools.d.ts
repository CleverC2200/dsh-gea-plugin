/** 文件作用：把 MCP 工具同步到宿主工具表，并处理结构化结果、图片与附件投影。 */
/**
 * Tool bridge: discovers MCP tools, registers them on the harness ToolRuntime
 * under deterministic server-qualified public names, and handles re-sync when
 * the server's tool list changes.
 *
 * Naming contract (mirrored from the harness `dsh-mcp-client` naming
 * invariants): every MCP tool has the stable identity `(serverName, rawName)`;
 * the model-facing public name is `mcp__<serverName>__<rawName>`, normalized
 * to the DeepSeek function-name constraints. The raw name is only ever sent on
 * the wire (`tools/call`); the public name is never parsed to recover it.
 *
 * The host contract below (`ToolDefinition`, `ToolExecution`,
 * `ToolExecutionResult`) is a structural mirror of `@deepseek-ai/dsh-tools`
 * rc.2's registration surface — the runtime accepts the same object shape the
 * upstream bridge registers, so the model-facing behavior is identical.
 *
 * @module runtime/mcp-client/tools
 */
import type { Context } from '@deepseek-ai/cordis';
import type { Client } from '@modelcontextprotocol/sdk/client/index.js';
import type { ContentBlock } from '@deepseek-ai/dsh-llm';
import type { JsonSchemaNode } from './json-schema-subset.js';
/** Lossless JSON value vocabulary the bridge exchanges with the registry. */
export type JsonValue = string | number | boolean | null | JsonValue[] | {
    [key: string]: JsonValue;
};
/** Canonical MCP result exposed to Code Mode without discarding protocol blocks. */
export type McpResult<Structured extends JsonValue = JsonValue> = {
    content: JsonValue[];
    structuredContent?: Structured;
};
/** The agent on whose behalf a tool call runs (structural mirror). */
interface ToolExecutionAgent {
    readonly ctx?: Context;
    session?: {
        requestHeader?: () => {
            config?: {
                provider?: string;
                model?: string;
            };
        } | undefined;
    };
    options?: {
        provider?: string;
        model?: string;
    };
} /** Execution identity handed to a tool body (structural mirror). */
export interface ToolExecution {
    /** Caller-owned cancellation for this invocation. */
    readonly signal: AbortSignal;
    /** The calling agent, when the call came from one. */
    readonly agent?: ToolExecutionAgent;
}
/** A settled tool outcome (structural mirror). */
export interface ToolExecutionResult {
    readonly value: JsonValue;
    readonly content: ContentBlock[];
    readonly isError: boolean;
}
/** One registered tool (structural mirror of the host registration shape). */
export interface ToolDefinition {
    readonly name: string;
    readonly description: string;
    readonly parameters: Record<string, unknown>;
    readonly output: {
        readonly schema: JsonSchemaNode;
        /** 中文：把工具执行结果同步投影为宿主可渲染的内容块。 */
        render(args: unknown, value: JsonValue): ContentBlock[];
    };
    /** 中文：接收模型参数并调用对应 MCP 工具，返回原始或结构化结果。 */
    execute(args: unknown, exec: ToolExecution): Promise<unknown>;
    /** 中文：在执行上下文完成后汇总富内容投影，供宿主最终展示。 */
    finalizeContent?(exec: Readonly<ToolExecution>, result: Readonly<ToolExecutionResult>): ContentBlock[] | undefined;
}
/**
 * The host surface the bridge needs: a tool registry, a logger, and the two
 * optional services image projection consults. Structural — the cordis
 * context is adapted onto this shape by the bridge shell.
 */
export interface ToolHost {
    readonly logger: {
        error(message: string): void;
        warn(message: string): void;
        info(message: string): void;
    };
    readonly tools: {
        register(definition: ToolDefinition): () => void;
    };
    /** Optional service lookup; image projection degrades when absent. */
    getService?(name: 'attachments' | 'llm'): unknown;
    executionScope?(agent: ToolExecutionAgent | undefined, serverName: string): {
        signal: AbortSignal;
        validate(): void;
    } | undefined;
}
/** Resolved options relevant to tool bridging. */
export interface ToolBridgeOptions {
    enabledTools?: string[];
    disabledTools?: string[];
    startupTimeoutMs?: number;
    /** Whether a registry conflict is contained or rejects this synchronization. */
    registrationFailure: 'contain' | 'throw';
    serverName: string;
    toolCallTimeoutMs: number;
}
/** State for one sync generation: the current set of disposers keyed by public name. */
export type ToolDisposers = Map<string, () => void>;
/**
 * Derive the model-facing public name for one MCP tool.
 *
 * Deterministic pure function of `(serverName, rawName)`: the clean case is
 * `mcp__<serverName>__<rawName>` verbatim. When character replacement or
 * truncation to the DeepSeek function-name contract (64 chars,
 * `[A-Za-z0-9_-]`) changes the name, a 12-hex-char SHA-256 hash of the
 * identity is appended so distinct MCP identities never collapse into the
 * same public name.
 *
 * @param serverName - Stable local namespace from bridge config.
 * @param rawName - The MCP server's own tool name.
 * @returns The globally unique, model-facing ToolRuntime name.
 */
/** 将外部工具名规范化为宿主公开命名，并在过长或冲突时追加稳定哈希。 */
export declare function publicToolName(serverName: string, rawName: string): string;
/**
 * Sync the MCP server's tool list into the harness ToolRuntime.
 *
 * Two phases keep the swap safe:
 *
 * 1. Fetch: drain uncached `tools/list` pagination and build the full next
 *    generation of `ToolDefinition`s under public names. Any failure here
 *    (network error, duplicate raw name in the server's list) rejects and
 *    leaves the previous generation registered untouched.
 * 2. Swap: dispose the previous generation, register the new one. A registry
 *    conflict here can only mean a foreign registration squats on this
 *    server's `mcp__<serverName>__` namespace — the partial generation is
 *    rolled back (zero tools from this server) and logged. Initial strict
 *    synchronization may propagate the conflict so its parent transaction
 *    rejects; ordinary clients and later re-syncs return an empty map.
 *
 * @param client - Connected MCP Client instance used to list and call tools.
 * @param host - The bridge host providing the tool registry and logger.
 * @param opts - Bridge options: server namespace and per-call timeout.
 * @param previous - Disposer map from the prior sync generation; disposed
 *   during the swap phase (only after the fetch phase succeeded).
 * @returns A map of registered public tool names to their unregister
 *   disposers — the exact set of live registrations owned by this server.
 */
/** 分页拉取 MCP 工具、卸载旧注册并注册新工具，返回下一代释放器集合。 */
export declare function syncTools(client: Client, host: ToolHost, opts: ToolBridgeOptions, previous: ToolDisposers): Promise<ToolDisposers>;
export {};
