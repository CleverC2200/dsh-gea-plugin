import type { Context } from '@deepseek-ai/cordis';
import type { AgentSourceBaseline } from '../contracts/agent-sources.js';
import type { AgentMcpView } from '../contracts/agent-mcp.js';
import type { UserAgentConfig } from '../contracts/user-agents.js';
import type { RuntimeManagement } from '../application/runtime-management.js';
declare module '@deepseek-ai/cordis' {
    interface Context {
        agentMcpScopes: AgentMcp;
    }
}
/** Personal MCP membership, persistence and scoped execution share this owner.
 * Definitions use Catalog.runtime; every managed namespace is masked before tools register. A mutation
 * only accepts personal Agent IDs known by UserAgents, never caller provenance.
 */
export declare class AgentMcp {
    private readonly ctx;
    private readonly dataRoot;
    private readonly runtime;
    private definitions;
    private associations;
    private agents;
    private sourceAvailable;
    private closed;
    private queue;
    private readonly scopes;
    private masks;
    private readonly stop;
    constructor(ctx: Context, dataRoot: string, runtime: RuntimeManagement);
    /** Each Agent/connection gets a revocable scope; the shared transport stays mounted. */
    executionScope(subject: {
        ctx?: Context;
    } | undefined, serverName: string): {
        signal: AbortSignal;
        validate(): void;
    } | undefined;
    load(agents: readonly UserAgentConfig[]): Promise<void>;
    /** Catalog owns availability. Re-evaluate it on source changes and every dispatch. */
    setSourceAvailability(read: (source: AgentSourceBaseline) => boolean): void;
    sourceAvailabilityChanged(): void;
    agentsChanged(agents: readonly UserAgentConfig[]): Promise<void>;
    list(agentId: string, includeRetired?: boolean): Promise<AgentMcpView[]>;
    available(agentId: string): Array<Pick<AgentMcpView, 'connectionId' | 'serverId' | 'name'>>;
    save(input: unknown): Promise<AgentMcpView>;
    /** Internal source import. Root comes from the Host's resolved checkout, never HTTP provenance. */
    importSource(input: {
        agentId: string;
        connectionId?: string;
        serverId: string;
        name: string;
        config: unknown;
        source: {
            sourceId: string;
            suiteId: string;
            serverKey: string;
            root: string;
        };
        staged?: boolean;
    }): Promise<AgentMcpView>;
    private saveDefinition;
    /** Source customization includes personal membership, switches, names and effective configs. */
    sourceCustomized(agentId: string, references: NonNullable<AgentSourceBaseline['mcpReferences']>): Promise<boolean>;
    /** Raw comparison stays Host-side; the original direct definition is the upstream baseline. */
    sourceConfig(connectionId: string): Promise<{
        base: unknown;
        local: unknown;
    }>;
    /** Retired source definitions remain mounted for the Core revisions that still retain them. */
    sourceRevision(agentId: string, connectionIds: string[]): Promise<void>;
    associate(input: unknown): Promise<AgentMcpView[]>;
    setEnabled(input: unknown): Promise<AgentMcpView[]>;
    remove(input: unknown): Promise<AgentMcpView[]>;
    reauthorize(input: unknown): Promise<AgentMcpView[]>;
    cancelAuthorization(input: unknown): Promise<AgentMcpView[]>;
    dispose(): Promise<void>;
    private requireAgent;
    private find;
    private associated;
    private runtimeId;
    private prefix;
    private permits;
    private syncing;
    private syncMasks;
    private write;
    private persist;
}
