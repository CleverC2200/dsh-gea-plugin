/** 文件作用：提供用户技能、命令和 Agent 人格面板的持久化及技能投影。 */
/**
 * User panel storage: the persistence layer behind the skills / commands /
 * agent-personas panels. Each surface owns one directory of Markdown files
 * under `<userRoot>/user/<kind>/`, so user-authored entries survive restarts,
 * are trivially hand-editable, and stay outside suite checkouts.
 *
 * Skills entries follow the SKILL.md frontmatter grammar (`name`,
 * `description`, optional `whenToUse`, invocation controls) plus a
 * `disabled: true` panel control; commands follow Claude Code command
 * frontmatter (`description`, optional `argument-hint`, `disabled`); agent
 * personas follow Claude Code agents frontmatter (`name`, `description`,
 * optional `whenToUse`, `tools`, `model`, `disabled`).
 * @module runtime/user-panels
 */
import type { SkillCandidate, SkillDefinition, SkillLookupOptions, SkillProvider } from '@deepseek-ai/dsh-skill';
import type { HostTranslate } from './host-locale.js';
/** The skill-source label user-panel entries carry into the skill registry. */
export declare const USER_PANEL_SKILL_SOURCE = "user-panel";
/** A user panel entry as the HTTP layer serializes it. */
export interface UserPanelEntry {
    /** Entry identity: the file's base name. */
    name: string;
    description: string;
    /** True when the entry is disabled through its `disabled` frontmatter key. */
    disabled: boolean;
    /** The parsed frontmatter record (name, description, hint, tools, model, …). */
    metadata: Record<string, unknown>;
    /** Absolute file path. */
    path: string;
    /** The body after frontmatter removal. */
    content: string;
    rawText: string;
    origin: 'user';
}
/** Throwing CRUD over one panel directory, shared by the three panels. */
export declare class UserPanelStore {
    private readonly dataRoot;
    private readonly kind;
    /** Extra name grammar for this panel (runs after USER_ENTRY_NAME). */
    private readonly extraNameCheck;
    /** 绑定数据根、面板类型和翻译器，形成一个面板独立存储边界。 */
    constructor(dataRoot: string, kind: 'skills' | 'commands' | 'agents', 
    /** Extra name grammar for this panel (runs after USER_ENTRY_NAME). */
    extraNameCheck?: (name: string) => boolean);
    /** The panel's directory under the data root. */
    /** 返回当前面板目录路径，供路由和测试展示。 */
    dirPath(): string;
    /** The plugin data root the panel lives under. */
    /** 返回面板所属用户根目录。 */
    root(): string;
    /** 返回当前面板对应的目录；所有读写都通过该受控路径进行。 */
    private get dir();
    /** Every entry, sorted by name; strict snapshots propagate temporary I/O failures. */
    /** 列出面板条目并映射为 HTTP 层模型；strict 控制坏文件是否抛错。 */
    list(strict?: boolean, metadataOnly?: boolean): Promise<UserPanelEntry[]>;
    /** One entry's full record, including the raw file text. */
    /** 按合法名称读取单个面板条目，不存在时返回 undefined。 */
    get(name: string): Promise<UserPanelEntry | undefined>;
    /**
     * Project one parsed file onto the wire shape. The description prefers the
     * strict frontmatter parse (multi-line YAML like `description: |` survives
     * intact there) and falls back to the shallow line record.
     */
    /** 将存储层条目转换为前端可用的统一面板模型。 */
    private serialize;
    /** Create an entry; refuses an occupied name. */
    /** 校验并创建新条目，拒绝重名和非法 Markdown frontmatter。 */
    create(name: string, text: string): Promise<UserPanelEntry>;
    /** Replace one entry's file content wholesale. */
    /** 校验并覆盖既有条目，保持文件名作为稳定身份。 */
    update(name: string, text: string): Promise<void>;
    /** Delete one entry; a missing file is a no-op (idempotent delete). */
    /** 删除指定面板条目；名称先过统一格式校验。 */
    remove(name: string): Promise<void>;
}
/** Locate the three stores; constructed once per plugin activation. */
/** 为三类用户面板创建共享数据根下的独立 Store。 */
export declare function createUserPanelStores(dataRoot: string): {
    skills: UserPanelStore;
    commands: UserPanelStore;
    agents: UserPanelStore;
};
/**
 * The skills/agents panels accept only harness skill-grammar names
 * (`[a-z0-9-]`, no underscores): a candidate name reaching the skill
 * registry's `get()` with an invalid name is dropped there, and several
 * consumers validate strictly, so `_`-named entries would be dead weight.
 * Commands keep the looser command grammar (`_` allowed).
 */
/** 判断候选技能名是否属于用户面板命名空间。 */
export declare function isUserSkillEntryName(name: string): boolean;
/**
 * Skill provider over user skills only. Agent definitions belong to the
 * subagent catalog and never become skill candidates or slash entries.
 */
export declare class UserPanelSkillProvider implements SkillProvider {
    private readonly skills;
    private readonly t;
    readonly name = "user-panel";
    /** 保存技能面板 Store，用于候选发现和正文加载。 */
    constructor(skills: UserPanelStore, t: HostTranslate);
    /** 列出启用的用户技能条目并转换为宿主候选。 */
    list(_options: SkillLookupOptions): Promise<SkillCandidate[]>;
    /** 根据候选名称读取用户技能并生成宿主定义，缺失时返回 undefined。 */
    get(candidate: SkillCandidate, _options: SkillLookupOptions): Promise<SkillDefinition | undefined>;
}
