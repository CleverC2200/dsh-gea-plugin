import type { Context } from '@deepseek-ai/cordis';
import { type SubagentCatalogEntry } from './subagent-catalog.js';
import { type HostTranslate } from './host-locale.js';
type JsonValue = string | number | boolean | null | JsonValue[] | {
    [key: string]: JsonValue;
};
export declare const AGENT_ROLE_TOOL_NAME = "subagents_run";
/** Panel identity is preserved so identically named cards from different suites remain addressable. */
export interface AgentRoleEntry {
    name: string;
    path: string;
    description: string;
    disabled: boolean;
    title?: string;
    rawText?: string;
}
export interface AgentRolePolicy {
    content: string;
    model?: string;
    provider?: string;
    reasoningEffort?: string;
    title?: string;
    description?: string;
    tools?: string[];
    disallowedTools?: string[];
    disabled: boolean;
}
/** Strict YAML parsing prevents malformed routing/restriction metadata from silently inheriting wider privileges. */
/** 解析角色 Markdown 的 frontmatter 与正文，输出执行策略而不执行外部副作用。 */
export declare function parseAgentRole(text: string): AgentRolePolicy;
interface ModelCatalog {
    /** 中文：列出当前可用的模型提供商标识。 */
    listProviders(): {
        id: string;
    }[];
    /** 中文：按提供商查询模型列表，返回模型标识。 */
    listModels(provider: string): Promise<{
        id: string;
    }[]>;
    resolveCallConfig(config: {
        provider: string;
        model: string;
        reasoningEffort?: string;
    }, signal?: AbortSignal): Promise<unknown>;
}
/** Bare ids must resolve uniquely; Claude aliases are accepted only if actually advertised by a DSH provider. */
/** 校验角色指定的 provider/model，并解析宿主实际调用配置。 */
export declare function resolveAgentModel(policy: AgentRolePolicy, catalog: ModelCatalog): Promise<{
    provider?: string;
    model?: string;
}>;
export interface AgentRoleRequest {
    label: string;
    prompt: {
        type: 'text';
        text: string;
    }[];
    parent: unknown;
    signal: AbortSignal;
    maxDepth: number;
    agentOptions: {
        provider?: string;
        model?: string;
        reasoningEffort?: string;
    };
    persona: string;
    toolFilter?: {
        allow?: string[];
        deny?: string[];
    };
}
export interface AgentRoleHost {
    tools: {
        register(definition: unknown): () => void;
    };
    llm: ModelCatalog;
    subagents: {
        start(provider: string, request: AgentRoleRequest): Promise<{
            id: string;
            result: Promise<{
                stopReason: string;
                output: JsonValue[];
            }>;
            /** 中文：释放一次角色执行对应的子 Agent 资源。 */
            dispose(): void | Promise<void>;
        }>;
    };
}
/** Read the same declaration for catalog summaries and execution, including inline resources. */
/** 读取一个角色文件并解析策略；路径来自已发现目录，输出可执行角色定义。 */
export declare function readAgentRole(entry: AgentRoleEntry): Promise<AgentRolePolicy>;
/** Stable summaries; invalid declarations are excluded and transient read failures abort publication. */
/** 并发解析角色条目，去重并报告单项错误；AbortSignal 控制目录刷新生命周期。 */
export declare function agentRoleCatalog(entries: AgentRoleEntry[], signal: AbortSignal, diagnose?: (message: string) => void): Promise<SubagentCatalogEntry[]>;
/** Resolve fresh panel state and raw Markdown on every call, including after edits, disabling and uninstall. */
/** 解析角色模型并启动子 Agent，返回宿主执行句柄的 Promise。 */
export declare function executeAgentRole(host: AgentRoleHost, listRoles: (parent?: unknown) => Promise<AgentRoleEntry[]>, name: string, prompt: string, parent: unknown, signal: AbortSignal): Promise<{
    runId: string;
    output: JsonValue[];
}>;
/** Mount once after tools, llm and subagents are available; the returned disposer belongs to the plugin lifecycle. */
/** 注册 subagents_run 工具，串接角色发现、模型解析、执行和释放。 */
export declare function mountAgentRoleTool(ctx: Context, listRoles: (parent?: unknown) => Promise<AgentRoleEntry[]>, t?: HostTranslate): () => void;
export {};
