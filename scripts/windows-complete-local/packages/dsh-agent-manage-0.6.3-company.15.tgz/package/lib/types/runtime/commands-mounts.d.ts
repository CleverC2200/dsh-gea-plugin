/** 文件作用：把启用套件里的命令 Markdown 挂载为宿主斜杠命令，并负责增量对账。 */
/**
 * Claude Code command compatibility: `commands/*.md` of enabled suites
 * register as dsh slash commands.
 *
 * A CC command is a prompt template the model executes (its body carries
 * `$ARGUMENTS` and execution rules), so the handler maps it onto the
 * harness's follow-up mechanism: the template with `$ARGUMENTS` substituted
 * becomes one durable user-role follow-up message on the receiving agent.
 * Registrations reconcile on every enable/disable/install/uninstall; a
 * broken command file or an unavailable `ctx.commands` is contained per
 * command and reported as a diagnostic.
 */
import type { Context } from '@deepseek-ai/cordis';
import type { Suite, SuiteMarkdownResource } from '../model/types.js';
import { type HostTranslate } from './host-locale.js';
export interface CommandMountDiagnostic {
    suiteId: string;
    command: string;
    reason: string;
}
interface CommandSpec {
    name: string;
    description: string;
    body: string;
    hint?: string;
}
export declare class CommandMountRegistry {
    private readonly ctx;
    private readonly t;
    private readonly fingerprints;
    private readonly live;
    /** 绑定宿主命令面和翻译器，后续 reconcile 在此上下文注册命令。 */
    constructor(ctx: Context, t?: HostTranslate);
    /** Register/unregister suite commands to match the enabled suites exactly. */
    /** 对账启用套件命令：卸载失效项，逐项读取并注册，单项失败转为诊断。 */
    reconcile(enabledSuites: Suite[]): Promise<CommandMountDiagnostic[]>;
    /** Dispose every registered command; used at plugin teardown. */
    /** 释放全部活动命令注册，供禁用插件或宿主销毁时调用。 */
    disposeAll(): void;
}
/** Parse `commands/*.md` of one suite root (Claude Code format). */
/** 读取套件命令资源，校验命名/frontmatter，并返回可注册的命令规格。 */
export declare function readCommands(root: string, resources?: SuiteMarkdownResource[]): Promise<CommandSpec[]>;
export {};
