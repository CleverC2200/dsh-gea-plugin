import type { Context } from '@deepseek-ai/cordis';
import type { UserAgents } from './user-agents.js';
/** Authenticated Host Fetch routes share the same complete configuration module as publication. */
export declare function mountUserAgentRoutes(host: Pick<Context, 'connection' | 'effect'>, agents: UserAgents): void;
