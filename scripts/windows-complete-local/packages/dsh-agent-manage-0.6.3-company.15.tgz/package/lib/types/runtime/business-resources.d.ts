import type { UserAgentSkill, UserAgentView } from '../contracts/user-agents.js';
import type { Context } from '@deepseek-ai/cordis';
import type { SkillLookupOptions } from '@deepseek-ai/dsh-skill';
export interface ExecutionProfile {
    label: string;
    consumerCode: string;
    skills: string[];
    crossConsumers?: string[];
}
export interface BusinessResourceDefinition {
    id: string;
    label: string;
    /** Agent catalog metadata; the business page keeps its separate title. */
    presetName?: string;
    description?: string;
    root: string;
    prompt?: string;
    /** Publish a validated preset when the enabled package registers, without selecting it or changing user defaults. */
    publishPreset?: boolean;
    /** Owning capability declaration, for explicit references to existing analysis Skills. */
    capability?: string;
    /** A policy JSON file may contain several original profiles. */
    profileKey?: string;
    profile: ExecutionProfile;
    /** Host-verified GEA Cube capability. Never populated from user/source imports. */
    cube?: boolean;
    skillFiles?: Record<string, string>;
    enabled?: boolean;
    /** Existing scoped resource-reference plugin, when required by this resource. */
    plugins?: Array<{
        id: string;
        name: string;
    }>;
}
export interface ResourceSummary {
    id: string;
    label: string;
    description?: string;
    kind: 'prompt' | 'skill';
    installed: boolean;
    enabled: boolean;
    provider: string;
    skills?: string[];
    /** Validated selected page choices; labels come from the corresponding resource summaries. */
    interpreters?: readonly string[];
    missingSkills?: string[];
    error?: string;
}
export interface ResourceSelection {
    id: string;
    preset: string;
    skill?: string;
    profile?: ExecutionProfile;
    interpreters?: readonly string[];
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        agentResources: BusinessResources;
    }
}
export declare class BusinessResources {
    private readonly ctx;
    private readonly indexFile;
    private readonly listeners;
    private readonly customizations;
    private readonly cubeDisabled;
    private readonly entries;
    private readonly mounted;
    private readonly versions;
    private readonly selected;
    private control?;
    private unregisterProvider;
    private closed;
    private readonly lifetime;
    private pending;
    constructor(ctx: Pick<Context, 'skills' | 'agentPresets'>, indexFile: string);
    load(): Promise<void>;
    /** Called by a live installed plugin owner, never by an HTTP-provided directory. */
    register(definitions: readonly BusinessResourceDefinition[]): Promise<() => Promise<void>>;
    /** Host-only projection; owner identity and Consumer never cross the UI interface. */
    cubeSource(id: string): {
        sourceRef: string;
        consumerCode: string;
        signal: AbortSignal;
    } | undefined;
    cubeCatalog(): Array<{
        sourceRef: string;
        name: string;
        enabled: boolean;
        available: boolean;
    }>;
    watch(listener: () => void): () => void;
    private fail;
    private changed;
    /** Plugin MCP membership is fixed; the only supported mutation is enabling it. */
    setCubeEnabled(id: string, enabled: boolean): Promise<void>;
    /** Explicit copy contains only original instructions and permitted resource references. */
    copyable(id: string): Promise<{
        name: string;
        description: string;
        prompt: string;
        skills: UserAgentSkill[];
        cube?: {
            sourceRef: string;
            enabled: boolean;
        };
    }>;
    /** All trusted prompt declarations, including non-Cube Agents, use their original preset identity. */
    pluginAgents(): Promise<UserAgentView[]>;
    pluginAgent(id: string): Promise<UserAgentView>;
    savePlugin(input: unknown): Promise<UserAgentView>;
    setPluginEnabled(id: string, enabled: boolean): Promise<UserAgentView>;
    private updatePlugin;
    /** Only a selected, validated original profile can contribute extra page interpreters. */
    interpreters(id: string): readonly string[];
    list(options?: SkillLookupOptions): Promise<ResourceSummary[]>;
    select(id: string, signal: AbortSignal, cwd?: string): Promise<ResourceSelection>;
    private persist;
    private serialize;
    private mountSkillPreset;
    private originalProfile;
    private mountPrompt;
    private skillCandidates;
    private skillBody;
    /** Retain the disposer and resource owner until Core confirms release. */
    private unmount;
    dispose(): Promise<void>;
}
