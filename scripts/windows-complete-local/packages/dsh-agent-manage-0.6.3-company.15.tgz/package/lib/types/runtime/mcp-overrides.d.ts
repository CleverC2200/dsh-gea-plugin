import type { McpServerSse, McpServerStreamableHttp, McpServerStdio } from '../model/types.js';
/** HTTP-shaped server sources (url + headers carriers) overrides can edit. */
type McpServerHttp = McpServerStreamableHttp | McpServerSse;
/** Per-server override record; absent fields pass through from the source. */
export type McpServerOverride = {
    /** Validated complete user configuration, retaining source-owned identity. */
    config?: McpServerStdio | McpServerHttp;
    /** Disabled servers are not mounted at all (default enabled). */
    enabled?: boolean;
    /** Replaces the source URL (streamable-http only). */
    url?: string;
    /** Replaces the whole header map (streamable-http only). */
    headers?: Record<string, string>;
    /** Replaces the whole env map (stdio). */
    env?: Record<string, string>;
    /** Replaces the whole args list (stdio). */
    args?: string[];
    /** Replaces the OAuth block (streamable-http only); `enabled: false` disables a source-declared flow. */
    auth?: {
        enabled: boolean;
        scope?: string;
    };
};
/** Overrides for one suite, keyed by mcp.json server key. */
export type McpSuiteOverrides = Record<string, McpServerOverride>;
/** Retired plugin connection edits stay on disk for recovery; only enablement remains effective.
 * User connection definitions still accept their validated, Agent-owned configuration.
 */
export declare function effectiveSuiteOverrides(suiteId: string, stored: McpSuiteOverrides): McpSuiteOverrides;
/** The overrides directory under the plugin data root. */
/** 返回 MCP 覆盖配置目录路径。 */
export declare function overridesDir(dataRoot: string): string;
/** One suite's override file path. */
/** 返回某个套件覆盖文件路径，并对套件 ID 做文件名清洗。 */
export declare function suiteOverridePath(dataRoot: string, suiteId: string): string;
/** Load one suite's persisted overrides; unreadable files yield none. */
/** 读取单套件覆盖并清洗未知字段；缺失文件返回空对象。 */
export declare function loadSuiteOverrides(dataRoot: string, suiteId: string): Promise<McpSuiteOverrides>;
/** Persist one suite's overrides atomically-ish (single writer, small file). */
/** 清洗并持久化单套件覆盖，确保敏感字面量不进入文件。 */
export declare function saveSuiteOverrides(dataRoot: string, suiteId: string, overrides: McpSuiteOverrides): Promise<void>;
/** Keep only recognized fields with correct shapes; drop everything else. */
/** 将任意输入收窄为服务器键到覆盖记录的安全映射。 */
export declare function sanitizeOverrides(raw: unknown): McpSuiteOverrides;
/** Validate a client-supplied patch for one server into an override value. */
/** 校验单个覆盖补丁并拒绝敏感字面量或未知结构。 */
export declare function sanitizeOverridePatch(patch: unknown): McpServerOverride | undefined;
/**
 * Merge one client patch into the override already on disk.
 *
 * The UI redacts secret-shaped values before rendering them, so a patch built
 * from that redacted view must not be written verbatim — that would silently
 * drop keys the user did not intend to change. Existing stored values are
 * therefore preserved and only the fields the patch actually carries replace
 * them.
 */
/** 将局部补丁合并进已有覆盖，保持未修改字段继承。 */
export declare function mergeOverridePatch(existing: McpServerOverride, patch: McpServerOverride): McpServerOverride;
/**
 * Apply one server's overrides onto its source shape. Field replacement is
 * whole-map (headers/env/args), never per-key merge, so removing a key in the
 * UI actually removes it at mount time. Values pass through the ordinary
 * mount-time placeholder pipeline afterwards, so override authors may
 * reference secrets as `${NAME}` or `${NAME:-fallback}` (resolved through the
 * Host credentials service or launch environment in memory) instead of
 * persisting them here.
 */
/** 将完整 config 或局部字段覆盖应用到源服务，保持传输类型不变。 */
export declare function applyOverride(server: McpServerStdio | McpServerHttp, override: McpServerOverride | undefined): McpServerStdio | McpServerHttp;
export {};
