/** Host runtime dictionary keys (mirrored for zh and en). */
export type HostLocaleKey = 'subagentCatalogIntro' | 'subagentCatalogUpdated' | 'subagentCatalogEmpty' | 'subagentCatalogCall' | 'subagentCatalogInherit' | 'subagentCatalogDefaultEffort' | 'commandForwardTitle' | 'commandAcknowledged' | 'userCommandSourceLabel' | 'userCommandForwardTitle' | 'userCommandAcknowledged' | 'userSkillDescription' | 'feedbackToolCardTitle';
export type HostTranslate = (key: HostLocaleKey, params?: Record<string, string>) => string;
interface ResolvedLocale {
    t: HostTranslate;
}
/** Resolve the active host language from settings; unknown values default to zh. */
/** 将语言偏好绑定为翻译函数；未知偏好回退中文并保留参数插值。 */
export declare function bindHostLocale(preference: string | undefined): HostTranslate;
/** Read `locale.preference` from `$DSH_HOME/settings.yaml` (best effort). */
/** 从宿主 settings.yaml 读取 locale.preference，文件不可读时返回 undefined。 */
export declare function readLocalePreference(): Promise<string | undefined>;
/** Bind a host translator against the persisted locale preference. */
/** 读取并解析宿主语言，返回可直接调用的翻译函数。 */
export declare function loadHostLocale(): Promise<ResolvedLocale>;
export {};
