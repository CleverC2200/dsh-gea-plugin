/** 文件作用：提供用户面板 Markdown 条目的目录、解析、读写和删除基础能力。 */
/**
 * Shared persistence primitives for the market's user-authored panels:
 * skills, commands, and agent personas. Each panel owns one directory of
 * Markdown files under the plugin data root, parsed with the same frontmatter
 * rules the catalog uses, so user entries look exactly like suite entries to
 * the runtime mounts.
 * @module runtime/user-store
 */
/** Where user panel entries persist: `<userRoot>/user/<kind>/`. */
/** 按数据根和面板类型计算用户条目目录，隔离 skills/commands/agents。 */
export declare function userEntryDir(dataRoot: string, kind: 'skills' | 'commands' | 'agents'): string;
/** `[a-z][a-z0-9_-]*` — the grammar every panel entry name must satisfy. */
export declare const USER_ENTRY_NAME: RegExp;
/** The enablement frontmatter key shared by skills and commands. */
export declare const DISABLED_KEY = "disabled";
/** Parse full YAML metadata without flattening arrays, mappings, or multiline strings. */
/** 解析完整 YAML 元数据并保持数组、映射及多行字符串的结构。 */
export declare function parseFrontmatterRecord(text: string): Record<string, unknown>;
/** Read one entry; strict runtime snapshots throw on I/O errors other than a vanished file. */
/** 读取并解析单个用户 Markdown 条目；strict 决定坏 frontmatter 是抛错还是跳过。 */
export declare function readEntryFile(file: string, fallbackName: string, strict?: boolean, metadataOnly?: boolean): Promise<UserEntryFile | undefined>;
/** One parsed Markdown panel entry. */
export interface UserEntryFile {
    /** The file's base name (the entry identity). */
    fallbackName: string;
    /** The frontmatter name when valid, else the fallback. */
    name: string;
    /** Absolute file path. */
    file: string;
    /** The raw file text, frontmatter included. */
    text: string;
    /** The body after frontmatter removal. */
    body: string;
    /** The shallow frontmatter record (description, hint, disabled, …). */
    meta: Record<string, unknown>;
    /** Additional fields when the entry carried valid skill frontmatter. */
    whenToUse?: string;
    /** The strict-parse description when the frontmatter was valid YAML. */
    description?: string;
    invocation?: {
        modelInvocable: boolean;
        userInvocable: boolean;
    };
}
/** List `.md` entries; strict runtime snapshots propagate I/O errors instead of publishing partial inventories. */
/** 扫描目录内 Markdown 条目并稳定排序，坏文件按 strict 策略处理。 */
export declare function listEntryFiles(dir: string, strict?: boolean, metadataOnly?: boolean): Promise<UserEntryFile[]>;
/** Write one panel entry; the name becomes `<name>.md`. */
/** 校验名称和 frontmatter 后写入用户条目文件。 */
export declare function writeEntryFile(dir: string, name: string, text: string): Promise<void>;
/** Delete one panel entry file; missing files resolve silently. */
/** 删除一个已校验名称对应的用户条目文件。 */
export declare function deleteEntryFile(dir: string, name: string): Promise<void>;
/** Whether an entry file with that name already exists. */
/** 检查条目文件是否存在且为普通文件。 */
export declare function entryExists(dir: string, name: string): Promise<boolean>;
/** Serialize a frontmatter block from a shallow record (deterministic key order). */
/** 将元数据稳定序列化为 frontmatter，供编辑回显和文件写入复用。 */
export declare function serializeFrontmatter(meta: Record<string, unknown>): string;
