/** 文件作用：对账套件 MCP 挂载，维护后端切换、重试、冲突和工具所有权。 */
/**
 * Runtime MCP mounts: one live self-built bridge child plugin per enabled
 * suite's mcp.json server, mounted through `ctx.plugin`.
 *
 * Mounts reconcile against the enabled-suite set: reconcile() unmounts rows
 * whose suite was disabled or removed and mounts rows that appeared. A
 * duplicate derived serverName or a load failure is contained per server — a
 * broken third-party suite must not take the host down — and reported through
 * the manager's diagnostic list.
 */
import type { Context } from '@deepseek-ai/cordis';
import type { McpBackend } from './mcp-backend.js';
import { type McpSuiteOverrides } from './mcp-overrides.js';
import { type McpMountFailureCode } from './mcp-config.js';
import type { Suite } from '../model/types.js';
export interface McpMountDiagnostic {
    suiteId: string;
    serverKey: string;
    reason: string;
    code?: McpMountFailureCode;
    credentialRefs?: string[];
}
export declare class McpMountRegistry {
    private readonly ctx;
    private readonly pluginDataRoot;
    private readonly namespace?;
    private readonly live;
    private readonly names;
    private readonly credentialRefs;
    private overridesProvider;
    /** Live model-facing tool names, for foreign-namespace detection before a mount. */
    /** 中文：保存宿主当前工具名，用于挂载前识别外部占用的命名空间。 */
    private toolNamesProvider;
    /** The active MCP mount backend ('builtin' bridge or host client compat mode). */
    /** 中文：记录当前 builtin/host 后端，后端切换会促使服务重挂载。 */
    private backendProvider;
    /** Serialize mount and unmount passes so a disable cannot race an in-flight spawn. */
    /** 中文：串行化增删，避免禁用操作与正在启动的子进程竞态。 */
    private reconcileQueue;
    /** Pending retry timers keyed by mount key, so a teardown can cancel them. */
    /** 中文：按挂载键保存待定定时器，释放时可准确取消。 */
    private readonly retries;
    /** Attempt count per mount key; reset whenever a retry succeeds. */
    /** 中文：记录每个服务的连续失败次数，成功或显式不重试时清零。 */
    private readonly attempts;
    /**
     * Mount keys flagged for an explicit rebuild (re-authorize): the next
     * reconcile must tear down and remount them even when the resolved config
     * fingerprint is unchanged — dropping a grant changes no config field.
     */
    private readonly forcedRemounts;
    /** Snapshot of the last reconciled suite set, replayed by retry passes. */
    /** 中文：重试只重放最近快照，避免恢复已卸载或已禁用的服务。 */
    private lastEnabled;
    /** 绑定宿主上下文、数据根和翻译器，初始化 MCP 对账状态。 */
    constructor(ctx: Context, pluginDataRoot: string, namespace?: string | undefined);
    /** Install the per-suite overrides provider (suiteId -> overrides). */
    /** 注入覆盖配置读取器，使编辑后的服务能在下一次对账生效。 */
    setOverridesProvider(provider: () => Promise<Map<string, McpSuiteOverrides>>): void;
    /**
     * Install the live model-facing tool-name provider (the host registry
     * snapshot) used to detect foreign `mcp__<serverName>__` namespaces before
     * a mount is attempted.
     */
    /** 注入宿主工具观察器，用于检测外部占用和状态展示。 */
    setToolNamesProvider(provider: () => string[]): void;
    /** Install the backend provider deciding which client mounts each server. */
    /** 注入后端选择器，支持 builtin/host 切换触发重挂载。 */
    setBackendProvider(provider: () => Promise<McpBackend>): void;
    /** Whether the last catalog snapshot uses one credential reference. */
    /** 判断当前活动配置是否引用某凭据，供凭据变更精确触发刷新。 */
    usesCredential(ref: string): boolean;
    /**
     * Flag one mount for an explicit rebuild on the next reconcile: used by
     * re-authorize, which deletes a grant without changing any resolved config
     * field, so a fingerprint-only reconcile would keep the live bridge (and
     * its in-memory tokens) untouched.
     */
    /** 标记单个服务需重挂载，下一次对账会绕过指纹短路。 */
    forceRemount(suiteId: string, serverKey: string): void;
    /** The mount key owning one derived serverName; undefined when not mounted here. */
    /** 根据公开 serverName 反查套件和服务键，供工具路由和诊断使用。 */
    serverOwner(serverName: string): {
        suiteId: string;
        serverKey: string;
    } | undefined;
    /** Queue one reconciliation behind any in-flight mount/unmount pass. */
    /** 串行执行 MCP 对账，容纳上一轮失败后继续处理新的快照。 */
    reconcile(enabledSuites: Suite[]): Promise<McpMountDiagnostic[]>;
    /** Mount/unmount MCP servers to match the enabled suites exactly. */
    /** 计算期望请求、处理后端和覆盖配置，再增删 MCP 挂载并收集诊断。 */
    private reconcileNow;
    /**
     * Schedule a delayed re-attempt for a mount that still is not live.
     *
     * Mounts are retried because a remote endpoint or a credential may become
     * available slightly after the suite is enabled. The schedule is bounded, and
     * a server that keeps failing simply stops retrying until the next reconcile.
     */
    /** 为可恢复失败安排有界退避重试，确定性配置错误不无限重试。 */
    private scheduleRetry;
    /** Dispose every live mount after queued reconciliation passes settle. */
    /** 取消待定重试并释放所有 MCP 客户端插件。 */
    disposeAll(): Promise<void>;
    /** Mount one precomputed request (source config merged with overrides). */
    /** 挂载单个 MCP 请求，后端不可用或工具命名冲突时返回结构化失败。 */
    private mountWith;
    /** 释放单个 MCP 挂载并清理所有权索引，返回释放错误供诊断。 */
    private unmount;
}
