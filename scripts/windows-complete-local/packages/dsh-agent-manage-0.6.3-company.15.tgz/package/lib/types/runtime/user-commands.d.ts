/** 文件作用：把用户命令面板条目挂载为宿主斜杠命令并按目录变化对账。 */
/**
 * User command mounting: every enabled entry of the user commands panel
 * registers as a dsh slash command, so user-authored quick replies behave
 * exactly like suite commands — the body with `$ARGUMENTS` substituted rides
 * one follow-up message on the receiving agent. Reconciled on every catalog
 * change, keyed `user/<name>`.
 * @module runtime/user-commands
 */
import type { Context } from '@deepseek-ai/cordis';
import type { HostTranslate } from './host-locale.js';
import type { UserPanelStore } from './user-panels.js';
/** Register/unregister user-panel commands to match the panel's enabled entries. */
export declare class UserCommandMountRegistry {
    private readonly ctx;
    private readonly store;
    private readonly t;
    private readonly fingerprints;
    private readonly live;
    /** 保存用户面板和宿主命令服务，后续对账从面板读取当前条目。 */
    /** 绑定用户命令面板和宿主命令服务，建立用户命令生命周期边界。 */
    constructor(ctx: Context, store: UserPanelStore, t: HostTranslate);
    /** Sync the live registrations with the panel's enabled entries. */
    /** 对账用户命令：移除删除/禁用项，注册新增项并返回诊断名称。 */
    reconcile(): Promise<string[]>;
    /** Dispose every registration (plugin teardown). */
    /** 释放所有用户命令注册，供面板卸载或宿主销毁调用。 */
    disposeAll(): void;
}
