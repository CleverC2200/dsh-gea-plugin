/** 文件作用：把 LSP 声明、挂载诊断和直接配置汇总成前端状态。 */
/**
 * LSP status aggregation: declared language servers of enabled+installed
 * suites and the user's direct configuration, merged with the mount
 * registry's latest diagnostics into rows for the status surface.
 *
 * The DSH `ctx.lsp` seam exposes no provider snapshot and no process probe,
 * so a row's state is a declaration-and-diagnostic judgment: a suite whose
 * mount succeeded yields `mounted` (the seam guarantees registration), a
 * stored diagnostic yields its own state, and a declaration with neither
 * mounts nor diagnostics means the host packages are absent (`host-missing`).
 * Direct user-configured rows follow the same model under the sentinel suite
 * id `direct` (mirroring mcp-status's `plugin`/`direct` split).
 */
import type { LspStatusPayload } from '../contracts/lsp-status.js';
import type { LspMountDiagnostic } from './lsp-mounts.js';
import type { LspServerSpec, Suite } from '../model/types.js';
/** Sentinel suite id for user-configured (non-suite) LSP servers. */
export declare const DIRECT_LSP_SUITE_ID = "direct";
/** The subset of LspMountRegistry the aggregator consumes (structural, for tests). */
export interface LspMountStatusSource {
    diagnosticsSnapshot(): Map<string, LspMountDiagnostic>;
    hasLiveMounts(): boolean;
    disabledServers?(): Set<string>;
}
/** The direct servers table the aggregator merges in (structural, for tests). */
export interface LspDirectServersSource {
    servers: Record<string, LspServerSpec>;
    errors: string[];
}
/** Build the status payload from declarations, direct configuration, and mount diagnostics. */
/** 汇总套件与 direct LSP 条目，输出状态行和统计计数，供管理界面展示。 */
export declare function buildLspStatus(suites: readonly Suite[], registry: LspMountStatusSource, direct?: LspDirectServersSource): LspStatusPayload;
