/** Resolve MCP `${NAME}` placeholders through the optional DSH credentials seam. */
/** 文件作用：把宿主凭据服务适配为 MCP 占位符解析器，并保留环境变量回退。 */
import type { Context } from '@deepseek-ai/cordis';
import type { McpCredentialResolver } from './mcp-config.js';
/**
 * Build the resolver used at mount time. Standard DSH profiles provide
 * `ctx.credentials`; minimal profiles retain the historical process-env
 * fallback so MCP mounting remains backwards compatible.
 */
/** 创建 MCP 凭据解析器：优先宿主 credentials，缺失时回退进程环境变量。 */
export declare function mcpCredentialResolver(ctx: Context): McpCredentialResolver;
