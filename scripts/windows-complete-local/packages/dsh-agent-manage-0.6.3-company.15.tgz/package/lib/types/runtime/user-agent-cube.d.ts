import type { Context } from '@deepseek-ai/cordis';
import type { UserAgents } from './user-agents.js';
export interface UserAgentCubeDeclaration {
    id: string;
    sourceRef: string;
    generation: string;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        userAgentCube: UserAgentCubeDeclaration;
        userAgents: UserAgents;
    }
}
/** Core owns this service's isolated revision and inherits it into child Agents. */
export declare function apply(ctx: Context, config: UserAgentCubeDeclaration): void;
