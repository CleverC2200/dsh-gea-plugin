import type { Context } from '@deepseek-ai/cordis';
export { FORECAST_VERSION } from './forecast-source.js';
type RecordValue = Record<string, unknown>;
/** Port of the suite's pure §5.5 calculator; no source verification, prices, network or business writes. */
export declare function computeForecast(data: RecordValue): RecordValue;
export declare function createForecastTool(skills: Context['skills']): import("@deepseek-ai/dsh-tools").ToolDefinition;
