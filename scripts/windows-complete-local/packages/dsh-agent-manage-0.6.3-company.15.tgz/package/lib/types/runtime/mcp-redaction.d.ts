/** 文件作用：在状态、日志和编辑回显边界脱敏 MCP 敏感配置。 */
/** Redact secret-shaped MCP configuration before it crosses a status/detail boundary. */
/** 递归脱敏单份 MCP 配置，保留占位符以便编辑后恢复原凭据。 */
export declare function redactMcpConfig(value: unknown): unknown;
/** 递归脱敏覆盖配置集合，输出仍保持按服务器分组的对象形状。 */
export declare function redactMcpOverrides(value: Record<string, Record<string, unknown>>): Record<string, Record<string, unknown>>;
/** Whether one map key is treated as secret-shaped. */
/** 判断键名是否具有凭据语义，供配置、参数和 URL 脱敏共用。 */
export declare function isSensitiveKey(key: string): boolean;
/** Redact credential-bearing query values from an endpoint URL. */
/** 仅遮蔽 URL 查询参数中的敏感值，保留可诊断的主机和非敏感参数。 */
export declare function redactUrl(raw: string): string;
