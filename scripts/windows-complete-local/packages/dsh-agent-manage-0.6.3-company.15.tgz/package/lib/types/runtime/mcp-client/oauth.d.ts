/** 文件作用：处理 MCP OAuth 授权回调、PKCE、凭据持久化及授权失败。 */
/**
 * OAuth 2.1 authorization-code support for Streamable HTTP (and legacy SSE)
 * MCP servers that answer `401` with an OAuth challenge (`WWW-Authenticate:
 * Bearer resource_metadata="…"` — the MCP authorization spec's discovery
 * anchor).
 *
 * The SDK owns the protocol: its `auth()` helper performs RFC 9728 protected-
 * resource discovery, authorization-server metadata lookup, RFC 7591 dynamic
 * client registration, PKCE, token exchange, and refresh, and the HTTP
 * transports invoke it on the first `401` through the
 * {@link OAuthClientProvider} this module implements. This module owns the two
 * parts the SDK leaves to the application: durable storage of client and token
 * state, and the human leg of the flow — a loopback redirect that captures
 * the authorization code without caller-side wiring.
 *
 * Tokens and registered client information persist as a `grant` credential
 * record under `mcp-auth/<serverName>` through the harness credentials seam
 * when one is mounted, so they land in the managed `.credentials.yaml`
 * document (mode `0600`, file-locked, refresh-safe across processes) and are
 * visible to the same surface that manages every other credential. Without a
 * credentials service the provider still completes flows in memory; tokens
 * then last exactly as long as the process.
 *
 * Ported from the harness `dsh-mcp-client` OAuth implementation (upstream
 * commits archived at `docs/upstream-proposal/patches/`); the record format is
 * byte-compatible, so grants written by either implementation are interchangeable.
 *
 * @module runtime/mcp-client/oauth
 */
import { type OAuthClientProvider } from '@modelcontextprotocol/sdk/client/auth.js';
import type { OAuthClientInformationMixed, OAuthClientMetadata, OAuthTokens } from '@modelcontextprotocol/sdk/shared/auth.js';
import { type CredentialKey } from './host-seams.js';
import type { OAuthStorageConfig } from './config.js';
/** Credential-record scope for MCP OAuth state; per-server ids follow it. */
export declare const MCP_AUTH_RECORD_SCOPE = "mcp-auth";
/**
 * Address the OAuth grant shared by the provider and reauthorization. Server names carry
 * `__` separators (e.g. `cloudflare__cloudflare-api`), and the key grammar
 * admits only `[a-z0-9-]`, so non-conforming characters collapse to `-` —
 * deterministic, so saving, reading and deleting address the existing record.
 */
/** 保存、读取和重新授权删除共用原有 OAuth 凭据键，不迁移记录。 */
export declare function mcpAuthRecordKey(serverName: string): CredentialKey;
/**
 * Error thrown when the human leg fails or is abandoned: the browser never
 * returned, the callback carried an OAuth error, or no browser could open.
 * The transport surfaces it from `connect`; the supervisor's reconnect loop
 * re-enters the flow — which reopens the browser — on a later attempt.
 */
export declare class AuthorizationAbortedError extends Error {
    /** 创建可识别的用户授权中止错误，供连接监督器保持/结束当前代际。 */
    constructor(message: string, options?: ErrorOptions);
}
export type AuthorizationState = 'idle' | 'awaiting-authorization' | 'authorization-cancelled' | 'authorization-failed';
/** Opens the platform browser; injected in tests to record the URL instead. */
export type BrowserOpener = (authorizationUrl: URL, serverName: string, log: (message: string) => void) => Promise<void>;
/** The real opener: platform browser or default URL handler. */
export declare const platformBrowserOpener: BrowserOpener;
/**
 * {@link OAuthClientProvider} over the harness credentials seam (or process
 * memory when the seam is absent), with a loopback redirect that opens the
 * system browser.
 */
export declare class LoopbackOAuthClientProvider implements OAuthClientProvider {
    private readonly serverName;
    private readonly storage;
    private readonly scope;
    private readonly log;
    private readonly opener;
    private readonly onAuthorizationState;
    private readonly recordKey;
    /** Credential store mounted in this composition; absence means memory-only. */
    private readonly store;
    /** In-memory fallback and cache over the store's durable state. */
    private providerState;
    /** The transport generation whose `finishAuth` completes the browser leg. */
    private activeTransport;
    /** Resolves `true` when the leg saved tokens, `false` when it failed; undefined while no leg is open. */
    private browserLegSettled;
    private abandoned;
    private authState;
    private rejectCallback;
    private callbackServer;
    private callbackTimer;
    private boundPort;
    /** Serializes store writes so a rapid refresh cannot interleave read-modify-writes. */
    private writeChain;
    /** 绑定服务名、凭据服务和日志回调，初始化本地 OAuth 状态容器。 */
    constructor(serverName: string, storage: OAuthStorageConfig, scope: string | undefined, log: (message: string) => void, store: unknown, opener?: BrowserOpener, onAuthorizationState?: (state: AuthorizationState) => void);
    /** 返回当前 loopback 回调地址，供 OAuth 客户端注册和授权请求使用。 */
    get redirectUrl(): string;
    /** 返回符合 MCP OAuth 动态注册要求的客户端元数据。 */
    get clientMetadata(): OAuthClientMetadata;
    /** 未绑定 issuer 的旧记录保留在存储中，但不发送，交给 SDK 重新注册和授权。 */
    clientInformation(): Promise<OAuthClientInformationMixed | undefined>;
    /** 持久化服务端返回的客户端注册信息。 */
    saveClientInformation(clientInformation: OAuthClientInformationMixed): Promise<void>;
    /** 只返回绑定 issuer 的 token，缺少归属时交给 SDK 触发重新授权。 */
    tokens(): Promise<OAuthTokens | undefined>;
    /** 保存新 token，并保留刷新所需的全部字段。 */
    saveTokens(tokens: OAuthTokens): Promise<void>;
    /**
     * Bind the loopback server, open the browser, and complete the code
     * exchange into the bound transport generation. Resolves only after tokens
     * are saved; an OAuth `error` redirect, a timeout, or a listener failure
     * rejects with {@link AuthorizationAbortedError}.
     */
    /** 打开浏览器授权页并等待本地回调完成。 */
    redirectToAuthorization(authorizationUrl: URL): Promise<void>;
    get authorizationState(): AuthorizationState;
    private setAuthorizationState;
    /** Whether a browser leg is open and the code exchange is still pending. */
    /** 标记是否有浏览器授权回调正在等待，供连接监督器保留代际。 */
    get awaitingBrowser(): boolean;
    /**
     * Resolves once the pending browser leg finishes (tokens saved or the leg
     * failed); undefined while no leg is open. The supervisor holds the
     * connection generation — instead of timing out and respawning, which would
     * abandon the leg the user is mid-way through approving — until this
     * settles.
     */
    /** 返回当前浏览器授权阶段的完成 Promise，未授权时为空。 */
    get browserLeg(): Promise<boolean> | undefined;
    /**
     * Register the transport generation whose `finishAuth` completes the flow.
     * The transport calls `redirectToAuthorization` during `connect`; binding
     * it here keeps the code exchange inside the generation that owns the
     * connection, per the SDK's per-connection session model.
     */
    /** 绑定当前 transport，以便回调收到 code 后完成 SDK 授权流程。 */
    bindTransport(transport: {
        finishAuth(code: string): Promise<void>;
    }): void;
    /** Abandon any previously bound browser leg before a new one starts. */
    /** 取消当前回调监听并清理超时，避免旧授权串入新连接。 */
    resetCallback(reason?: Error): void;
    /** 持久化 PKCE verifier，供后续授权交换使用。 */
    saveCodeVerifier(codeVerifier: string): Promise<void>;
    /** 读取当前 PKCE verifier，不存在时拒绝复用旧授权。 */
    codeVerifier(): Promise<string>;
    /** 按范围清理 OAuth 客户端、token、verifier 或发现缓存。 */
    invalidateCredentials(scope: 'all' | 'client' | 'tokens' | 'verifier' | 'discovery'): Promise<void>;
    /** 从凭据服务加载并规范化当前 Provider 状态。 */
    private load;
    /** 串行修改并保存 Provider 状态，避免并发 OAuth 回调覆盖。 */
    private mutate;
    /**
     * Bind a loopback listener, open the browser at `authorizationUrl` (its
     * `redirect_uri` is rewritten to the bound port), and resolve with the code
     * the user agent lands back with.
     */
    /** 启动 loopback HTTP 回调服务器并等待一次性授权 code。 */
    private awaitCallback;
    /** 校验回调参数、返回用户可读页面，并把 code 或 OAuth 错误交给等待方。 */
    private handleCallbackRequest;
    /** 清除 loopback 回调定时器，防止授权结束后仍触发超时。 */
    private clearCallbackTimer;
}
