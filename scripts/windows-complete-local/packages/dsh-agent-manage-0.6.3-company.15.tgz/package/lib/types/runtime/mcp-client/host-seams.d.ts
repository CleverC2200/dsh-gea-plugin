/** 文件作用：封装内置 MCP 客户端访问宿主凭据、附件和环境变量的最小接口。 */
/**
 * Local ports of the tiny host seams the self-built MCP client needs.
 *
 * The market plugin must stay self-contained at runtime: it cannot import
 * host-internal packages that are not published at compatible versions, and
 * every one of these seams is a small pure function or constant. Each port
 * below is copied verbatim (semantics, not prose) from the harness source at
 * `0.1.1-rc.2` and carries the upstream reference it came from, so a future
 * host change can be re-diffed against `~/workspace/deepseek-harness`.
 *
 * Anything larger than a handful of lines (the JSON Schema subset validator)
 * lives in its own module.
 *
 * @module runtime/mcp-client/host-seams
 */
/**
 * The largest delay `setTimeout` accepts without overflowing to a 1ms clamp
 * (2^31 - 1). Shared guard for reconnect and callback timers.
 */
export declare const MAX_TIMER_DELAY_MS = 2147483647;
/** `DSH_*` environment namespace owned by the harness. */
export declare const DSH_ENV_PREFIX: "DSH_";
/**
 * Credential-shaped environment names are NOT forwarded to MCP server child
 * processes (the harness's own `DEEPSEEK_API_KEY`/secrets must not leak into a
 * spawned server implicitly). Deliberately supplied env entries survive
 * because the config's explicit env merges after the scrub.
 */
export declare const SENSITIVE_ENV_PATTERN: RegExp;
/**
 * The ambient parent environment minus credential-shaped names and minus all
 * `DSH_*` names — the canonical base every harness child starts from. `PATH`,
 * `HOME`, locale, and proxy variables survive, so child CLIs run normally;
 * harness identity never leaks implicitly. Both scrubs match case-insensitively:
 * Windows environment names are case-insensitive, so a parent `dsh_*` entry
 * would otherwise survive and read back as `$env:DSH_*` in the child.
 * @returns a fresh environment object safe to hand to a child spawn.
 */
/** 返回剔除敏感父进程变量的子进程环境，避免凭据意外下传。 */
export declare function scrubbedParentEnv(): Record<string, string>;
/** A credential record key: `<scope>/<id>` with both segments in the grammar below. */
declare const credentialKeyBrand: unique symbol;
export type CredentialKey = string & {
    readonly [credentialKeyBrand]: true;
};
/**
 * Brand a scope and an id as a {@link CredentialKey}.
 * @param scope - the owning plugin's registered name (here: the `mcp-auth` record scope).
 * @param id - the plugin's own addressing unit (here: the folded serverName).
 * @returns the branded key.
 * @throws TypeError when either segment is not a lowercase hyphenated identifier.
 */
/** 构造宿主凭据服务使用的稳定作用域/标识键。 */
export declare function credentialKey(scope: string, id: string): CredentialKey;
/**
 * Structural mirror of the host `CredentialProvider` record surface the OAuth
 * provider needs. Typed structurally because the store arrives via the
 * optional `credentials` service; the OAuth provider narrows at runtime and
 * falls back to memory-only state when the service is absent.
 */
export interface CredentialRecordStore {
    describeRecord(key: CredentialKey): Promise<{
        configured: boolean;
        writable: boolean;
    }>;
    readRecord(key: CredentialKey): Promise<unknown>;
    modifyRecord(key: CredentialKey, mutate: (current: unknown) => Promise<unknown>): Promise<unknown>;
}
/**
 * Distinguish caller-correctable image admission failures from storage faults,
 * so an admission refusal projects text diagnostics while a storage fault is
 * reported as such.
 */
/** 判断附件服务错误是否表示当前模型不接收图片，而非连接故障。 */
export declare function isImageAdmissionError(error: unknown): boolean;
/** Raster formats supported by the durable attachment vocabulary. */
export type ImageMediaType = 'image/png' | 'image/jpeg' | 'image/webp' | 'image/gif';
/** One decoded image handed to the host attachment store. */
export interface SaveImageAttachment {
    data: Buffer;
    mediaType: ImageMediaType;
}
/**
 * Structural mirror of the host `AttachmentStore.saveImages` surface. The
 * returned refs are opaque host values that ride inside `ContentBlock`
 * image blocks; typed `unknown` here and narrowed by the model content
 * contract at the projection site.
 */
export interface AttachmentStoreLike {
    saveImages(images: readonly SaveImageAttachment[]): Promise<readonly unknown[]>;
}
export {};
