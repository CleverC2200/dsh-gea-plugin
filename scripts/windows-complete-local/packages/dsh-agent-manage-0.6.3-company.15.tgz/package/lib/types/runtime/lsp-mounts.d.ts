/** 文件作用：将套件 LSP 声明挂载为宿主插件，维护重试、冲突和释放状态。 */
/**
 * Runtime LSP mounts: one live `dsh-lsp-stdio` child plugin per enabled
 * suite's inline `lspServers` table, mounted through `ctx.plugin`.
 *
 * Mounts reconcile against the enabled-suite set exactly like the MCP mounts:
 * reconcile() unmounts rows whose suite was disabled or removed and mounts
 * rows that appeared. The host LSP package is optional at runtime — without
 * it, suites keep every other surface and the manager reports a one-line
 * `host-missing` diagnostic that does not enter the retry schedule (a missing
 * package is not a transient failure). Mount failures that can resolve after
 * user action (installing the language server executable) do retry.
 *
 * Provider identity: one `${suiteId}/${serverKey}` provider id per server, so
 * two suites declaring the same server key mount independently. Extension
 * ownership in `ctx.lsp` is exclusive by design; when two enabled suites
 * claim the same extension the later mount fails with `seam-conflict` and the
 * user resolves it through per-suite surface toggles.
 */
import type { Context } from '@deepseek-ai/cordis';
import type { Suite } from '../model/types.js';
export interface LspMountDiagnostic {
    suiteId: string;
    serverKey: string;
    reason: string;
    code?: 'mount-failed' | 'unmount-failed' | 'seam-conflict' | 'host-missing';
}
/** One dsh-lsp-stdio server configuration row (its Config.servers entry). */
export interface LspStdioServerConfig {
    command: string;
    args: string[];
    extensionToLanguage: Record<string, string>;
    env?: Record<string, string>;
    initializationOptions?: unknown;
    configuration?: unknown;
}
/** Build one dsh-lsp-stdio Config.servers entry from a normalized spec. */
/** 将领域 LSP 声明转换成宿主 stdio 插件所需的命令、参数和扩展配置。 */
export declare function toLspServerConfig(spec: {
    command: string;
    args: string[];
    extensionToLanguage: Record<string, string>;
    env?: Record<string, string>;
    initializationOptions?: unknown;
    configuration?: unknown;
}): LspStdioServerConfig;
/** Minimal structural shape of the dynamically imported `dsh-lsp-stdio` module. */
interface LspStdioModule {
    default?: unknown;
}
export declare class LspMountRegistry {
    private readonly ctx;
    private readonly live;
    /** Serialize mount and unmount passes so a disable cannot race an in-flight spawn. */
    private reconcileQueue;
    /** Pending retry timers keyed by mount key, so a teardown can cancel them. */
    private readonly retries;
    /** Attempt count per mount key; reset whenever a retry succeeds. */
    private readonly attempts;
    /** Snapshot of the last reconciled suite set, replayed by retry passes. */
    private lastEnabled;
    /** Host module loader; overridable for tests. */
    private loadHost;
    /** Latest diagnostic per suite id; cleared when its suite mounts or leaves the wanted set. */
    private readonly lastDiagnostics;
    /** Direct (user-configured) server provider; defaults to none. */
    private directProvider;
    private disabledProvider;
    private disabledSnapshot;
    /** 绑定宿主上下文和可选 LSP 主机加载器，初始化串行对账状态。 */
    constructor(ctx: Context, loadHost?: () => Promise<LspStdioModule | undefined>);
    /** Queue one reconciliation behind any in-flight mount/unmount pass. */
    /** 将对账串入队列并吞掉已记录失败，避免一次失败污染后续刷新。 */
    reconcile(enabledSuites: Suite[]): Promise<LspMountDiagnostic[]>;
    /** Mount/unmount LSP servers to match the enabled suites plus direct config exactly. */
    /** 计算期望 LSP 表，卸载失效项并挂载新增项，失败写入诊断。 */
    private reconcileNow;
    /** Install the direct (user-configured) server provider used at reconcile time. */
    /** 注入 direct LSP 读取器，使用户配置与套件挂载共享对账流程。 */
    setDirectProvider(provider: () => Promise<Record<string, import('../model/types.js').LspServerSpec>>): void;
    /** 注入禁用状态读取器，供下次对账跳过用户明确关闭的服务。 */
    setDisabledProvider(provider: () => Promise<Set<string>>): void;
    /** 返回当前禁用服务快照，供状态聚合层区分 disabled。 */
    disabledServers(): Set<string>;
    /** The latest mount diagnostic per suite, for the LSP status surface. */
    /** 返回诊断副本，避免状态读取修改注册表内部状态。 */
    diagnosticsSnapshot(): Map<string, LspMountDiagnostic>;
    /** Whether at least one suite mount is live. */
    /** 判断是否至少存在一个成功挂载的 LSP 实例。 */
    hasLiveMounts(): boolean;
    /** Mount one suite's full server table as a single `dsh-lsp-stdio` instance. */
    /** 挂载单个限定套件的全部 LSP 服务，并在宿主冲突时整体回滚。 */
    private mountWith;
    /** 释放单个套件 LSP 插件，返回可展示的释放错误。 */
    private unmount;
    /**
     * Schedule a delayed re-attempt for a mount that still is not live. A
     * `host-missing` failure passes no diagnostic and is never retried; the
     * schedule is bounded and resets with every reconcile pass.
     */
    /** 按固定退避安排下一次对账；宿主缺失等确定性错误不进入重试。 */
    private scheduleRetry;
    /** Dispose every live mount after queued reconciliation passes settle. */
    /** 取消重试并释放所有 LSP 挂载，供运行时整体销毁。 */
    disposeAll(): Promise<void>;
}
export {};
