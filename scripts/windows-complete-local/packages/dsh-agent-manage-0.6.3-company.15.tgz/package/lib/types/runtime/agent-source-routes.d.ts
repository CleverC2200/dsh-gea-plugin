import type { Context } from '@deepseek-ai/cordis';
import type { AgentSources } from './agent-sources.js';
/** Authenticated Host transport; imported declarations cannot choose owner or Consumer. */
export declare function mountAgentSourceRoutes(host: Pick<Context, 'connection' | 'effect'>, sources: AgentSources): void;
