import type { SkillDefinition } from '@deepseek-ai/dsh-skill';
/** The same immutable algorithm version is consumed by calculation and its evidence verifier. */
export declare const FORECAST_VERSION = "gea-v2-5.5-decimal-1";
export type ForecastBaseline = Pick<SkillDefinition, 'name' | 'provider' | 'path' | 'resourceBase' | 'content' | 'invocation'>;
/** Current native baseline visibility and body identify the calculation rule version; metadata alone grants no business access. */
export declare function forecastBaselineHash(baseline: ForecastBaseline | undefined): string;
/** Reuse the original input normalization and actual-user origin verifier at the public calculator/evidence seam. */
export declare function forecastSourceProof(input: unknown, messages: readonly unknown[], baseline: ForecastBaseline | undefined): {
    inputHash: string;
    calculatorVersion: string;
    baselineHash: string;
    userInputVerified: boolean;
    businessAuthorization: false;
};
/** Hash the exact input values independently of JSON key order or whitespace. */
export declare function forecastInputHash(value: unknown): string;
/** Only complete JSON actually submitted by the user proves a pure calculation's source.
 * Tool results, plugin injections and a model's data_mode declaration grant nothing.
 */
export declare function hasUserForecastInput(messages: readonly unknown[], digest: string): boolean;
