import type { Catalog } from '../application/catalog.js';
import type { AgentSourceView, AgentSourcePreview } from '../contracts/agent-sources.js';
import type { UserAgents } from './user-agents.js';
/** Source acquisition/discovery uses Catalog; editable snapshots and publication belong to UserAgents. */
export declare class AgentSources {
    private readonly catalog;
    private readonly agents;
    private pending;
    private plans;
    constructor(catalog: Catalog, agents: UserAgents);
    changed(): void;
    list(): Promise<AgentSourceView[]>;
    acquire(input: unknown, signal?: AbortSignal): Promise<AgentSourceView>;
    import(input: unknown, signal?: AbortSignal): Promise<import("../contracts/user-agents.js").UserAgentView>;
    /** Capture old source and effective MCP values before Catalog may reset a checkout. */
    preview(input: unknown, signal?: AbortSignal): Promise<AgentSourcePreview>;
    cancel(input: unknown): Promise<{
        cancelled: true;
    }>;
    commit(input: unknown, signal?: AbortSignal): Promise<import("../contracts/user-agents.js").UserAgentView>;
    private serialize;
    private sourceSkills;
    private discover;
}
