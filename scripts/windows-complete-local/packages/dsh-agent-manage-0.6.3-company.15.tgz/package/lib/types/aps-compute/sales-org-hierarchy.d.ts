export type SalesOrgNode = {
    name: string;
    children?: SalesOrgNode[];
};
export declare const salesOrgHierarchy: SalesOrgNode[];
export declare const salesOrgCounts: {
    regions: number;
    provinces: number;
    teams: number;
};
