import type { MetricData } from './metrics.js';
export type WorkbenchWarning = {
    id: string;
    rank: string;
    scope: string;
    metric: string;
    range: string;
    gap: string;
    diagnosis: string;
    confidence: number;
    evidence: string;
    trend: string;
    dimension: 'category';
};
export type WorkbenchAction = {
    id: string;
    rank: string;
    trigger: string;
    triggerNote: string;
    scope: string;
    metric: string;
    gap: string;
    diagnosis: string;
    evidence: string;
    confidence: number;
    owner: string;
    due: string;
    action: string;
    impact: string;
    dimension: 'cross';
};
export declare function deriveWorkbenchInsights(data?: MetricData | null, previous?: MetricData | null): {
    warnings: WorkbenchWarning[];
    actions: WorkbenchAction[];
};
/** Full risk list from the same page facts and thresholds as the workbench. */
export declare function deriveOrderRisks(data: MetricData | null | undefined, dimension: 'category' | 'base' | 'cross'): {
    risk: "\u4E25\u91CD" | "\u9884\u8B66";
    gap: number;
    scope: string;
    demand: number;
    shortage: number;
    rate: number;
}[];
