type Row = Record<string, unknown>;
export type Metric = {
    name: string;
    value: number | null;
    unit: string;
    note: string;
};
export type MetricData = {
    start: string;
    end: string;
    granularity: string;
    sections: {
        id: string;
        status: string;
        rows: Row[];
    }[];
};
export declare function accuracy(planned: number | null, actual: number | null): number | null;
export declare function change(current: Metric, previous?: Metric): string;
export declare function deriveMetrics(data: MetricData): Record<string, Metric>;
export {};
