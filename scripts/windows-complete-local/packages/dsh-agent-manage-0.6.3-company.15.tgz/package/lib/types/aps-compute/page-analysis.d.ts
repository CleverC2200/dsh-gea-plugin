import { type MetricData } from './metrics.js';
export declare const pageAnalysisPolicy: {
    readonly source: "current-page";
    readonly allowAdditionalQueries: false;
    readonly allowAutomaticRefresh: false;
    readonly conclusionFirst: true;
    readonly partialDataAllowed: true;
};
/** Pure analysis of the successful sections already present on this page. */
export declare function summarizePage(data: MetricData | null | undefined, busy?: boolean, visibleMetrics?: readonly string[]): {
    title: string;
    copy: string;
};
