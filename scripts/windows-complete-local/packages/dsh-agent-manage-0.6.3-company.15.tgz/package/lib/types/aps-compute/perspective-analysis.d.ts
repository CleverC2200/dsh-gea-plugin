/** The four V0.2 analysis views use the same evidence and boundary rules as the
 * business prompts. This pure function never fills missing measures with demo data. */
export type AnalysisMetric = {
    name: string;
    value: number;
    unit: string;
    previous?: number | null;
};
export type AnalysisScope = 'overview' | 'production' | 'sales';
export type AnalysisResult = {
    title: string;
    copy: string;
    score: number;
    total: number;
    question: string;
};
export declare function analyzePerspective(scope: AnalysisScope, period: string, metrics: AnalysisMetric[]): AnalysisResult;
export type MatrixCell = {
    scope: string;
    value: number;
    weight?: number;
};
export declare function analyzeProductionMatrix(metric: string, period: string, cells: MatrixCell[]): AnalysisResult;
/** Matrix cells are recomputed from mutually exclusive base/category source rows. */
export declare function matrixCellsFromData(data: {
    sections: {
        id: string;
        status: string;
        rows: Record<string, unknown>[];
    }[];
} | null | undefined, metric: string): MatrixCell[];
