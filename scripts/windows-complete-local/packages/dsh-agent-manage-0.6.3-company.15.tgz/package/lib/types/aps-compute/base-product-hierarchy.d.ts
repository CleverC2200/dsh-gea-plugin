export type BaseProductItem = {
    name: string;
    materials: string[];
};
export type BaseProductCategory = {
    name: string;
    items: BaseProductItem[];
};
export declare const baseProductHierarchy: BaseProductCategory[];
