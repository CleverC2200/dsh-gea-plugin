export type CalendarDate = {
    year: number;
    month: number;
    day: number;
    iso: string;
};
export declare function effectivePeriodEnd(year: number, month: number, day: number, today?: Date): CalendarDate;
export declare function isFutureCalendarDay(year: number, month: number, day: number, today?: Date): boolean;
