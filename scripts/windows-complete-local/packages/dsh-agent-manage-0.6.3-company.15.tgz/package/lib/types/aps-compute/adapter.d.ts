import { type MetricData } from './metrics.js';
export type Scope = {
    base?: string;
    category?: string;
    item?: string;
    material?: string;
    region?: string;
    province?: string;
    sales_group?: string;
};
export declare const metricNames: readonly ["销售预算达成率", "销售提报准确率", "销售提报达成率", "需求预测准确率", "需求预测达成率", "生产计划达成率", "订单满足率", "订单缺货量", "可发货天数", "库存量"];
export declare function scopedData(data: MetricData, scope: Scope): MetricData;
export declare function metricValues(data?: MetricData | null, scope?: Scope): Record<"销售提报准确率" | "销售提报达成率" | "需求预测准确率" | "需求预测达成率" | "库存量" | "订单缺货量" | "订单满足率" | "销售预算达成率" | "生产计划达成率" | "可发货天数", number> & {
    __sales: number;
};
export declare function comparisonValues(data?: MetricData | null, previous?: MetricData | null, annual?: MetricData | null, scope?: Scope): Record<"销售提报准确率" | "销售提报达成率" | "需求预测准确率" | "需求预测达成率" | "库存量" | "订单缺货量" | "订单满足率" | "销售预算达成率" | "生产计划达成率" | "可发货天数", {
    current: number;
    previous: number;
    same: number | null;
    change: number;
    yoy: number | null;
}>;
export declare const formatNumber: (value: number | null | undefined, digits?: number) => string;
export declare function createMetricReader(data?: MetricData | null, previous?: MetricData | null, annual?: MetricData | null): (scope?: Scope) => Record<"销售提报准确率" | "销售提报达成率" | "需求预测准确率" | "需求预测达成率" | "库存量" | "订单缺货量" | "订单满足率" | "销售预算达成率" | "生产计划达成率" | "可发货天数", number> & {
    __sales: number;
} & {
    __comparison: ReturnType<typeof comparisonValues>;
};
