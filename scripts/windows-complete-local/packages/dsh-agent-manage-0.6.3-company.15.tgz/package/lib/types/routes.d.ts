/** Read-only host support for Agent configuration; mutations use the Agent-owned routes. */
import type { IncomingMessage, ServerResponse } from 'node:http';
import type { McpBackendPayload } from './contracts/market.js';
export interface WebServerService {
    register(route: {
        kind: 'exact' | 'prefix';
        path: string;
        handler: (request: IncomingMessage, response: ServerResponse) => void | Promise<void>;
    }): () => void;
}
/** No generic resource or global service write route is registered here. */
export declare function mountSuiteRoutes(hostCtx: unknown, manager: {
    runtime: {
        mcpBackendInfo(): Promise<McpBackendPayload>;
    };
}): () => void;
