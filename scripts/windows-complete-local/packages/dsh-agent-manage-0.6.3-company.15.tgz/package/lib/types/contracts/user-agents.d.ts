import type { AgentSourceBaseline } from './agent-sources.js';
/** A provider reference keeps source ownership; a content override is personal to this Agent. */
export type UserAgentSkill = {
    kind: 'reference';
    name: string;
    provider: string;
    path?: string;
    enabled: boolean;
    content?: string;
} | {
    kind: 'personal';
    name: string;
    description: string;
    content: string;
    enabled: boolean;
};
export interface TrustedCubeSource {
    sourceRef: string;
    name: string;
    enabled: boolean;
    available: boolean;
}
export interface UserAgentSkillOption {
    name: string;
    description: string;
    provider: string;
    path?: string;
}
/** Complete personal Agent configuration; distinct from a reusable subagent role. */
export interface UserAgentConfig {
    id: string;
    name: string;
    description: string;
    prompt: string;
    enabled: boolean;
    revision: number;
    source?: AgentSourceBaseline;
    /** Soft deletion keeps the stable preset identity and dependency configuration. */
    deletedAt?: string;
    skills: UserAgentSkill[];
    cube?: {
        sourceRef: string;
        enabled: boolean;
    };
}
export interface UserAgentView extends UserAgentConfig {
    customized: boolean;
    origin: 'user' | 'plugin';
    pluginSource?: {
        sourceRef: string;
        version: string;
    };
    preset: string;
    publication: 'ready' | 'disabled' | 'deleted' | 'failed';
    /** The host default still points here; only an explicit host selection changes it. */
    defaultUnavailable: boolean;
    error?: string;
}
export type SaveUserAgent = Pick<UserAgentConfig, 'name' | 'description' | 'prompt' | 'enabled'> & {
    id?: string;
};
export declare const USER_AGENT_ROUTES: {
    readonly list: "/api/agent-manage/agents";
    readonly pluginList: "/api/agent-manage/agents/plugins";
    readonly pluginSave: "/api/agent-manage/agents/plugin/save";
    readonly pluginSkills: "/api/agent-manage/agents/plugin/skills";
    readonly pluginEnabled: "/api/agent-manage/agents/plugin/enabled";
    readonly save: "/api/agent-manage/agents/save";
    readonly enabled: "/api/agent-manage/agents/enabled";
    readonly select: "/api/agent-manage/agents/select";
    readonly remove: "/api/agent-manage/agents/remove";
    readonly restore: "/api/agent-manage/agents/restore";
    readonly skillCatalog: "/api/agent-manage/agents/skills/catalog";
    readonly skillRead: "/api/agent-manage/agents/skills/read";
    readonly skills: "/api/agent-manage/agents/skills/save";
    readonly cubeSources: "/api/agent-manage/agents/cube/sources";
    readonly cubeSave: "/api/agent-manage/agents/cube/save";
    readonly cubeEnabled: "/api/agent-manage/agents/cube/enabled";
    readonly pluginCopy: "/api/agent-manage/agents/plugin/copy";
};
