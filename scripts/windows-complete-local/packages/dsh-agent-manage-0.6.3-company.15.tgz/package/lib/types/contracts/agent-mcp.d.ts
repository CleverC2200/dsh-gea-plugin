import type { McpConnectionState } from './mcp-status.js';
/** Connection definitions are shared. Each Agent owns only its enabled association. */
export interface AgentMcpView {
    connectionId: string;
    serverId: string;
    name: string;
    owner: 'user' | 'plugin';
    allowedOps: Array<'edit' | 'toggle' | 'remove'>;
    enabled: boolean;
    config: Record<string, unknown>;
    state: 'saved' | 'disabled' | 'needs-credentials' | McpConnectionState;
    canReauthorize?: boolean;
    reason?: string;
}
export interface SaveAgentMcp {
    agentId: string;
    connectionId?: string;
    serverId: string;
    name: string;
    config: Record<string, unknown>;
}
export declare const AGENT_MCP_ROUTES: {
    readonly mcpAvailable: "/api/agent-manage/agents/mcp/available";
    readonly mcpList: "/api/agent-manage/agents/mcp/list";
    readonly mcpSave: "/api/agent-manage/agents/mcp/save";
    readonly mcpAssociate: "/api/agent-manage/agents/mcp/associate";
    readonly mcpEnabled: "/api/agent-manage/agents/mcp/enabled";
    readonly mcpReauthorize: "/api/agent-manage/agents/mcp/reauthorize";
    readonly mcpCancelAuthorization: "/api/agent-manage/agents/mcp/cancel-authorization";
    readonly mcpRemove: "/api/agent-manage/agents/mcp/remove";
};
