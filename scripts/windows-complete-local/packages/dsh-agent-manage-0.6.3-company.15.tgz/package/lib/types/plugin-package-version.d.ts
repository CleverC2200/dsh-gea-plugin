/** Package identity captured at build time; immutable after module loading. */
export declare const pluginPackageVersion: Readonly<{
    readonly name: "dsh-agent-manage";
    readonly version: "0.6.3-company.15";
}>;
