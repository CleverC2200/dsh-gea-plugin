/** 文件作用：定义各 Agent 生态的插件、marketplace 和项目目录布局常量。 */
/** Ordered layout declarations shared by manifest and project discovery. 中文：本文件集中定义各编码 Agent 生态的插件与项目目录布局，供 manifest 识别和项目原生发现共用。 */
export declare const PLUGIN_LAYOUTS: readonly [{
    readonly kind: "agent-plugin-v1";
    readonly manifest: "plugin.json";
    readonly marketplaces: readonly [];
}, {
    readonly kind: "universal";
    readonly manifest: ".plugin/plugin.json";
    readonly marketplaces: readonly [".plugin/marketplace.json"];
}, {
    readonly kind: "claude-code";
    readonly manifest: ".claude-plugin/plugin.json";
    readonly marketplaces: readonly [".claude-plugin/marketplace.json"];
}, {
    readonly kind: "cursor";
    readonly manifest: ".cursor-plugin/plugin.json";
    readonly marketplaces: readonly [".cursor-plugin/marketplace.json"];
}, {
    readonly kind: "kimi";
    readonly manifest: ".kimi-plugin/plugin.json";
    readonly marketplaces: readonly [".kimi-plugin/marketplace.json"];
}, {
    readonly kind: "codex";
    readonly manifest: ".codex-plugin/plugin.json";
    readonly marketplaces: readonly [".agents/plugins/marketplace.json", ".agents/plugins/api_marketplace.json"];
}, {
    readonly kind: "zcode";
    readonly manifest: ".zcode-plugin/plugin.json";
    readonly marketplaces: readonly [];
}, {
    readonly kind: "qoder";
    readonly manifest: ".qoder-plugin/plugin.json";
    readonly marketplaces: readonly [".qoder-plugin/marketplace.json"];
}, {
    readonly kind: "github-copilot";
    readonly manifest: ".github/plugin/plugin.json";
    readonly marketplaces: readonly [".github/plugin/marketplace.json"];
}];
export type ManifestKind = (typeof PLUGIN_LAYOUTS)[number]['kind'];
/** Kimi Code's primary spelling precedes its compatibility spelling within that dialect. 中文：Kimi 方言中优先使用主文件名，兼容别名只作后备。 */
export declare const MANIFEST_ALIASES: Partial<Record<ManifestKind, readonly string[]>>;
/** Equivalent plugin-owned path variables; these never resolve as credentials. 中文：不同生态表示插件根目录和数据目录的等价变量，它们属于路径占位符，不是凭据。 */
export declare const PLUGIN_ROOT_VARIABLES: ReadonlySet<string>;
export declare const PLUGIN_DATA_VARIABLES: ReadonlySet<string>;
/** Explicit project document formats and portable surfaces; execution stays in the runtime adapters. 中文：声明可识别的项目配置格式和可移植 surface，真正执行仍由 runtime 适配器负责。 */
export type ProjectMcpFormat = 'mcpServers' | 'zcode' | 'codex';
export type ProjectHookFormat = 'claude' | 'zcode';
export interface ProjectLayout {
    dirName: string;
    label: string;
    subdirs: readonly string[];
    mcpFiles?: readonly string[];
    hookFiles?: readonly string[];
    mcpFormat?: ProjectMcpFormat;
    hookFormat?: ProjectHookFormat;
}
export declare const PROJECT_LAYOUTS: readonly [{
    readonly dirName: ".claude";
    readonly label: "Claude Code";
    readonly subdirs: readonly ["skills", "agents", "commands"];
    readonly mcpFiles: readonly [".mcp.json"];
    readonly hookFiles: readonly [".claude/settings.json", ".claude/settings.local.json"];
}, {
    readonly dirName: ".agents";
    readonly label: "agents";
    readonly subdirs: readonly ["skills", "agents", "commands"];
}, {
    readonly dirName: ".codex";
    readonly label: "Codex";
    readonly subdirs: readonly ["skills"];
    readonly mcpFiles: readonly [".codex/config.toml"];
    readonly mcpFormat: "codex";
}, {
    readonly dirName: ".cursor";
    readonly label: "Cursor";
    readonly subdirs: readonly ["skills", "agents", "commands"];
    readonly mcpFiles: readonly [".cursor/mcp.json"];
}, {
    readonly dirName: ".kimi";
    readonly label: "Kimi";
    readonly subdirs: readonly ["skills"];
}, {
    readonly dirName: ".zcode";
    readonly label: "ZCode";
    readonly subdirs: readonly ["skills", "agents", "commands"];
    readonly mcpFiles: readonly ["zcode.json", ".zcode/config.json"];
    readonly mcpFormat: "zcode";
    readonly hookFiles: readonly ["zcode.json", ".zcode/config.json"];
    readonly hookFormat: "zcode";
}, {
    readonly dirName: ".qoder";
    readonly label: "Qoder CLI";
    readonly subdirs: readonly ["skills", "agents", "commands"];
    readonly mcpFiles: readonly [".qoder/settings.json", ".qoder/settings.local.json"];
    readonly hookFiles: readonly [".qoder/settings.json", ".qoder/settings.local.json"];
}, {
    readonly dirName: ".github";
    readonly label: "GitHub Copilot";
    readonly subdirs: readonly ["skills", "agents"];
}];
/** Marketplace catalogs follow manifest layout order; the shared root catalog is the fallback. 中文：市场目录按 manifest 布局优先级排序，仓库根目录的通用目录作最后兜底。 */
export declare const MARKETPLACE_PATHS: readonly string[];
