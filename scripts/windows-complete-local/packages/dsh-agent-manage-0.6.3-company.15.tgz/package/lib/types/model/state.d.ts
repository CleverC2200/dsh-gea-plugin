import { type SuiteState } from './types.js';
export declare const EMPTY_STATE: SuiteState;
/** Parse persisted state; unreadable or wrong-version files yield a contained empty state. 中文：读取并规范化状态文件，缺失、损坏或版本不匹配时安全退回空状态。 */
export declare function loadState(statePath: string): Promise<SuiteState>;
/** Persist state atomically through a sibling-temp rename. 中文：先写同目录临时文件再重命名，避免崩溃时留下半个 JSON。 */
export declare function saveState(statePath: string, state: SuiteState): Promise<void>;
