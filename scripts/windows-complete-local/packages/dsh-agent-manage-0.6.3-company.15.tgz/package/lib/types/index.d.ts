import type { Context, Volatile } from '@deepseek-ai/cordis';
import type { SourceRef } from './model/types.js';
export { pluginPackageVersion } from './plugin-package-version.js';
export declare const name = "dsh-agent-manage";
export declare const inject: string[];
/** Host configuration. */
/** 中文：插件启动时可传入 GEA MCP、初始来源和 Git 获取策略；存储根目录由宿主 DSH_HOME 决定。 */
export interface Config {
    /** Live fields belong to the official Loader config and SettingsForms. */
    mcpEnhanced: Volatile<boolean>;
    downloadRegion: Volatile<'auto' | 'global' | 'china'>;
    feedbackEnabled: Volatile<boolean>;
    scanProjectLayouts: Volatile<boolean>;
    /** Registered GEA Consumer for automatic MCP discovery after GEA plugin login. */
    /** 中文：GEA 登录后用于自动发现 MCP 的消费者；显式 false 时不挂载。 */
    geaMcp?: false;
    /** Initial repository sources, merged into the persisted state on first load. */
    /** 中文：首次加载时并入持久化状态的初始仓库源。 */
    sources?: SourceRef[];
    /**
     * Git/archive acquisition tuning: `proxy` (http/https proxy URL),
     * `insteadOf` URL-prefix rewrites (mirror acceleration), `timeoutMs` per
     * git invocation, `cloneRetry` (default true), `fallbackTarball` (retry a
     * failed GitHub clone as a codeload tarball download; default false), and
     * `allowHttpArchives` (permit plain-http archive URLs; default false).
     * 中文：统一控制代理、镜像改写、超时、重试、GitHub 压缩包回退和 HTTP 压缩包许可。
     */
    git?: {
        proxy?: string;
        insteadOf?: Record<string, string>;
        timeoutMs?: number;
        cloneRetry?: boolean;
        fallbackTarball?: boolean;
        allowHttpArchives?: boolean;
    };
}
export declare const Config: import("@deepseek-ai/schemastery").default<Schemastery.ObjectS<NoInfer<{
    mcpEnhanced: import("@deepseek-ai/schemastery").default<boolean, boolean, "volatile-defined">;
    scanProjectLayouts: import("@deepseek-ai/schemastery").default<boolean, boolean, "volatile-defined">;
    downloadRegion: import("@deepseek-ai/schemastery").default<"auto" | "global" | "china", "auto" | "global" | "china", "volatile-defined">;
    feedbackEnabled: import("@deepseek-ai/schemastery").default<boolean, boolean, "volatile-defined">;
}>>, Schemastery.ObjectT<NoInfer<{
    mcpEnhanced: import("@deepseek-ai/schemastery").default<boolean, boolean, "volatile-defined">;
    scanProjectLayouts: import("@deepseek-ai/schemastery").default<boolean, boolean, "volatile-defined">;
    downloadRegion: import("@deepseek-ai/schemastery").default<"auto" | "global" | "china", "auto" | "global" | "china", "volatile-defined">;
    feedbackEnabled: import("@deepseek-ai/schemastery").default<boolean, boolean, "volatile-defined">;
}>>, "plain">;
/** 启动插件：恢复目录状态，注册运行时资源、设置监听、路由和最终销毁器。 */
export declare function apply(ctx: Context, config?: Config): Promise<void>;
