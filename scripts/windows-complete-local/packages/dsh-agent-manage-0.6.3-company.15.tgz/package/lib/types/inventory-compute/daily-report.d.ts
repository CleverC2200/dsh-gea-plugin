/** Pure, deterministic report contract. Never treats unknown facts as zero. */
export declare const DAILY_REPORT_BASES: string[];
export type DailySource = 'stock' | 'age' | 'pending' | 'fulfillment';
export type DailyStock = {
    base: string;
    material: string;
    name: string;
    category: string;
    inventory: number | null;
    target: number | null;
    demand: number | null;
    shipment30: number | null;
    snapshot: string;
};
export type DailyAge = {
    base: string;
    material: string;
    name: string;
    category: string;
    inventory: number | null;
    bands: (number | null)[];
    natural7?: number | null;
    natural14?: number | null;
    weightedAge: number | null;
    invalidQuantity: boolean;
    snapshot: string;
};
export type DailyPending = {
    base: string;
    material: string;
    quantity: number | null;
    shortage: number | null;
    allocated: number | null;
    snapshot: string;
    inventorySnapshot: string;
};
export type DailyFulfillment = {
    base: string;
    material: string;
    need: number | null;
    shortage: number | null;
    invalidQuantity: boolean;
    snapshot: string;
};
export type DailyReportInput = {
    stock: DailyStock[];
    age: DailyAge[];
    pending: DailyPending[];
    fulfillment: DailyFulfillment[];
    pendingSnapshot: string;
    failedSources: DailySource[];
    targetMonth: string;
    targetVersion: string;
    targetRule: string;
    generatedAt: string;
    localPreview: boolean;
    selectedBases?: string[];
    includeAllRisks?: boolean;
};
export type ReportModuleId = 'age' | 'shortage' | 'movement' | 'quality';
export type ReportModule = {
    id: ReportModuleId;
    title: string;
    description: string;
    conclusion: string;
    yesterday?: string;
    overview: {
        title: string;
        metrics: ReportMetric[];
    }[];
    groups: {
        base: string;
        risks: ReportRisk[];
    }[];
};
export type ReportMetric = {
    label: string;
    value: number | null;
    unit: string;
    note?: string;
    auxiliaries?: string[];
};
export type ReportRisk = {
    id: string;
    object: string;
    kind: string;
    level: string;
    quantity: number;
    base: string;
    material: string;
    category: string;
    module: ReportModuleId;
    evidence: string;
    action: string;
    role: string;
    priority: number;
    cause: string;
    feedbackStatus: string;
    details: {
        label: string;
        value: string;
    }[];
};
export type DailyReport = {
    title: string;
    date: string;
    generatedAt: string;
    scope: string;
    bases: string[];
    localPreview: boolean;
    empty: boolean;
    summary: string[];
    metrics: ReportMetric[];
    ageInventory: number | null;
    ageBands: {
        label: string;
        quantity: number | null;
        share: number | null;
        objects: string;
    }[];
    risks: ReportRisk[];
    riskCount: number;
    missingTargetCount: number;
    missingMovementCount: number;
    sources: {
        label: string;
        status: string;
        snapshot: string;
    }[];
    notes: string[];
    coreMetrics: ReportMetric[];
    modules: ReportModule[];
    status: '已生成' | '部分生成';
    riskLevel: string;
    visibleObjectKeys: string[];
    qualityIssues: string[];
};
export declare function reportNumber(value: unknown): number | null;
export declare function reportQuantity(value: number | null, digits?: number): string;
export declare function reportDate(value: string): string;
export declare function reportTimestamp(value: string): string;
export declare const reportObjectKey: (row: {
    base: string;
    material: string;
}) => string;
/** All inputs must already have passed GEA row permissions; the intersection is
 * additional protection against joining auxiliary rows outside visible objects. */
export declare function buildDailyReport(input: DailyReportInput): DailyReport;
