export type Risk = {
    id: string;
    objectId: string;
    object: string;
    sku: string;
    productName?: string;
    category: string;
    type: string;
    tags: string[];
    priority: number;
    issue: string;
    action: string;
    role: string;
    details: unknown;
};
export type MetricKey = 'inventory' | 'target' | 'age' | 'shortage' | 'stagnant' | 'over30';
export type ObjectData = {
    categories?: (ObjectData & {
        category: string;
    })[];
    id: string;
    name: string;
    kind: 'base' | 'branch';
    inventory: number | null;
    target: number | null;
    age: number | null;
    ageWeight: number | null;
    shortage: number | null;
    stagnant: number | null;
    over30?: number | null;
    partial?: Partial<Record<MetricKey, boolean>>;
    snapshot: string;
    risks: Risk[];
    error?: string;
};
export declare const known: (v: unknown) => number | null;
export declare const sum: (values: (number | null)[]) => number | null;
export declare function summarize(objects: ObjectData[]): {
    inventory: number | null;
    target: number | null;
    gap: number | null;
    age: number | null;
    over30: number | null;
    shortage: number | null;
    stagnant: number | null;
    partial: {
        gap: boolean;
        target: boolean;
        inventory: boolean;
        shortage: boolean;
        age: boolean;
        stagnant: boolean;
        over30: boolean;
    };
    mixedStagnant: boolean;
};
export declare function dedupeRisks(risks: Risk[]): Risk[];
