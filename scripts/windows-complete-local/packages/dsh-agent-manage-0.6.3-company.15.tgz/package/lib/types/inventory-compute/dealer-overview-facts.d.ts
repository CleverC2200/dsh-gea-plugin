/** One selection policy for workbench cards and conversational overviews. */
import type { DealerDashboardSummary, DealerInventoryDailySummary } from './dealer-dashboard.js';
export declare function dealerOverviewFacts(plan: DealerDashboardSummary | null, daily: DealerInventoryDailySummary | null): {
    inventory: number | null;
    inTransit: number | null;
    totalInventory: number | null;
    forecastSales: number | null;
    averageCover: number | null;
    stockAmount: number | null;
    targetInventory: number | null;
    reasonableSkuCount: number | null;
    unreasonableSkuCount: number | null;
    shortageSkuCount: number | null;
    coveredSkuCount: number | null;
    skuCount: number | null;
    healthScore: number;
    healthStatus: string;
    expirySkuCount: null;
    inventorySource: string;
    transitSource: string;
    coverageSource: string;
    dailyCustomerCount: number;
    dailyCoverageComplete: boolean;
    stockAmountCoverage: number;
};
