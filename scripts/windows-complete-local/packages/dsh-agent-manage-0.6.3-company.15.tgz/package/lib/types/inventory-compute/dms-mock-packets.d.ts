export type DmsMockSku = {
    skuCode: string;
    qty: string;
    addQty: string;
    cutQty: string;
};
export type DmsMockPlan = {
    planId: string;
    versionId: string;
    typeCode: string;
    orderType: 'M' | 'Z';
    status: number;
    skus: DmsMockSku[];
};
export type DmsMockPacket = {
    key: string;
    PLANE_NUM: string;
    sourceVersionId: string;
    planTypeCode: string;
    orderType: 'M' | 'Z';
    operation: 'MONTHLY' | 'ADD' | 'CUT';
    items: Array<{
        skuCode: string;
        qty: string;
    }>;
};
/** 构造 mock 报文；只有 PLANE_NUM 映射是已确认的外部字段名。
 * Caller owns terminal approval and workflow validation; this calculation owns quantities and keys.
 */
export declare function buildDmsMockPackets(plan: DmsMockPlan): DmsMockPacket[];
