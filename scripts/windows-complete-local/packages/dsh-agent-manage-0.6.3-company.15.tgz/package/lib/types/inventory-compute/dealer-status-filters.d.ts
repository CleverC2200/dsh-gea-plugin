/** Read-only business predicates. Unknown facts remain unknown under exclusion. */
export declare const statusLabels: {
    readonly fuse_normal: "货龄正常";
    readonly fuse_low: "低风险";
    readonly fuse_high: "高风险";
    readonly fuse_fused: "已熔断";
    readonly fuse_attention: "货龄风险";
    readonly health_urgent: "告急";
    readonly health_healthy: "库存健康";
    readonly health_high: "库存偏高";
    readonly health_slow: "滞销";
    readonly supply_short: "缺货";
    readonly supply_enough: "保障充足";
    readonly stock_reasonable: "合理备货";
    readonly stock_unreasonable: "不合理备货";
    readonly action_attention: "需关注/暂缓";
    readonly action_deferred: "暂缓补货";
    readonly action_cautious: "谨慎补货";
    readonly action_suggested: "有建议补货量";
    readonly action_none: "无建议补货量";
    readonly action_blocked: "不可下单或需确认";
    readonly data_abnormal: "数据异常";
    readonly age_new: "新近货龄";
    readonly age_regular: "常规货龄";
    readonly age_attention: "关注货龄";
    readonly age_old: "长货龄";
    readonly sales_zero: "无动销";
    readonly expiry: "临期/过期";
};
export type DealerStatusFilter = {
    code: keyof typeof statusLabels;
    exclude: boolean;
};
type Row = Record<string, string | number | null | undefined>;
type Tri = boolean | null;
export type StatusContext = {
    fuse: (row: Row) => string;
    health: (days: number | null) => string;
    ageBand: (days: number | null) => string;
    dataIssues: (row: Row) => boolean;
    exception: (row: Row) => boolean;
};
export declare function validStatusFilters(value: unknown): value is DealerStatusFilter[] | undefined;
export declare function statusDimension(code: string): string;
export declare function statusNumber(value: unknown): number | null;
export declare function statusMatches(row: Row, code: DealerStatusFilter['code'], context: StatusContext): Tri;
/** Shared with the answer summary: review-needed OR deferred, with guard priority. */
export declare function rowActionStatus(row: Row, context: StatusContext): string;
export declare function evaluateStatusFilters(row: Row, filters: DealerStatusFilter[], context: StatusContext): Tri;
export declare function statusFilterLabel(filters: DealerStatusFilter[]): string;
export {};
