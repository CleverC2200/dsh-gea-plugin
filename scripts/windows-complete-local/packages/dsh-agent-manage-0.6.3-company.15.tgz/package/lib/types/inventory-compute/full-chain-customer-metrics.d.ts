import type { FullChainWorkspace } from './full-chain-types.js';
export declare function customerMetrics(workspace: FullChainWorkspace): {
    inventory: number | null;
    share: null;
    turnover: number | null;
    demandIncomplete: boolean;
    averageAge: number | null;
    over30: number | null;
    reviewCount: number;
};
