import type { DealerDashboardRecord, DealerCategoryInventorySummary } from './dealer-dashboard.js';
/** Chinese-calendar season, evaluated in the business timezone (including leap months). */
export declare function seasonalReplenishmentReason(category: string, now?: Date): "季节性商品过节日后不补货" | null;
export declare function skuExpiryFacts(age: number | null | undefined, stock: number | null | undefined): {
    near: number;
    expired: number;
    remaining: null;
} | {
    near: null;
    expired: null;
    remaining: null;
} | {
    near: number;
    expired: number;
    remaining: number;
};
export declare function replenishmentFacts(stock: number | null | undefined, expiryStock: number | null | undefined, transitStock: number | null | undefined, sales30: number | null | undefined): {
    quantity: null;
    reason: string;
    action: string;
} | {
    quantity: number;
    reason: string;
    action: string;
};
export declare function missingStockFactsReason(stock: number | null | undefined, transit: number | null | undefined, target: number | null | undefined): string;
export declare function inventoryStructureRisk(categories: DealerCategoryInventorySummary[]): {
    count: number | null;
    details: {
        category: string;
        complete: boolean;
        reasons: string[];
    }[];
};
export declare function finite(value: number | null | undefined): number;
export declare function actionFor(record: DealerDashboardRecord): "" | "建议补货" | "暂无补货建议";
export declare function suggestedStockQuantity(target: number | null | undefined, stock: number | null | undefined, transit: number | null | undefined): number | null;
export declare function reasonFor(record: DealerDashboardRecord): string;
export type LiveDemoSku = {
    commerceFacts: {
        stock: number | null;
        transit: number | null;
        recommendedQty: number | null;
        nearExpiryStock: number | null;
        price: number | null;
        warehouse: string | null;
    };
    dealer: string;
    dealerCode: string;
    dealerName: string;
    plannedQty: number | null;
    region: string;
    code: string;
    sku: string;
    category: string;
    stock: number | null;
    transit: number | null;
    normalStock: number | null;
    stockAmount: number | null;
    targetInventory: number | null;
    suggestedStockQty: number | null;
    orderRecommendation?: {
        quantity: number | null;
        reason: string;
        action: string;
    };
    nearExpiryStock: number | null;
    expiredStock: number | null;
    remainingValidityDays: number | null;
    totalValidityDays: number;
    sales7: number | null;
    sales30: number | null;
    shortageSales30: number | null;
    publishedSales7: number | null;
    publishedSales30: number | null;
    publishedSalesAmount30: number | null;
    productRange: string | null;
    productTag: string | null;
    materialSize: string | null;
    cifPrice: number | null;
    averageAge: number | null;
    inventorySnapshotDate: string | null;
    inventoryDailySource: string | null;
    margin: number | null;
    price: number | null;
    sellThrough: number | null;
    manualQtyOverride: number;
    manualAdjustNote: string;
    liveAction: string;
    liveReason: string;
};
export declare function computeDealerSku(record: DealerDashboardRecord, price: number | null, useDailyInventory?: boolean, now?: Date): LiveDemoSku;
