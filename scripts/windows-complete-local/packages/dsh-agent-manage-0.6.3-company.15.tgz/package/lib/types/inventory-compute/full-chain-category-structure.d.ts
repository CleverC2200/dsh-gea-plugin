import type { StructureRow } from './full-chain-types.js';
export declare const completeTotal: (values: (number | null | undefined)[]) => number | null;
/** Aggregate only additive evidence; never average turnover ratios or merge customer units. */
export declare function summarizeStructure(rows: StructureRow[], key: string, label: string): StructureRow;
export declare function categoryStructureRows(rows: StructureRow[]): StructureRow[];
