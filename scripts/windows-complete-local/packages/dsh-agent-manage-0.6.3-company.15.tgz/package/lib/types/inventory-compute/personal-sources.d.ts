import { type DailyReportInput } from './daily-report.js';
import { type ObjectData } from './personal.js';
export type PersonalBranchSnapshot = {
    metrics: {
        inventoryQty: number | null;
        averageAgeDays: number | null;
        shortageQty: number | null;
        stagnantQty: number | null;
    };
    snapshotTime: string;
    inventory: {
        sku: string;
        category: string;
        productName?: string;
        quantity: number;
        batches: {
            quantity: number;
            ageDays: number;
        }[];
        batchSummary?: {
            positiveQty: number;
            bigDateQty: number;
            stagnantQty: number;
        };
    }[];
    replenishments: {
        sku: string;
        category: string;
        productName?: string;
        shortageQty: number | null;
        targetInventoryQty: number | null;
        availableQty: number | null;
        openTransferQty: number | null;
        recommendedQty: number | null;
        reason: string;
    }[];
};
export declare function buildBasePersonalObject(input: DailyReportInput, name: string): ObjectData;
export declare function buildBranchPersonalObject(snapshot: PersonalBranchSnapshot, warehouse: {
    id: string;
    name: string;
}): ObjectData;
