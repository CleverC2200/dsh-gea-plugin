/** Display actual stock dates only; statistical/sync dates are not fallbacks. */
export declare function inventoryDateLabel(earliest: string | null, latest: string | null, missing?: number): string;
