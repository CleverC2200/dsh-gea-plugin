import type { FullChainData } from './full-chain-types.js';
type Row = Record<string, unknown>;
export type CompanySourceRows = Record<'base' | 'branch' | 'baseAge' | 'branchAge' | 'orders' | 'pending' | 'orders7d' | 'outbound' | 'branchFulfillment' | 'baseCurrentOrders' | 'trend' | 'orderHistory' | 'agingHistory', Row[]>;
/** Original company source mappings and quantity/velocity rules; no identity or IO. */
export declare function normalizeCompanySource(rows: CompanySourceRows): FullChainData;
export {};
