import type { BuildWorkspaceRequest, FullChainData, FullChainWorkspace, TrustedAccessContext } from './full-chain-types.js';
export declare function buildAccessScopeId(access: TrustedAccessContext): string;
export declare function buildFullChainWorkspace(input: FullChainData, request: BuildWorkspaceRequest): FullChainWorkspace;
