type PolicyPeriod = {
    start?: string;
    end?: string;
};
export type DealerPolicyScope = PolicyPeriod & {
    productCode: string;
    verifiedPickupCodes?: string[];
    pickupCode?: string;
};
export type DealerPolicy = PolicyPeriod & {
    mock?: boolean;
    customerCode: string;
    verifiedPickupCodes?: string[];
    scopes?: DealerPolicyScope[];
};
export type DealerOrderRow = {
    quantity: number;
    unitPrice?: number | null;
};
/** Browser-only counterpart of the original commerce policy guard. No inferred discounts. */
export declare function applicablePolicies<T extends DealerPolicy>(policies: T[], customerCode: string, sku: string, pickupCode: string, now?: Date): T[];
export declare function orderTotals(rows: DealerOrderRow[]): {
    count: number;
    quantity: number;
    amount: number | null;
};
export {};
