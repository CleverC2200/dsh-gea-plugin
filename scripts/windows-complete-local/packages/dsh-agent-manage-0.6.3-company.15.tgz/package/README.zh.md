<img src="docs-site/public/favicon.svg" alt="" width="48" height="48" />

版本由 [package.json](package.json) 声明，既往改动见[发行历史](CHANGELOG.md)。

# dsh-agent-manage

个人 Agent 在配置页的 MCP Tab 管理外部连接。显示名称与稳定服务标识分开，每个 Agent 可选择、停用或移除自己的关联。共享定义、凭据和连接仍由 Catalog.runtime 管理，移除关联不影响其他 Agent。

同一 MCP 编辑器支持 Streamable HTTP、SSE 和 stdio。本地进程的可执行文件、参数、工作目录和环境变量分别保存；个人定义允许绝对路径并保留未知扩展字段。OAuth 沿用宿主凭据记录和浏览器授权流程。保存可在等待授权时返回，取消和失败状态保留到重新授权。取消或替换连接会关闭待定回调并拒绝迟到的令牌写入。

**[DeepSeek Harness（DSH）](https://github.com/deepseek-ai/deepseek-harness)的 Agent 配置与原生预设工作区。**

复用 Claude Code、Codex、Cursor、Kimi 等已识别布局中支持的内容及社区兼容布局，在 DSH Web 界面管理自己的技能、命令、代理角色、MCP 服务和 LSP 服务。支持的布局原地读取，无需转换清单或手动将文件复制到 DSH。各格式的具体限制见能力矩阵。

[English](README.md) | 简体中文 | [文档站](https://github.com/CleverC2200/dsh-agent-manage/tree/main/docs/guides)

[![License](https://img.shields.io/github/license/CleverC2200/dsh-agent-manage)](LICENSE)

[快速开始](#快速开始) · [日常使用](#日常使用) · [兼容性](#兼容性与运行边界) · [常见问题](#常见问题)

## 个人 Agent 配置

公开的 Agent 配置页支持持久保存个人 Agent，并将启用的配置沿当前 DSH standard 声明发布为原生预设。“开始使用”通过 Workbench 的原生 Session 入口创建新对话，保留原对话和默认选择。Skill 页可选用已有资源或创建个人正文；编辑与启停作用于该 Agent 的新会话，源文件与既有会话 revision 保留。停用会从新任务目录撤下预设；删除保留可恢复配置、历史和草稿。恢复配置后仍须显式启用并补齐依赖，不改写宿主默认。运行中会话保留原 revision；重启恢复使用保留的当前配置，不能重建旧修订。外部 MCP 沿 MCP 页配置；Git、目录和配置包来源支持三方同步，可保留本地、采用上游或手动合并，更新失败保留原可用 revision。MCP 页也可选用一个可信插件 Cube 引用，沿当前 GEA 身份执行；插件预设支持显式复制为个人 Agent。完整 Agent 配置与可复用的子角色分别保存。

## 你可以用它做什么

- 创建、启用个人 Agent，以稳定身份发布原生预设。
- 导入 Git、本地目录或配置包，通过同步保留个人修改。
- 为每个 Agent 选用已有 Skill，或编辑个人 Skill 正文。
- 配置 Agent 的 MCP 连接和获准的可信 Cube 引用，沿用宿主凭据与授权。

项目资源、原生命令、LSP、Hook 和子 Agent 保留既有执行合同。Agent 目录调整配置管理，运行能力继续服从宿主策略。

## 快速开始

本分支的包名为 `dsh-agent-manage`；新 npm 包尚未在本次工作中发布或验证，使用下方 GitHub 来源。替换旧包时应先移除旧 profile 中的插件条目，再安装新包，避免双重加载。当前设置绑定 `dsh-agent-manage` Loader 条目，旧命名空间值不自动导入，已有用户数据留在原位。

工具链与 peer 要求见 [package.json](package.json)。Git 来源需要 Git，资源发现需要宿主技能服务。隔离安装须准备本票登记的官方 SDK 与已审包；下方命令不准备这些输入。详见[宿主要求](docs/guides/usage.zh.md#宿主要求)。运行 peer 合同接受已登记的官方 DSH 0.2.0-rc.2 与 0.2.1-alpha.1；[两版 Core 决定](.agents/notes/implemented/process/2026-10-10-two-official-core-releases.zh.md)持有精确 peer 与能力矩阵。开发期图标、UI primitives 使用本票登记的 alpha.1 SDK，保留 React 去重。

将 `<name>` 替换为你的 profile 名称后安装：

```sh
dsh plugin --profile <name> add github:CleverC2200/dsh-agent-manage
```

1. 重启 DSH，打开 **工作台 → Agent 配置**（`agent-plugin-workspace`）；设置区打开同一 Agent 列表与编辑器。
2. 创建个人 Agent，或通过**配置来源**获取 Git、本地目录或配置包，再显式导入 Agent。随包销售来源可被发现，仍需导入。
3. 详情固定为**提示词、Skill、MCP**三个页签。取消放弃表单；配置保存、原生预设可用和 MCP 连接分别反馈。
4. 启用后点击**开始对话**，或在宿主普通入口选择 Agent。启用不改变默认 Agent 或已有 Session。

## 日常使用

Agent 列表显示来源、个人修改、启用与可用状态。来源同步比较基线、个人配置与上游，冲突由用户明确处理；更新失败保留原可用预设。停用或删除个人 Agent 保留可恢复配置、会话历史与草稿。

个人 MCP 支持 Streamable HTTP、SSE、本地进程和宿主凭据/OAuth。移除关联仅影响当前 Agent。插件提供的 MCP 归来源所有，只允许启停；个人 Agent 可组合允许引用的能力。GEA Cube 使用可信插件引用，GEA Host 继续核当前身份与 Consumer。

旧市场安装、命令/LSP 编辑器和通用资源 HTTP 写入已移除。发现、获取、缓存、来源锁、导入/同步、命令/LSP/Hook/项目运行与子 Agent 执行保留。路径与优先级见[存储与发现](docs/guides/usage.zh.md#存储与发现)。

启动仅使用当前 `$DSH_HOME/agent-plugins` 存储。旧 `userRoot` 或 `dataRoot` 配置在挂载前以 `MANAGE_STORAGE_UPGRADE_REQUIRED` 拒绝；原数据保留原位，必要转换另行授权。标准 home、user/data、用户资源和 `.sources` 目录不得为符号链接。

旧插件 MCP 连接覆盖保留在 `data/overrides/` 供恢复，仅启停继续生效。运行状态以 `PLUGIN_MCP_OVERRIDE_RETIRED` 标明保留文件路径；所需值应显式复制到个人 Agent 的连接。个人 MCP 定义和凭据保留既有存储与生命周期。

## 兼容性与运行边界

支持的**布局方言（layout dialect）**描述文件如何组织。[统一优先级表](#布局识别优先级)并列列出套件清单与 Marketplace 目录索引。

[`schemas/`](schemas/README.md) 中十种当前布局契约均有独立读取测试。[布局审计](docs/layout-coverage.zh.md)将它们对应到固定提交号的 README 仓库快照，并区分布局/组件兼容与完整原厂运行时等价。

支持的**运行时能力（runtime surface）**描述 DSH 能使用什么：

| 能力  | 支持情况与条件                                                                                     |
| ----- | -------------------------------------------------------------------------------------------------- |
| 技能  | 接入宿主技能目录，允许手动调用的技能出现在斜杠菜单；展开支持的根路径占位符。                       |
| 命令  | 通过宿主命令服务注册斜杠命令。                                                                     |
| 代理  | 动态子代理目录与 `subagents_run`；需要宿主 agents、tools、LLM 和 subagents 服务。                  |
| MCP   | 默认使用内置桥接，支持 stdio、带 OAuth 的 Streamable HTTP 和旧式 SSE；也可切换宿主客户端兼容模式。 |
| Hooks | 运行 `dsh-hooks-claude-code` 桥接映射支持的 command-hook 子集。                                    |
| LSP   | 宿主具备 LSP 包时实际挂载；Agent 调用还需要 profile 暴露 LSP 工具。                                |

代理角色直接发布到动态 `subagent-catalog`，采用与 DSH skills catalog 相同的逐 step 比对、条目持久化和完整替换机制。通过 `subagents_run(role, prompt)` 传入目录中的准确 ID，由工具解析角色的供应商、模型和 `reasoning_effort`，再应用角色指令及工具限制。角色不再生成 `agent-*` 或 `persona-*` 技能/命令条目。模型继承、目录刷新与 `market_agent` 迁移说明见[代理角色](docs/guides/agent-roles.zh.md)。

### 布局识别优先级

**同一个套件目录**同时存在多个清单时，按下表顺序选择第一个存在的文件来确定布局：

| 优先级 | 布局 | 套件清单 | Marketplace 目录索引 |
| --- | --- | --- | --- |
| 1 | agent-plugins.org v1 / 根兼容清单 | `plugin.json` | 无专属索引 |
| 2 | Universal 兼容布局 | `.plugin/plugin.json` | `.plugin/marketplace.json` |
| 3 | Claude Code | `.claude-plugin/plugin.json` | `.claude-plugin/marketplace.json` |
| 4 | Cursor | `.cursor-plugin/plugin.json` | `.cursor-plugin/marketplace.json` |
| 5 | Kimi Code | `kimi.plugin.json`，其次 `.kimi-plugin/plugin.json` | `.kimi-plugin/marketplace.json` |
| 6 | Codex | `.codex-plugin/plugin.json` | `.agents/plugins/marketplace.json`，其次 `.agents/plugins/api_marketplace.json` |
| 7 | ZCode | `.zcode-plugin/plugin.json` | 无专属索引 |
| 8 | Qoder CLI | `.qoder-plugin/plugin.json` | `.qoder-plugin/marketplace.json` |
| 9 | GitHub Copilot CLI | `.github/plugin/plugin.json` | `.github/plugin/marketplace.json` |
| 回退 | 技能集合 / 共享索引 | 无已知清单时按技能集合约定发现 | 根 `marketplace.json` |

- **先选择，再解析：**高优先级清单无效时给出诊断，不会自动重试低优先级清单。
- **根清单身份：**根 `plugin.json` 只有声明了受识别的 agent-plugins.org `$schema`，才按 v1 严格校验；否则按 Claude 兼容清单读取。
- **组件补充：**通常不合并多个清单。非 v1 根 `plugin.json` 缺失的组件声明可以从 `.claude-plugin/plugin.json` 补齐；根清单中的显式声明优先，marketplace 条目声明补充剩余缺项。

**两列遵循同一布局优先级。** 索引查找跳过无专属索引的布局，同一布局的别名按表内顺序尝试。根 `marketplace.json` 是共享回退，既不是技能集合的清单，也不是 agent-plugins.org v1 的专属索引，不继承根 `plugin.json` 的优先级。

读取阶段收集所有存在的索引，套件扫描采用第一个能产出套件的索引，不会合并全部索引；无效或空索引允许继续尝试下一项。该优先级不意味着项目原生目录之间互斥。

顺序定义见 [`src/model/layouts.ts`](src/model/layouts.ts)，选择与根清单补充逻辑见 [`src/catalog/manifests.ts`](src/catalog/manifests.ts)。

### 布局能力支持矩阵

按官方文档、本插件源码与「每个 schema 一个真实仓库」逐项核验（2026-09-08）。表中描述的是**本插件接入范围**：“通用”表示仅按本插件共用目录规则读取，不代表该平台定义了对应能力；“部分”须结合下方限制阅读。[兼容性报告](docs/compat-report.md)记录抽样仓库、提交号、schema 结论与扫描器输出。

| 布局 | Skills | Agents | Commands | MCP | Hooks | LSP |
| --- | --- | --- | --- | --- | --- | --- |
| [Claude Code](https://code.claude.com/docs/en/plugins-reference) | 声明 + 默认技能 | 声明 Markdown | 声明 Markdown | 文件 / 内联 | 命令事件子集 | 文件 / 内联 |
| [Codex](https://developers.openai.com/plugins/build/plugins) | 支持 | 通用 | 通用 | 部分：`.mcp.json` | 兼容事件子集 | 通用内联 |
| [Cursor](https://cursor.com/docs/reference/plugins) | 支持 | 部分：仅 `.md` | 部分：仅 `.md` | 部分：见下方限制 | 原生事件不支持 | 通用内联 |
| Kimi Code | 声明技能 + 启动技能 | 声明 Markdown | 声明命令 | 内联 | 内联命令事件 | 通用扩展，非原生 |
| [ZCode](https://zcode.z.ai/en/docs/plugin) `.zcode-plugin/` | 通用 | 通用 | 通用 | `.mcp.json` + 内联覆盖 | 通用 | 通用内联，非原生 |
| [Qoder CLI](https://docs.qoder.com/cli/plugins-reference) `.qoder-plugin/` | 通用 | 通用 | 通用 | 部分：优先 `.mcp.json` | 通用 | 通用内联，非原生 |
| [GitHub Copilot CLI](https://docs.github.com/en/copilot/reference/copilot-cli-reference/cli-plugin-reference) | 声明技能 | `.md` / `.agent.md` | 声明 Markdown | 文件 / 内联 | 映射命令事件 | 文件 / 内联 |
| Universal 兼容布局 `.plugin/` | 通用 | 通用 | 通用 | 通用 | Claude 格式子集 | 通用内联 |
| [agent-plugins.org v1](https://agent-plugins.org/specification) | 支持 | 通用，非标准 | 通用，非标准 | 标准 `mcp.json` | 通用，非标准 | 仅目录预览，非标准 |
| 无清单技能集合 | 支持 | 通用 | 通用 | 通用文件 | Claude 格式子集 | 仅目录预览 |
| 项目原生目录（见下文） | 支持 | 可移植 Markdown 角色 | 会话作用域命令 | JSON / Codex TOML | 已映射命令事件子集 | 诊断，不挂载 |

- **组件路径：**支持声明文件、目录树和数组，按 realpath 限制在套件内部。命令、代理和详情面板消费同一组资源。Cursor 命令还支持 `.mdc`、`.markdown`、`.txt`；Qoder 命令映射支持文件与内联内容。Claude/Codex 技能声明补充默认发现；无清单集合也支持平铺技能 Markdown 文件。
- **代理身份：**`reviewer.agent.md` 与 `reviewer.md` 在子代理目录中保留不同角色 ID，不再生成 `agent-*` 技能或命令别名。普通技能本身采用这些名称的不受影响。
- **MCP：**按方言解析声明文件、内联表和数组。支持 Cursor 无 schema 的 `mcp.json`；agent-plugins v1 保持严格 schema 校验。Claude/ZCode 声明叠加默认配置，Cursor 声明替换默认配置，Copilot/Universal 包含 `.github/mcp.json`，Kimi Code 使用内联声明。无效显式配置不会复活默认配置。Codex app 连接器不属于此适配器。
- **Hooks：**支持声明文件/目录及内联配置，包括 Kimi 数组和保留 argv 引用边界的 ZCode process hooks。受支持的 Copilot/Cursor 生命周期名称映射到已有 command-hook 桥。没有 DSH 对应点的事件（如 `afterFileEdit`）给出诊断，不伪造执行。
- **LSP：**用户套件支持声明文件、数组、内联表，以及 `.lsp.json` 和 Copilot/Universal 的 `lsp.json`、`.github/lsp.json`、`lsp-config/servers.json`。反向域名目录定义仍为预览。项目 LSP 保留宿主作用域限制。
- **规范边界：**agent-plugins.org v1 的可移植核心只有 skills 与 MCP，不能把通用 agents / commands / hooks 扫描称为标准能力。Universal 是本插件识别的兼容布局名称：[OpenHands SDK](https://docs.openhands.dev/sdk/guides/plugins)文档同样使用 `.plugin/plugin.json`，[Vercel 仓库](https://github.com/vercel/vercel-plugin/blob/main/.plugin/plugin.json)也在使用，但不存在跨厂商规范。
- **Kimi Code：**当前 schema 覆盖两种清单路径、启动技能、附加技能指令、系统提示、内联 hooks 和 catalog 别名。历史 `kimi-cli` 根 tools 协议是另一套系统，不能与当前 Kimi Code schema 混淆。
- **ZCode 边界：**已识别 `.zcode-plugin/plugin.json` 与根 `marketplace.json`，包含按名称索引的插件表。内联 MCP 按同名键覆盖 `.mcp.json`。尚未实现 marketplace 的 zip + `sha256` 分发契约。
- **Qoder 边界：**已识别 `.qoder-plugin/plugin.json` 与 `.qoder-plugin/marketplace.json`。MCP 优先读取 `.mcp.json`，无 schema 的 `mcp.json` 作为回退。
- **GitHub Copilot CLI：**`.plugin/plugin.json` 保留 Universal 身份。两种路径均消费声明组件及默认 MCP/LSP 文件。隔离测试在嵌套套件根也去除竞争清单，防止 Claude 回退冒充 Copilot 测试通过。
- **项目目录：**[Claude 项目技能](https://code.claude.com/docs/en/skills)与 [Codex 的 `.agents/skills`](https://developers.openai.com/codex/skills)有官方依据；`.agents/agents`、`.agents/commands` 是本插件的通用发现约定。

### 项目布局开关

插件设置卡提供**扫描项目 Agent 布局**（`dsh-agent-manage.scanProjectLayouts`，默认 `true`）。关闭后立即移除本插件的项目原生候选；配置源与宿主自身的技能提供器独立运行。文件原位只读，不安装、不改写、不删除。

注册表读取 `.claude`、`.agents`、`.codex`、`.cursor`、`.kimi`、`.zcode`、`.qoder`、`.github` 下的技能。除 `.codex` 与 `.kimi` 外启用可移植 Markdown agents；两者的 TOML/YAML 格式需要独立适配器。角色执行按调用会话确定项目。项目 commands、受支持的 MCP 服务和已映射命令 hooks 注册在各 Agent 独立作用域，会话启动或目录变更通知时刷新，关闭总开关即撤销。

MCP 读取根 `.mcp.json`、`.cursor/mcp.json`，以及 `.qoder/settings.json`、`.qoder/settings.local.json` 的 `mcpServers` 表（本机配置覆盖同名项目配置）。ZCode 读取 `zcode.json`、`.zcode/config.json` 的 `mcp.servers`，原生表为空时回退到 `.agents/mcp.json`。Codex 通过 `smol-toml` 读取 `.codex/config.toml` 的 `[mcp_servers.*]`，保留 stdio/HTTP 配置、环境变量/请求头引用、启停、工具过滤和超时。不支持的服务字段会报诊断，宿主客户端模式会拒绝无法执行的策略。相对可执行路径从项目根解析。Claude/Qoder 设置 hooks 与明确启用的 ZCode 配置 hooks 使用桥支持的命令事件子集。校验后的 hooks 写入私有运行时临时文件，销毁时删除，项目原文件保持不变。项目 LSP 给出诊断且不挂载，修改宿主不属于本插件范围。见[架构决策与支持边界](docs/adr/2026-09-09-layout-registry.md)。

### 抽样验证

`schemas/` 中的每个 schema 都会对照一个真实仓库核验——取 GitHub 代码搜索为该布局返回的 star 最高候选（2026-09-08）——再用本插件自己的扫描器读取该 checkout。九个样本中有六个**被遮蔽（shadowed）**：仓库同时提供多种方言，优先级更高的清单胜出，因此能力面仍被发现，但抽样方言自身的身份未被采用。[兼容性报告](docs/compat-report.md)记录了提交号、schema 错误与扫描备注。

| 布局 | 抽样仓库 | 方言清单 | Schema | 扫描器 |
| --- | --- | --- | --- | --- |
| Claude Code | [grafana/mcp-grafana](https://github.com/grafana/mcp-grafana) | `.claude-plugin/plugin.json` | 通过 | 接入 |
| Codex | [saadeghi/daisyui](https://github.com/saadeghi/daisyui) | `.codex-plugin/plugin.json` | 通过 | 被遮蔽 |
| Cursor | [EveryInc/compound-engineering-plugin](https://github.com/EveryInc/compound-engineering-plugin) | `.cursor-plugin/plugin.json` + marketplace | 通过 | 被遮蔽 |
| Kimi | [obra/superpowers](https://github.com/obra/superpowers) | `.kimi-plugin/plugin.json` | 通过 | 被遮蔽 |
| Universal | [muratcankoylan/Agent-Skills-for-Context-Engineering](https://github.com/muratcankoylan/Agent-Skills-for-Context-Engineering) | `.plugin/plugin.json` | 通过 | 接入 |
| agent-plugins.org v1 | [saadeghi/daisyui](https://github.com/saadeghi/daisyui) | `plugin.json` | 通过 | 接入 |
| ZCode | [zenstory-ai/oh-story-claudecode](https://github.com/zenstory-ai/oh-story-claudecode) | `.zcode-plugin/plugin.json` + `marketplace.json` | 通过 | 被遮蔽 |
| Qoder CLI | [DietrichGebert/ponytail](https://github.com/DietrichGebert/ponytail) | `.qoder-plugin/plugin.json` | 通过 | 被遮蔽 |
| GitHub Copilot CLI | [headroomlabs-ai/headroom](https://github.com/headroomlabs-ai/headroom) | `.github/plugin/marketplace.json` | 通过 | 被遮蔽 |

**扫描器**列描述未修改的仓库：**接入**表示自身清单胜出，**被遮蔽**表示其它方言胜出，**未读取**表示无套件。它与单布局隔离测试分开判断。无清单集合使用真实 Universal 仓库技能、在测试中移除清单验证，补齐十种布局覆盖。快照位于 `tests/fixtures/real-layouts/`，保留提交号、文件哈希与许可证，详见[审计表](docs/layout-coverage.zh.md)。

核验依据包括 `src/catalog/manifests.ts`、`surfaces.ts`、`validate.ts`、`native-project.ts` 与 `src/runtime/hooks-mounts.ts`。[兼容性报告](docs/compat-report.md)补充「每个 schema 一个真实仓库」并由本插件扫描器实测。这是文档、源码与抽样核验，并非每个平台的端到端兼容认证。

能读取一种布局，并不保证复现原平台的全部行为。无效声明会被诊断并跳过。项目原生命令与受支持的 MCP 服务使用宿主的 Agent 作用域注册；项目 MCP 服务名包含会话身份，以避免应用级命名冲突。

启用第三方套件前请检查其内容：启用的服务和 hooks 可以执行程序。详见[运行时与安全边界](docs/guides/usage.zh.md#运行时与安全边界)。

## 常见问题

**安装后为什么找不到技能或工具？**

检查套件及对应能力是否启用。技能可能限制手动调用；MCP / LSP 面板显示用户服务故障。项目资源还需要开启项目扫描；不支持的原生字段与项目 LSP 声明进入扫描诊断，作用域挂载错误记录在宿主日志中。

**在哪里配置 MCP token？**

在 **MCP 服务**中打开对应服务。缺失环境变量引用时显示 `needs-credentials`。宿主管理的凭据只写不读；启动环境中的凭据需要修改环境后重启 DSH。

**套件没有声明的服务怎么添加？**

在 **MCP 服务**或 **LSP 服务**中点击新增并填入声明。声明会先校验，保存到 `~/.dsh/agent-plugins/data/` 下，并与套件服务走同一套挂载生命周期。从宿主配置观察到的服务保持只读。

**来源下载失败怎么办？**

可以使用本地目录、收编手动克隆的仓库，或配置代理与镜像，见[配置市场源](docs/guides/usage.zh.md#配置市场源)。

**本地修改什么时候生效？**

没有文件监听。本地来源的发现结果最多缓存 30 秒，刷新来源可立即使缓存失效。项目发现有独立的五秒缓存。已经打开的页面不会自动刷新。

**删除来源会删除文件吗？**

只有勾选确认框里的「同时删除市场目录」才会删除。它删除该源在 `~/.dsh/agent-plugins/.sources/<id>` 下的目录——包括你手动克隆后被收编的目录。指向 `.sources/` 之外的本地目录源永不删除。

## 更多文档

Host 与 client 入口均导出冻结的 `pluginPackageVersion {name, version}`，记录编译时的包身份。构建从当前 package.json 生成标记，类型检查拒绝过期标记；已加载模块不会重读更新后的 manifest。运行核对应读取实际 ACTIVE Loader 模块的导出，另核安装来源与重启过程；标记本身不证明 Native 装载或业务验收。

- [使用指南](docs/guides/usage.zh.md)：安装、来源配置、存储、宿主要求、MCP / LSP 和反馈设置。
- [插件规范](schemas/README.md)：各布局的参考 schema 与依据，以及内置的 agent-plugins.org v1.0.0 契约。
- [兼容性报告](docs/compat-report.md)：每个 schema 一个真实仓库，含提交号、schema 结论与扫描器输出。
- [贡献指南](CONTRIBUTING.md)：开发环境、检查命令和 PR 流程。
- [安全政策](SECURITY.md) · [版本记录](CHANGELOG.md) · [MIT 许可](LICENSE)。
- [领域词汇](CONTEXT.md) · [架构设计](docs/adr/0001-catalog-centered-modular-refactor.md)。

- [代理角色与存储](docs/guides/agent-roles.zh.md)：角色策略、持久目录和存储。
- [GEA MCP](docs/guides/gea-mcp.zh.md)：登录归属、Consumer/预设约束及取消。
- [原生资源](docs/guides/native-resources.zh.md)：公开选用、恢复、参考读取、计算来源与业务包边界。
- [当前开发](docs/current-development.md)：登记的 SDK、源码检查与未完成验收。
